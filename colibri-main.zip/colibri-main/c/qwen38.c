/* Qwen3.8-Flash-Next text inference in dependency-free C.
 *
 * The language model is 12 repetitions of three Gated DeltaNet layers and one
 * Qwen Sparse Attention (QSA) layer.  Four Gated-Residual streams replace the
 * usual scalar residual; layer 2 injects pageable hashed n-gram embeddings
 * (PLE), and every layer has a 512-way sparse MoE plus a shared expert.
 *
 * Resident tensors are loaded from the official multimodal checkpoint's text
 * namespace.  The MTP head's tensors are read only under Q38_MTP=1, which
 * turns on speculative decoding with it (qwen38_core.h).  Official
 * block-FP8 experts remain native in a bounded per-layer LRU; the 51B-parameter
 * PLE table remains on disk and only its sixteen 160-byte rows/token are read.
 *
 * Runtime: SNAP=<dir>, optional Q38_MAXT, Q38_EXPERT_PREFETCH=0 and
 * Q38_EXPERT_PARALLEL_READS=0 A/B controls, and argv
 * `qwen38 <cache/layer> <reserved> [ref.json]`.  The second positional remains
 * reserved so Colibri's common cache-aware launcher ABI stays stable.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
#include <limits.h>
#include <float.h>
#include <errno.h>
#include <time.h>
#include <stdarg.h>
#ifdef _OPENMP
#include <omp.h>
#endif

/* Hard context ceiling: the model's max_position_embeddings. Every buffer that
 * scales with position (KV cache, attention score row) is allocated from max_t,
 * so this is a policy limit, not a buffer limit -- but it is ONE limit, named
 * once. It used to be the literal 8192 in two unrelated places: the size of a
 * stack array in attention() and the default of Q38_MAXT in serve_one(). They
 * agreed by luck, and raising Q38_MAXT moved the guard without moving the
 * buffer, so a longer prompt overran the stack instead of being refused.
 * Context costs 54 KB/token in KV/index state (12 QSA layers, f32) -- 128k is 6.75 GiB
 * -- which is why Q38_MAXT still defaults far below this. */
#define QWEN38_ATTN_MAX_CTX 262144
#define QWEN38_DEFAULT_MAX_CTX 8192

/* Effective ceiling: Q38_MAXT if set and sane, the conservative default
 * otherwise; never above the hard limit. */
static int qwen38_max_ctx(void) {
    const char *e = getenv("Q38_MAXT");
    if (!e || !*e) return QWEN38_DEFAULT_MAX_CTX;
    char *end = NULL;
    errno = 0;
    long v = strtol(e, &end, 10);
    if (errno || end == e || *end || v < 1) return QWEN38_DEFAULT_MAX_CTX;
    return v > QWEN38_ATTN_MAX_CTX ? QWEN38_ATTN_MAX_CTX : (int)v;
}
#if defined(__APPLE__) || defined(__linux__) || defined(__FreeBSD__)
#include <sys/resource.h>
#include <unistd.h>
#endif
#include "cpu_check.h"   /* the processor runs what this build assumes, or it says so (#1979) */
#include "cli_args.h"
#include "st.h"
#include "omp_tune.h"
#include "qwen38_vision.h"
#include "json.h"   /* tokenizer.json parsing (reuse minimal parser) */
#include "tok_unicode.h"
#include "tok_unicode_o200k.h"
#include "qwen38_nfc.h"
/* quant.h owns Colibri's authoritative E4M3 table.  This engine retains the
 * Qwen sibling's established dense kernels, so rename quant.h's two generic
 * helpers while including it; every format-specific symbol keeps its shared
 * name and implementation. */
#define matmul coli_quant_matmul
#define matmul_q coli_quant_matmul_q
#include "quant.h"
#undef matmul
#undef matmul_q
#include "route_trace.h"             /* shared ROUTE_TRACE + .coli_usage contract */
#include "serve_codec.h"             /* shared SUBMIT/STOP/CANCEL framing */
#include "pin_pool.h"                /* piu scatti annidati dello stato */
#include "argmax_first.h"            /* serve_sample's greedy pick */
/* ---------- tokenizer (optional, for human-readable output) ---------- */
static char **g_tok = NULL;   /* id -> piece string (strdup'd) */
static int    g_tok_n = 0;

static int hexnib(char c){
    if (c>='0'&&c<='9') return c-'0';
    if (c>='a'&&c<='f') return c-'a'+10;
    if (c>='A'&&c<='F') return c-'A'+10;
    return 0;
}

/* ===== text -> ids : BPE encoder (mirrors HF/Qwen tokenizer.json) =====
 * Builds piece->id (reverse vocab) + pair->rank (merges) maps, plus the
 * GPT-2 byte-to-unicode mapping. Encode = special-token split + GPT-2 regex
 * pre-tokenize + per-piece ByteLevel map + BPE merges. */
typedef struct { char **keys; int *vals; uint8_t *used; size_t cap; } SMap;
static unsigned shash(const char *s){ unsigned h=2166136261u; while(*s){ h^=(unsigned char)*s++; h*=16777619u; } return h; }
static int smap_init(SMap *m,size_t cap){
    if(!m||cap<2||(cap&(cap-1))||cap>SIZE_MAX/sizeof(char*)||
       cap>SIZE_MAX/sizeof(int))return -1;
    memset(m,0,sizeof(*m));m->cap=cap;
    m->keys=(char**)calloc(cap,sizeof(char*));
    m->vals=(int*)malloc(cap*sizeof(int));
    m->used=(uint8_t*)calloc(cap,sizeof(uint8_t));
    if(!m->keys||!m->vals||!m->used){free(m->keys);free(m->vals);free(m->used);memset(m,0,sizeof(*m));return -1;}
    return 0;
}
static int smap_init_entries(SMap *m,size_t entries){
    if(entries>SIZE_MAX/2u)return -1;
    size_t need=entries*2u,cap=2u;
    while(cap<need){if(cap>SIZE_MAX/2u)return -1;cap*=2u;}
    return smap_init(m,cap);
}
static int smap_put(SMap *m,const char *k,int v){
    if(!m||!m->cap||!k)return -1;
    size_t h=(size_t)shash(k)&(m->cap-1u);
    for(size_t probes=0;probes<m->cap;probes++,h=(h+1u)&(m->cap-1u)){
        if(!m->used[h]){m->used[h]=1;m->keys[h]=(char*)k;m->vals[h]=v;return 0;}
        if(m->keys[h]&&!strcmp(m->keys[h],k)){m->vals[h]=v;return 0;}
    }
    return -1;
}
static int smap_get(const SMap *m,const char *k){
    if(!m||!m->cap||!k)return -1;
    size_t h=(size_t)shash(k)&(m->cap-1u);
    for(size_t probes=0;probes<m->cap&&m->used[h];probes++,h=(h+1u)&(m->cap-1u))
        if(m->keys[h]&&!strcmp(m->keys[h],k))return m->vals[h];
    return -1;
}

static SMap  g_rev;                 /* piece string -> id (encode) */
static SMap  g_merge;               /* "a\x1F b" pair -> rank (encode) */
static char  byte_sym_utf8[256][8]; /* byte -> UTF-8 of mapped codepoint */
static short g_unmap[512];          /* mapped codepoint -> original byte (-1 = unused) */
static int   g_nspecial = 0;
static char **g_sp_str = NULL; static int *g_sp_id = NULL; static int *g_sp_len = NULL;
static int g_tok_nfc = 0;

static void free_tokenizer(void){
    for(int i=0;i<g_tok_n;i++) free(g_tok ? g_tok[i] : NULL);
    free(g_tok); g_tok=NULL; g_tok_n=0;
    free(g_rev.keys); free(g_rev.vals); free(g_rev.used); memset(&g_rev,0,sizeof g_rev);
    if(g_merge.keys) for(size_t i=0;i<g_merge.cap;i++)
        if(g_merge.used && g_merge.used[i]) free(g_merge.keys[i]);
    free(g_merge.keys); free(g_merge.vals); free(g_merge.used); memset(&g_merge,0,sizeof g_merge);
    for(int i=0;i<g_nspecial;i++) free(g_sp_str ? g_sp_str[i] : NULL);
    free(g_sp_str); free(g_sp_id); free(g_sp_len);
    g_sp_str=NULL; g_sp_id=NULL; g_sp_len=NULL; g_nspecial=0; g_tok_nfc=0;
}

static const char *jstr(jval *o,const char *k){ jval *v=json_get(o,k); return (v&&v->t==J_STR)?v->str:NULL; }
static double jnum(jval *o,const char *k){ jval *v=json_get(o,k); return (v&&v->t==J_NUM)?v->num:0; }

enum { U_W=0, U_L=1, U_M=2, U_N=3, U_P=4, U_O=5 };
static int uclass(unsigned cp){
    if(is_S(cp))return U_W;
    if(is_L(cp))return U_L;
    if(is_X(cp))return U_M; /* uni_X minus uni_L is exactly Unicode Mark. */
    if(is_N(cp))return U_N;
    return U_P;             /* every remaining category is regex punctuation. */
}
static int utf8_decode(const char *s,int i,int n,int *adv){
    if(!s||i<0||i>=n){if(adv)*adv=0;return 0xfffd;}
    unsigned char c=(unsigned char)s[i]; int cp,a;
    if(c<0x80){cp=c;a=1;}
    else if((c>>5)==6){cp=c&0x1F;a=2;}
    else if((c>>4)==14){cp=c&0x0F;a=3;}
    else if((c>>3)==30){cp=c&0x07;a=4;}
    else {cp=c;a=1;}
    for(int k=1;k<a;k++){
        if(i+k>=n||((unsigned char)s[i+k]&0xC0)!=0x80){if(adv)*adv=1;return c;}
        cp=(cp<<6)|((unsigned char)s[i+k]&0x3F);
    }
    if(adv)*adv=a; return cp;
}
static int utf8_adv(const char *s,int i,int n){ int a; utf8_decode(s,i,n,&a); return a?a:1; }

static void build_byte_sym(void){
    for(int i=0;i<512;i++) g_unmap[i]=-1;
    int bs[256]; for(int b=0;b<256;b++) bs[b]=0;
    for(int b=33;b<=126;b++) bs[b]=1;
    for(int b=161;b<=172;b++) bs[b]=1;
    for(int b=174;b<=255;b++) bs[b]=1;
    int cn=0;
    for(int b=0;b<256;b++){
        int cp = bs[b]?b:(256+cn); if(!bs[b]) cn++;
        int k=0; unsigned c=(unsigned)cp;
        if(c<0x80) byte_sym_utf8[b][k++]=(char)c;
        else if(c<0x800){ byte_sym_utf8[b][k++]=0xC0|(c>>6); byte_sym_utf8[b][k++]=0x80|(c&0x3F); }
        else { byte_sym_utf8[b][k++]=0xE0|(c>>12); byte_sym_utf8[b][k++]=0x80|((c>>6)&0x3F); byte_sym_utf8[b][k++]=0x80|(c&0x3F); }
        byte_sym_utf8[b][k]=0;
        g_unmap[cp]=(short)b;   /* reverse: mapped codepoint -> original byte */
    }
}
static void q38_encode_oom(void){fprintf(stderr,"[enc] out of memory\n");exit(1);}
static void *q38_encode_malloc(size_t bytes){
    void *result=malloc(bytes);if(!result)q38_encode_oom();return result;
}
static void *q38_encode_realloc(void *allocation,size_t bytes){
    void *result=realloc(allocation,bytes);if(!result)q38_encode_oom();return result;
}
static void push_id(int **ids,int *n,int *cap,int v){
    if(!ids||!n||!cap||*n<0||*cap<1||*n>*cap){
        fprintf(stderr,"[enc] invalid token buffer state\n");exit(1);
    }
    if(*n==*cap){
        if(*cap>INT_MAX/2||(size_t)(*cap*2)>SIZE_MAX/sizeof(int))q38_encode_oom();
        *cap*=2;*ids=(int*)q38_encode_realloc(*ids,(size_t)*cap*sizeof(int));
    }
    (*ids)[(*n)++]=v;
}

static int try_special(const char *s,int i,int n,int *id_out){
    int best_len=0,best_id=-1;
    for(int k=0;k<g_nspecial;k++){
        int L=g_sp_len[k]; if(L<=0||i+L>n) continue;
        if(memcmp(s+i,g_sp_str[k],L)==0){ if(L>best_len){best_len=L;best_id=g_sp_id[k];} }
    }
    *id_out=best_id; return best_len;
}
/* Pre-tokenize splitter, mirrors the HF/Qwen regex alternation:
 *   (?i:'s|'t|'re|'ve|'m|'ll|'d) | [^\r\n\p{L}\p{N}]?[\p{L}\p{M}]+ | \p{N}
 *   | ?[^\s\p{L}\p{M}\p{N}]+[\r\n]* | \s*[\r\n]+ | \s+(?!\S) | \s+
 * Returns the byte index just past the piece starting at i. */
static int pretok_end(const char *s,int i,int n){
    if (s[i]=='\''){
        const char *cands[]={"ll","ve","re","s","t","m","d"}; int clen[]={2,2,2,1,1,1,1};
        int best=0;
        for(int c=0;c<7;c++){ int L=clen[c]; if(i+1+L>n) continue; int ok=1; for(int k=0;k<L;k++){ char a=(char)tolower((unsigned char)s[i+1+k]); if(a!=cands[c][k]){ok=0;break;} } if(ok&&L>best)best=L; }
        if(best>0) return i+1+best;
    }
    int adv; unsigned c0=utf8_decode(s,i,n,&adv);
    { /* rule2: optional non-(cr/lf/letter/number) prefix then letter/mark run */
        int k=i; unsigned c=c0; int prefix=0;
        if(k<n && c!='\r'&&c!='\n'&&uclass(c)!=U_L&&uclass(c)!=U_N&&k+adv<n){
            int a2; unsigned c1=utf8_decode(s,k+adv,n,&a2);
            if(uclass(c1)==U_L||uclass(c1)==U_M){ prefix=1; k+=adv; }
        }
        if(prefix || uclass(c)==U_L || uclass(c)==U_M){
            while(k<n){ int a; unsigned cc=utf8_decode(s,k,n,&a); if(uclass(cc)==U_L||uclass(cc)==U_M) k+=a; else break; }
            return k;
        }
    }
    if(uclass(c0)==U_N) return i+adv;
    { /* rule4: optional space + punctuation run (+ trailing newlines) */
        int k=i;
        if(s[i]==' '&&i+1<n){ int a1; unsigned c1=utf8_decode(s,i+1,n,&a1); if(uclass(c1)!=U_W&&uclass(c1)!=U_L&&uclass(c1)!=U_N&&c1!='\r'&&c1!='\n'){ k=i+1; while(k<n){int a;unsigned cc=utf8_decode(s,k,n,&a); if(uclass(cc)!=U_W&&uclass(cc)!=U_L&&uclass(cc)!=U_N&&cc!='\r'&&cc!='\n')k+=a; else break;} while(k<n&&(s[k]=='\r'||s[k]=='\n'))k++; return k; } }
        if(uclass(c0)!=U_W&&uclass(c0)!=U_L&&uclass(c0)!=U_N&&c0!='\r'&&c0!='\n'){ int k2=i; while(k2<n){int a;unsigned cc=utf8_decode(s,k2,n,&a); if(uclass(cc)!=U_W&&uclass(cc)!=U_L&&uclass(cc)!=U_N&&cc!='\r'&&cc!='\n')k2+=a; else break;} while(k2<n&&(s[k2]=='\r'||s[k2]=='\n'))k2++; return k2; }
    }
    if(uclass(c0)==U_W){
        int k=i,last=i,last_newline_end=-1,count=0;
        while(k<n){
            int a;unsigned cc=utf8_decode(s,k,n,&a);if(uclass(cc)!=U_W)break;
            last=k;if(cc=='\r'||cc=='\n')last_newline_end=k+a;k+=a;count++;
        }
        /* `\s*[\r\n]+` ends at the final newline, leaving any following
         * indentation for the next regex match.  Without a newline,
         * `\s+(?!\S)` leaves the final whitespace character available as the
         * optional prefix of the following word/punctuation match. */
        if(last_newline_end>=0)return last_newline_end;
        if(k<n&&count>1)return last;
        return k;
    }
    return i+adv;
}
#ifdef QWEN38_TEST_TOKENIZER
static uint64_t g_bpe_pair_checks;
#define Q38_BPE_PAIR_CHECK() (g_bpe_pair_checks++)
#else
#define Q38_BPE_PAIR_CHECK() ((void)0)
#endif

static int bpe_pair_rank(const char *left,const char *right){
    size_t left_length=strlen(left),right_length=strlen(right);
    if(right_length>SIZE_MAX-2u||left_length>SIZE_MAX-right_length-2u)
        q38_encode_oom();
    size_t key_length=left_length+right_length+2u;
    char *key=(char*)q38_encode_malloc(key_length);
    memcpy(key,left,left_length);key[left_length]=0x1f;
    memcpy(key+left_length+1u,right,right_length+1u);
    Q38_BPE_PAIR_CHECK();int rank=smap_get(&g_merge,key);free(key);return rank;
}

static char *bpe_join(const char *left,const char *right){
    size_t left_length=strlen(left),right_length=strlen(right);
    if(right_length>SIZE_MAX-1u||left_length>SIZE_MAX-right_length-1u)
        q38_encode_oom();
    char *joined=(char*)q38_encode_malloc(left_length+right_length+1u);
    memcpy(joined,left,left_length);memcpy(joined+left_length,right,right_length+1u);
    return joined;
}

static void bpe_piece(const char *piece,int len,int **ids,int *n,int *cap){
    if(len<=0)return;
    int sc=0,scap=16;
    char **syms=(char**)q38_encode_malloc((size_t)scap*sizeof(char*));
    for(int b=0;b<len;b++){
        const char *sym=byte_sym_utf8[(unsigned char)piece[b]];
        size_t sl=strlen(sym);char *d=(char*)q38_encode_malloc(sl+1u);
        memcpy(d,sym,sl+1u);
        if(sc==scap){
            if(scap>INT_MAX/2||(size_t)(scap*2)>SIZE_MAX/sizeof(char*))q38_encode_oom();
            scap*=2;syms=(char**)q38_encode_realloc(
                syms,(size_t)scap*sizeof(char*));
        }
        syms[sc++]=d;
    }
    while(sc>1){
        int best=-1;
        for(int k=0;k<sc-1;k++){
            int rank=bpe_pair_rank(syms[k],syms[k+1]);
            if(rank>=0&&(best<0||rank<best))best=rank;
        }
        if(best<0)break;
        /* GPT-2/Qwen BPE merges every non-overlapping occurrence of the
         * selected pair before ranks are recomputed. Besides matching the
         * reference algorithm, this keeps a long run of rank-zero pairs from
         * rescanning almost the entire request once per merge. */
        int read=0,write=0;
        while(read<sc){
            if(read+1<sc&&bpe_pair_rank(syms[read],syms[read+1])==best){
                char *joined=bpe_join(syms[read],syms[read+1]);
                free(syms[read]);free(syms[read+1]);syms[write++]=joined;read+=2;
            }else syms[write++]=syms[read++];
        }
        sc=write;
    }
    for(int k=0;k<sc;k++){ int id=smap_get(&g_rev,syms[k]); if(id<0) id=0; push_id(ids,n,cap,id); free(syms[k]); }
    free(syms);
}
static int next_special(const char *text,int from,int length){
    for(int at=from;at<length;at++){
        int unused; if(try_special(text,at,length,&unused)>0)return at;
    }
    return length;
}

static void encode_ordinary(const char *text,int length,
                            int **ids,int *count,int *capacity){
    for(int at=0;at<length;){
        int end=pretok_end(text,at,length);
        if(end<=at)end=at+utf8_adv(text,at,length);
        if(end>length)end=length;
        bpe_piece(text+at,end-at,ids,count,capacity);
        at=end;
    }
}

static void encode_text_n(const char *text,size_t text_length,
                          int **out_ids,int *out_n){
    if(!out_ids||!out_n||(text_length&&!text)||text_length>(size_t)INT_MAX){
        fprintf(stderr,"[enc] invalid or oversized input\n");exit(1);
    }
    int cap=1024,n=0;int *ids=(int*)malloc((size_t)cap*sizeof(int));
    if(!ids){fprintf(stderr,"[enc] out of memory\n");exit(1);}
    int length=(int)text_length;
    for(int at=0;at<length;){
        int sid,L=try_special(text,at,length,&sid);
        if(L>0){push_id(&ids,&n,&cap,sid);at+=L;continue;}
        /* Added tokens have normalized=false in the official tokenizer. Match
         * them against the original bytes, then normalize only the ordinary
         * span before regex pre-tokenization. */
        int limit=next_special(text,at+1,length);
        char *normalized=NULL;size_t normalized_length=0;
        if(g_tok_nfc){
            if(q38_nfc_normalize(text+at,(size_t)(limit-at),
                                 &normalized,&normalized_length)||
               normalized_length>(size_t)INT_MAX){
                free(normalized);free(ids);fprintf(stderr,"[enc] NFC normalization failed\n");exit(1);
            }
        }else{
            normalized=(char*)malloc((size_t)(limit-at)+1u);
            if(!normalized){free(ids);fprintf(stderr,"[enc] out of memory\n");exit(1);}
            memcpy(normalized,text+at,(size_t)(limit-at));
            normalized_length=(size_t)(limit-at);normalized[normalized_length]='\0';
        }
        encode_ordinary(normalized,(int)normalized_length,&ids,&n,&cap);
        free(normalized);at=limit;
    }
    *out_ids=ids;*out_n=n;
}

static void encode_text(const char *text,int **out_ids,int *out_n){
    encode_text_n(text,strlen(text),out_ids,out_n);
}

/* Load Qwen tokenizer.json and build the id/piece and BPE merge tables. Every
 * post-publication error clears the complete global state, and callers receive
 * an explicit status instead of guessing success from a partially filled
 * pointer table. */
static int load_tokenizer(const char *path){
    FILE *file=NULL;char *buffer=NULL,*arena=NULL;jval *root=NULL;
    int result=-1;
    free_tokenizer();
    file=fopen(path,"rb");
    if(!file){fprintf(stderr,"[tok] cannot open %s\n",path);goto cleanup;}
    if(fseek(file,0,SEEK_END)){fprintf(stderr,"[tok] cannot seek %s\n",path);goto cleanup;}
    long file_size=ftell(file);
    if(file_size<0||file_size>(256L<<20)||fseek(file,0,SEEK_SET)){
        fprintf(stderr,"[tok] invalid or oversized tokenizer %s\n",path);goto cleanup;
    }
    buffer=(char*)malloc((size_t)file_size+1u);
    if(!buffer||fread(buffer,1,(size_t)file_size,file)!=(size_t)file_size){
        fprintf(stderr,"[tok] cannot read %s\n",path);goto cleanup;
    }
    buffer[file_size]='\0';root=json_parse(buffer,&arena);
    if(!root||root->t!=J_OBJ){
        fprintf(stderr,"[tok] invalid tokenizer JSON in %s\n",path);goto cleanup;
    }
    jval *model=json_get(root,"model");if(!model)model=root;
    if(model->t!=J_OBJ){
        fprintf(stderr,"[tok] invalid model object in %s\n",path);goto cleanup;
    }
    jval *vocab=json_get(model,"vocab");if(!vocab)vocab=json_get(model,"tokens");
    if(!vocab||(vocab->t!=J_OBJ&&vocab->t!=J_ARR)||vocab->len<1){
        fprintf(stderr,"[tok] no valid model.vocab/tokens in %s\n",path);goto cleanup;
    }
    int max_id=0;
    if(vocab->t==J_OBJ){
        for(int index=0;index<vocab->len;index++){
            jval *value=vocab->kids[index];
            if(!value||value->t!=J_NUM||!isfinite(value->num)||value->num<0||
               value->num>10000000||floor(value->num)!=value->num){
                fprintf(stderr,"[tok] invalid vocabulary id in %s\n",path);goto cleanup;
            }
            int id=(int)value->num;if(id>max_id)max_id=id;
        }
    }else{
        if(vocab->len>10000001){
            fprintf(stderr,"[tok] vocabulary is too large in %s\n",path);goto cleanup;
        }
        max_id=vocab->len-1;
    }
    g_tok=(char**)calloc((size_t)max_id+1u,sizeof(char*));g_tok_n=max_id+1;
    if(!g_tok){fprintf(stderr,"[tok] OOM loading %s\n",path);goto cleanup;}
    if(vocab->t==J_OBJ){
        for(int index=0;index<vocab->len;index++){
            int id=(int)vocab->kids[index]->num;
            if(g_tok[id]){
                fprintf(stderr,"[tok] duplicate vocabulary id in %s\n",path);goto cleanup;
            }
            g_tok[id]=strdup(vocab->keys[index]);
            if(!g_tok[id]){fprintf(stderr,"[tok] OOM loading %s\n",path);goto cleanup;}
        }
    }else{
        for(int index=0;index<vocab->len;index++){
            jval *value=vocab->kids[index];
            if(!value||value->t!=J_STR){
                fprintf(stderr,"[tok] invalid vocabulary token in %s\n",path);goto cleanup;
            }
            g_tok[index]=strdup(value->str);
            if(!g_tok[index]){fprintf(stderr,"[tok] OOM loading %s\n",path);goto cleanup;}
        }
    }

    jval *normalizer=json_get(root,"normalizer");
    if(normalizer&&normalizer->t!=J_NULL){
        const char *kind=normalizer->t==J_OBJ?jstr(normalizer,"type"):NULL;
        if(!kind||strcmp(kind,"NFC")){
            fprintf(stderr,"[tok] unsupported tokenizer normalizer in %s\n",path);goto cleanup;
        }
        g_tok_nfc=1;
    }
    if(smap_init_entries(&g_rev,(size_t)vocab->len)){
        fprintf(stderr,"[tok] OOM sizing vocabulary map for %s\n",path);goto cleanup;
    }
    for(int id=0;id<g_tok_n;id++)if(g_tok[id]&&smap_put(&g_rev,g_tok[id],id)){
        fprintf(stderr,"[tok] vocabulary map is full in %s\n",path);goto cleanup;
    }

    jval *merges=json_get(model,"merges");
    if(merges&&merges->t!=J_ARR){
        fprintf(stderr,"[tok] invalid merge list in %s\n",path);goto cleanup;
    }
    size_t merge_entries=merges?(size_t)merges->len:0u;
    if(smap_init_entries(&g_merge,merge_entries)){
        fprintf(stderr,"[tok] OOM sizing merge map for %s\n",path);goto cleanup;
    }
    if(merges)for(int rank=0;rank<merges->len;rank++){
        jval *entry=merges->kids[rank];
        const char *encoded=entry&&entry->t==J_STR?entry->str:NULL;
        const char *space=encoded?strchr(encoded,' '):NULL;
        if(!space||space==encoded||!space[1]){
            fprintf(stderr,"[tok] invalid merge entry in %s\n",path);goto cleanup;
        }
        size_t left_length=(size_t)(space-encoded),right_length=strlen(space+1);
        if(right_length>SIZE_MAX-2u||left_length>SIZE_MAX-right_length-2u){
            fprintf(stderr,"[tok] oversized merge entry in %s\n",path);goto cleanup;
        }
        size_t key_length=left_length+right_length+2u;
        char *key=(char*)malloc(key_length);
        if(!key){fprintf(stderr,"[tok] OOM loading merges from %s\n",path);goto cleanup;}
        memcpy(key,encoded,left_length);key[left_length]=0x1f;
        memcpy(key+left_length+1u,space+1,right_length+1u);
        if(smap_get(&g_merge,key)>=0){free(key);continue;} /* first rank wins */
        if(smap_put(&g_merge,key,rank)){
            free(key);fprintf(stderr,"[tok] merge map is full in %s\n",path);goto cleanup;
        }
    }

    jval *added=json_get(root,"added_tokens");
    if(added&&added->t!=J_ARR){
        fprintf(stderr,"[tok] invalid added-token list in %s\n",path);goto cleanup;
    }
    if(added){
        int added_max=g_tok_n-1;
        for(int index=0;index<added->len;index++){
            jval *token=added->kids[index];
            jval *id_value=token&&token->t==J_OBJ?json_get(token,"id"):NULL;
            const char *content=token&&token->t==J_OBJ?jstr(token,"content"):NULL;
            if(!id_value||id_value->t!=J_NUM||!isfinite(id_value->num)||
               id_value->num<0||id_value->num>10000000||
               floor(id_value->num)!=id_value->num||!content||
               strlen(content)>(size_t)INT_MAX){
                fprintf(stderr,"[tok] invalid added token in %s\n",path);goto cleanup;
            }
            if((int)id_value->num>added_max)added_max=(int)id_value->num;
        }
        if(added_max>=g_tok_n){
            char **grown=(char**)realloc(
                g_tok,((size_t)added_max+1u)*sizeof(char*));
            if(!grown){
                fprintf(stderr,"[tok] OOM loading added tokens from %s\n",path);goto cleanup;
            }
            memset(grown+g_tok_n,0,(size_t)(added_max+1-g_tok_n)*sizeof(char*));
            g_tok=grown;g_tok_n=added_max+1;
        }
        g_nspecial=added->len;
        if(g_nspecial&&((size_t)g_nspecial>SIZE_MAX/sizeof(char*)||
                         (size_t)g_nspecial>SIZE_MAX/sizeof(int))){
            fprintf(stderr,"[tok] too many added tokens in %s\n",path);goto cleanup;
        }
        g_sp_str=(char**)calloc((size_t)g_nspecial,sizeof(char*));
        g_sp_id=(int*)malloc((size_t)g_nspecial*sizeof(int));
        g_sp_len=(int*)malloc((size_t)g_nspecial*sizeof(int));
        if(g_nspecial&&(!g_sp_str||!g_sp_id||!g_sp_len)){
            fprintf(stderr,"[tok] OOM loading added tokens from %s\n",path);goto cleanup;
        }
        for(int index=0;index<added->len;index++){
            jval *token=added->kids[index];const char *content=jstr(token,"content");
            g_sp_str[index]=strdup(content);g_sp_id[index]=(int)jnum(token,"id");
            if(!g_sp_str[index]){
                fprintf(stderr,"[tok] OOM loading added tokens from %s\n",path);goto cleanup;
            }
            g_sp_len[index]=(int)strlen(g_sp_str[index]);
            if(g_tok[g_sp_id[index]]&&strcmp(g_tok[g_sp_id[index]],content)){
                fprintf(stderr,"[tok] added token id conflicts with vocabulary in %s\n",
                        path);goto cleanup;
            }else if(!g_tok[g_sp_id[index]]){
                g_tok[g_sp_id[index]]=strdup(content);
                if(!g_tok[g_sp_id[index]]){
                    fprintf(stderr,"[tok] OOM loading added tokens from %s\n",path);goto cleanup;
                }
            }
        }
    }
    build_byte_sym();result=0;
    fprintf(stderr,"[tok] loaded %d base pieces + %d added tokens (max id %d) from %s\n",
            vocab->len,g_nspecial,g_tok_n-1,path);
cleanup:
    if(file)fclose(file);json_free(root);free(buffer);free(arena);
    if(result)free_tokenizer();
    return result;
}

/* Decode token ids to text using g_tok, writing to stdout. Handles Qwen's
 * byte-representation markers (Ġ=space, Ċ=newline, ▁=space) and <0xXX> byte
 * fallback. Only active when a tokenizer was loaded. */
/* ---- streaming / incremental decode support ---- */
static int    g_stream = 0;            /* 1 = emit tokens as they are generated */
static unsigned char g_sbuf[16];       /* carries a partial UTF-8 char across tokens */
static int    g_sbn = 0;

/* ---- OpenAI-compatible output + timing ---- */
static int    g_openai = 0;            /* 1 = emit OpenAI Chat Completions format (SSE/JSON) */
static double g_gen_t0 = 0;            /* generate() start (monotonic seconds) */
static double g_ttft   = -1;           /* time to first token (s); -1 = unset */
static long   g_oa_created = 0;        /* unix timestamp for OpenAI "created" */
static char   g_oa_id[64];             /* OpenAI-style id, e.g. chatcmpl-... */
static char   g_model[128] = "qwen3.8-flash-next-colibri";
static double now_s(void);   /* forward decl; defined later near model code */
static int q38_completion_nonce(double monotonic_seconds){
    if(!isfinite(monotonic_seconds)||monotonic_seconds<0.0)return 0;
    double within_ten=fmod(monotonic_seconds,10.0);
    return (int)(within_ten*1000.0)%10000;
}
/* Decode throughput is reciprocal TPOT: prefill produces token one, so N
 * completion tokens contain exactly N-1 measured decode intervals. */
static double q38_decode_rate(int generated,double decode_seconds){
    return generated>1&&isfinite(decode_seconds)&&decode_seconds>1e-6?
           (double)(generated-1)/decode_seconds:0.0;
}

/* Output sink for server mode: when g_sock_out >= 0, SSE/JSON bytes are routed
 * to the live socket via g_sock_send instead of stdout. Lets qwen38_serve.c
 * reuse all emit logic without any change to the CLI path. */
static long long g_sock_out = -1;
static void (*g_sock_send)(long long fd, const char *buf, int n) = NULL;
static char g_q38_usage[2100];        /* <snap>/.coli_usage, or COLI_USAGE */

/* JSON-escape a byte string into out (no surrounding quotes). Returns length,
 * or -1 without emitting a partial string when the destination is too small. */
static int json_escape(const unsigned char *s, int n, char *out, int outsz){
    if(n<0||outsz<1||!out||(n&& !s))return -1;
    int o = 0;
    for (int i=0;i<n;i++){
        unsigned char c = s[i];
        int need=c<0x20?((c=='\n'||c=='\r'||c=='\t'||c=='\b'||c=='\f')?2:6):
                 ((c=='"'||c=='\\')?2:1);
        if(o>outsz-1-need)return -1;
        if(c=='"'||c=='\\'){out[o++]='\\';out[o++]=(char)c;}
        else if(c=='\n'){out[o++]='\\';out[o++]='n';}
        else if(c=='\r'){out[o++]='\\';out[o++]='r';}
        else if(c=='\t'){out[o++]='\\';out[o++]='t';}
        else if(c=='\b'){out[o++]='\\';out[o++]='b';}
        else if(c=='\f'){out[o++]='\\';out[o++]='f';}
        else if(c<0x20){snprintf(out+o,(size_t)(outsz-o),"\\u%04x",c);o+=6;}
        else out[o++]=(char)c;
    }
    out[o] = 0;
    return o;
}

static char *json_escape_alloc(const unsigned char *s,size_t n){
    if(n>(SIZE_MAX-1u)/6u||n>((size_t)INT_MAX-1u)/6u)return NULL;
    size_t cap=n*6u+1u;char *out=(char*)malloc(cap);
    if(!out||json_escape(s,(int)n,out,(int)cap)<0){free(out);return NULL;}
    return out;
}

static char *q38_format_alloc(const char *format,...){
    va_list args,copy;va_start(args,format);va_copy(copy,args);
    int needed=vsnprintf(NULL,0,format,args);va_end(args);
    if(needed<0||(size_t)needed==SIZE_MAX){va_end(copy);return NULL;}
    char *out=(char*)malloc((size_t)needed+1u);
    if(!out||vsnprintf(out,(size_t)needed+1u,format,copy)!=needed){free(out);out=NULL;}
    va_end(copy);return out;
}

static int utf8_emit(const unsigned char *bytes,int count,
                     unsigned char *out,int outcap,int *outn){
    if(count<0||*outn<0||*outn>outcap||count>outcap-*outn)return -1;
    if(count)memcpy(out+*outn,bytes,(size_t)count);*outn+=count;return 0;
}

/* Incrementally validate decoded token bytes as UTF-8. Hugging Face's
 * ByteLevel decoder uses replacement semantics for arbitrary byte tokens, so
 * malformed maximal subparts become U+FFFD instead of leaking invalid bytes
 * into JSON/SSE. A valid scalar may remain split across token boundaries. */
static int utf8_drain(unsigned char *buf,int *bn,const unsigned char *b,int n,
                      unsigned char *out,int outcap,int *outn){
    if(!buf||!bn||*bn<0||*bn>3||n<0||(n&&!b)||outcap<0||(outcap&&!out)||!outn)return -1;
    static const unsigned char replacement[3]={0xef,0xbf,0xbd};*outn=0;
    for(int k=0;k<n;k++){
        unsigned char current=b[k];int pending=1;
        while(pending){
            if(!*bn){
                if(current<0x80){if(utf8_emit(&current,1,out,outcap,outn))return -1;}
                else if((current>=0xc2&&current<=0xdf)||
                        (current>=0xe0&&current<=0xef)||
                        (current>=0xf0&&current<=0xf4))buf[(*bn)++]=current;
                else if(utf8_emit(replacement,3,out,outcap,outn))return -1;
                pending=0;continue;
            }
            unsigned char lead=buf[0];int position=*bn;
            int continuation=current>=0x80&&current<=0xbf;
            if(position==1){
                if(lead==0xe0)continuation=current>=0xa0&&current<=0xbf;
                else if(lead==0xed)continuation=current>=0x80&&current<=0x9f;
                else if(lead==0xf0)continuation=current>=0x90&&current<=0xbf;
                else if(lead==0xf4)continuation=current>=0x80&&current<=0x8f;
            }
            if(!continuation){
                if(utf8_emit(replacement,3,out,outcap,outn))return -1;
                *bn=0;continue; /* reprocess current as a new leading byte */
            }
            buf[(*bn)++]=current;pending=0;
            int need=lead<=0xdf?2:lead<=0xef?3:4;
            if(*bn==need){
                if(utf8_emit(buf,need,out,outcap,outn))return -1;*bn=0;
            }
        }
    }
    return *outn;
}

static int utf8_finish(unsigned char *buf,int *bn,
                       unsigned char *out,int outcap,int *outn){
    static const unsigned char replacement[3]={0xef,0xbf,0xbd};
    if(!buf||!bn||*bn<0||*bn>3||!outn)return -1;*outn=0;
    if(*bn&&utf8_emit(replacement,3,out,outcap,outn))return -1;
    *bn=0;return *outn;
}

/* Emit one Server-Sent-Event chunk (OpenAI streaming uses `data: <json>` lines). */
static void sse_chunk(const char *json){
    char hdr[8]; int hl = snprintf(hdr, sizeof hdr, "data: ");
    if (g_sock_out >= 0 && g_sock_send){
        g_sock_send(g_sock_out, hdr, hl);
        g_sock_send(g_sock_out, json, (int)strlen(json));
        g_sock_send(g_sock_out, "\n\n", 2);
    } else {
        fwrite(hdr, 1, (size_t)hl, stdout);
        fwrite(json, 1, (size_t)strlen(json), stdout);
        fwrite("\n\n", 1, 2, stdout);
        fflush(stdout);
    }
}

/* Decode a single token id into its raw (unmapped) bytes.
 * The vocab stores byte-level BPE pieces: each piece is UTF-8 of the
 * GPT-2 byte_to_unicode-mapped codepoints. We reverse that mapping so the
 * output is the original text bytes (correct for CJK / non-ASCII too).
 * <0xXX> byte-fallback tokens emit the raw byte directly. */
static int decode_id_to_bytes(int id,unsigned char *out,size_t outcap){
    size_t outn=0;
    if(!g_tok||id<0||id>=g_tok_n||!g_tok[id])return 0;
    const unsigned char *pc = (const unsigned char*)g_tok[id];
    /* byte-fallback token: <0xXX> -> raw byte */
    if (strlen((const char *)pc)==6 && pc[0]=='<' && pc[1]=='0' &&
        pc[2]=='x' && pc[5]=='>'){
        if(!outcap)return -1;out[outn++]=(unsigned char)(hexnib((char)pc[3])*16+hexnib((char)pc[4]));
        return (int)outn;
    }
    int i = 0;
    while (pc[i]){
        int cp, extra;
        if (pc[i] < 0x80){ cp = pc[i]; extra = 0; }
        else if ((pc[i] & 0xE0) == 0xC0){ cp = pc[i] & 0x1F; extra = 1; }
        else if ((pc[i] & 0xF0) == 0xE0){ cp = pc[i] & 0x0F; extra = 2; }
        else if ((pc[i] & 0xF8) == 0xF0){ cp = pc[i] & 0x07; extra = 3; }
        else { i++; continue; }                 /* stray lead byte, skip */
        int ok = 1;
        for (int e=0; e<extra; e++){ if (!pc[i+1+e]){ ok=0; break; } cp = (cp<<6) | (pc[i+1+e] & 0x3F); }
        i += 1 + extra;
        if (!ok) continue;
        if(outn>=outcap)return -1;
        if(cp==0x2581)out[outn++]=' '; /* SentencePiece space marker (kept safe) */
        else if(cp<512&&g_unmap[cp]>=0)out[outn++]=(unsigned char)g_unmap[cp];
        else out[outn++]=(unsigned char)cp;
    }
    return outn>(size_t)INT_MAX?-1:(int)outn;
}

static int decode_id_alloc(int id,unsigned char **out,int *outn){
    if(!out||!outn)return -1;*out=NULL;*outn=0;
    if(!g_tok||id<0||id>=g_tok_n||!g_tok[id])return 0;
    size_t cap=strlen(g_tok[id])+1u;if(cap>(size_t)INT_MAX)return -1;
    unsigned char *bytes=(unsigned char*)malloc(cap);if(!bytes)return -1;
    int n=decode_id_to_bytes(id,bytes,cap);if(n<0){free(bytes);return -1;}
    *out=bytes;*outn=n;return 0;
}

static int q38_bytes_append(unsigned char **out,size_t *length,size_t *capacity,
                            const unsigned char *bytes,size_t count){
    if(count>SIZE_MAX-*length)return -1;size_t need=*length+count;
    if(need>*capacity){
        size_t grown=*capacity?*capacity:256u;
        while(grown<need){if(grown>SIZE_MAX/2u){grown=need;break;}grown*=2u;}
        unsigned char *next=(unsigned char*)realloc(*out,grown);if(!next)return -1;
        *out=next;*capacity=grown;
    }
    if(count)memcpy(*out+*length,bytes,count);*length=need;return 0;
}

/* Decode a range without imposing a response-size ceiling. The returned byte
 * length remains authoritative even when the text contains an embedded NUL. */
static int decode_range_alloc(const int *arr,int from,int to,
                              unsigned char **out,size_t *outn){
    if(!arr||from<0||to<from||!out||!outn)return -1;
    unsigned char carry[4];int carry_n=0;unsigned char *all=NULL;size_t length=0,capacity=0;
    for(int index=from;index<to;index++){
        unsigned char *token=NULL;int token_n=0;
        if(decode_id_alloc(arr[index],&token,&token_n)){free(all);return -1;}
        if(token_n>(INT_MAX-3)/3){free(token);free(all);return -1;}
        int chunk_cap=token_n*3+3;
        unsigned char *chunk=(unsigned char*)malloc((size_t)chunk_cap);int chunk_n=0;
        if(!chunk||utf8_drain(carry,&carry_n,token,token_n,chunk,chunk_cap,&chunk_n)<0||
           q38_bytes_append(&all,&length,&capacity,chunk,(size_t)chunk_n)){
            free(chunk);free(token);free(all);return -1;
        }
        free(chunk);free(token);
    }
    unsigned char tail[3];int tail_n=0;
    if(utf8_finish(carry,&carry_n,tail,sizeof tail,&tail_n)<0||
       q38_bytes_append(&all,&length,&capacity,tail,(size_t)tail_n)||
       q38_bytes_append(&all,&length,&capacity,(const unsigned char*)"",1u)){
        free(all);return -1;
    }
    length--;*out=all;*outn=length;return 0;
}

/* Append bytes to a buffer and flush any complete UTF-8 codepoints; any
 * trailing partial sequence is left in the buffer for the next call. */
static void out_bytes(FILE *stream,unsigned char *buf,int *bn,
                      const unsigned char *b,int n){
    if(n>(INT_MAX-3)/3){fprintf(stderr,"[decode] token is too large\n");exit(1);}
    int cap=n*3+3,outn=0;unsigned char *decoded=(unsigned char*)malloc((size_t)cap);
    if(!decoded||utf8_drain(buf,bn,b,n,decoded,cap,&outn)<0){
        free(decoded);fprintf(stderr,"[decode] invalid output capacity\n");exit(1);
    }
    if(outn)fwrite(decoded,1,(size_t)outn,stream);free(decoded);
}

static void print_decoded(FILE *stream,const int *arr,int from,int to){
    unsigned char *text=NULL;size_t length=0;
    if(decode_range_alloc(arr,from,to,&text,&length)){
        fprintf(stderr,"[decode] out of memory\n");exit(1);
    }
    if(length)fwrite(text,1,length,stream);free(text);
}

static void openai_content_chunk(const unsigned char *bytes,size_t length){
    char *content=json_escape_alloc(bytes,length);
    char *model=json_escape_alloc((const unsigned char*)g_model,strlen(g_model));
    if(!content||!model){free(content);free(model);fprintf(stderr,"[openai] out of memory formatting response\n");exit(1);}
    char *json=q38_format_alloc(
        "{\"id\":\"%s\",\"object\":\"chat.completion.chunk\",\"created\":%ld,\"model\":\"%s\","
        "\"choices\":[{\"index\":0,\"delta\":{\"content\":\"%s\"},\"finish_reason\":null}]}",
        g_oa_id,g_oa_created,model,content);
    free(content);free(model);
    if(!json){fprintf(stderr,"[openai] out of memory formatting response\n");exit(1);}
    sse_chunk(json);free(json);
}

/* Streaming variants: emit one token at a time. In OpenAI mode each token is
 * one SSE `chat.completion.chunk` (delta.content = decoded text for this token,
 * carrying partial UTF-8 across tokens so CJK never splits mid-codepoint).
 * Otherwise emit raw readable text, flushing complete UTF-8 codepoints. */
static void stream_token(int id){
    if (g_openai){
        if (g_ttft < 0) g_ttft = now_s() - g_gen_t0;   /* TTFT on first token */
        if (!g_tok){
            char token[32];int length=snprintf(token,sizeof token,"%d",id);
            openai_content_chunk((const unsigned char*)token,(size_t)length);return;
        }
        unsigned char *token=NULL;int token_n=0;
        if(decode_id_alloc(id,&token,&token_n)){fprintf(stderr,"[decode] out of memory\n");exit(1);}
        if(token_n>(INT_MAX-3)/3){free(token);fprintf(stderr,"[decode] token is too large\n");exit(1);}
        int chunk_cap=token_n*3+3;
        unsigned char *chunk=(unsigned char*)malloc((size_t)chunk_cap);int chunk_n=0;
        if(!chunk||utf8_drain(g_sbuf,&g_sbn,token,token_n,chunk,chunk_cap,&chunk_n)<0){
            free(chunk);free(token);fprintf(stderr,"[decode] invalid output capacity\n");exit(1);
        }
        if(chunk_n>0)openai_content_chunk(chunk,(size_t)chunk_n);
        free(chunk);free(token);
        return;
    }
    /* default raw-text streaming */
    if (!g_tok){ printf("%d ", id); fflush(stdout); return; }
    unsigned char *token=NULL;int token_n=0;
    if(decode_id_alloc(id,&token,&token_n)){fprintf(stderr,"[decode] out of memory\n");exit(1);}
    out_bytes(stdout,g_sbuf,&g_sbn,token,token_n);free(token);
    fflush(stdout);   /* make streaming visible immediately even when piped */
}
static void stream_flush(void){
    unsigned char tail[3];int tail_n=0;
    if(utf8_finish(g_sbuf,&g_sbn,tail,sizeof tail,&tail_n)<0){
        fprintf(stderr,"[decode] invalid UTF-8 finalization\n");exit(1);
    }
    if(tail_n)fwrite(tail,1,(size_t)tail_n,stdout);
}

/* Emit the final OpenAI Chat Completions response for a finished generation.
 * Streaming: flushes any trailing partial UTF-8 as a last content chunk, then
 * sends the termination chunk (finish_reason + usage + timings) and "data: [DONE]".
 * Non-streaming: sends a single chat.completion JSON object.
 * When g_sock_out >= 0 the bytes go to the live socket; otherwise to stdout. */
static void emit_openai_result(const int *out, int np, int n_new, int stream){
    double total = now_s() - g_gen_t0;
    if (g_ttft < 0) g_ttft = total;   /* non-streaming: all tokens arrive at once */
    double gen_t = total - g_ttft;
    double tps = q38_decode_rate(n_new,gen_t);
    if (stream){
        unsigned char tail[3];int tail_n=0;
        if(utf8_finish(g_sbuf,&g_sbn,tail,sizeof tail,&tail_n)<0){
            fprintf(stderr,"[decode] invalid UTF-8 finalization\n");exit(1);
        }
        if(tail_n)openai_content_chunk(tail,(size_t)tail_n);
        char *model=json_escape_alloc((const unsigned char*)g_model,strlen(g_model));
        char *jb=model?q38_format_alloc(
          "{\"id\":\"%s\",\"object\":\"chat.completion.chunk\",\"created\":%ld,\"model\":\"%s\","
          "\"choices\":[{\"index\":0,\"delta\":{},\"finish_reason\":\"stop\"}],"
          "\"usage\":{\"prompt_tokens\":%d,\"completion_tokens\":%d,\"total_tokens\":%d},"
          "\"timings\":{\"ttft_s\":%.3f,\"tokens_per_sec\":%.3f,\"total_s\":%.3f}}",
          g_oa_id,g_oa_created,model,np,n_new,np+n_new,g_ttft,tps,total):NULL;
        free(model);if(!jb){fprintf(stderr,"[openai] out of memory formatting response\n");exit(1);}
        sse_chunk(jb);free(jb);
        char done[16]; int dl = snprintf(done, sizeof done, "data: [DONE]\n\n");
        if (g_sock_out >= 0 && g_sock_send) g_sock_send(g_sock_out, done, dl);
        else { fwrite(done, 1, (size_t)dl, stdout); fflush(stdout); }
    } else {
        unsigned char *text=NULL;size_t text_length=0;
        if(decode_range_alloc(out,np,np+n_new,&text,&text_length)){
            fprintf(stderr,"[decode] out of memory\n");exit(1);
        }
        char *content=json_escape_alloc(text,text_length);
        char *model=json_escape_alloc((const unsigned char*)g_model,strlen(g_model));
        free(text);
        char *buf=content&&model?q38_format_alloc(
          "{\"id\":\"%s\",\"object\":\"chat.completion\",\"created\":%ld,\"model\":\"%s\","
          "\"choices\":[{\"index\":0,\"message\":{\"role\":\"assistant\",\"content\":\"%s\"},\"finish_reason\":\"stop\"}],"
          "\"usage\":{\"prompt_tokens\":%d,\"completion_tokens\":%d,\"total_tokens\":%d},"
          "\"timings\":{\"ttft_s\":%.3f,\"tokens_per_sec\":%.3f,\"total_s\":%.3f}}\n",
          g_oa_id,g_oa_created,model,content,np,n_new,np+n_new,g_ttft,tps,total):NULL;
        free(content);free(model);
        if(!buf){fprintf(stderr,"[openai] out of memory formatting response\n");exit(1);}
        size_t length=strlen(buf);
        if(g_sock_out>=0&&g_sock_send)g_sock_send(g_sock_out,buf,(int)length);
        else{fwrite(buf,1,length,stdout);fflush(stdout);}free(buf);
    }
}

/* ---------- native text inference core ---------- */
#include "qwen38_core.h"
#ifdef COLI_SEGMENT_ADAPTER
#include "segment_runtime.h"
#include "segment_adapters.h"
#include "segment_adapter_internal.h"
#endif
#ifdef COLI_EDGE_ADAPTER
#include "edge_runtime.h"
#include "edge_adapters.h"
#include "edge_adapter_internal.h"
#endif

/* The state file named by the setting `env`, or <snap>/<name>. */
static char *q38_state_path(const char *snap, const char *env, const char *name) {
    const char *given = getenv(env);
    char *path = given && *given ? q38_format_alloc("%s", given) : q38_format_alloc("%s/%s", snap, name);
    if (!path) { fprintf(stderr, "OOM path of %s\n", name); exit(1); }
    return path;
}

/* Qwen3.8 routes every transformer layer; the MTP row (index c.layers) is
 * kept only when the head is attached and routes too. Keep the
 * process-global route_trace owner in the CLI/serve model only; segment
 * adapters can coexist in one process and intentionally leave telemetry
 * detached, just like the other range-native engines. */
static int64_t q38_telemetry_init(const char *snap, const Model *m) {
    rt_init("qwen38", m->c.layers, m->c.experts);
    if (!m->mtp) rt_drop_row(m->c.layers);
    char *usage = q38_state_path(snap, "COLI_USAGE", ".coli_usage");
    snprintf(g_q38_usage, sizeof g_q38_usage, "%s", usage);
    free(usage);
    int64_t h = rt_load(g_q38_usage);
    if (h > 0)
        fprintf(stderr, "[USAGE] expert history: %lld selections (%s)\n",
                (long long)h, g_q38_usage);
    return h;   /* 0: no history (no file, or no record for this model) */
}

/* Creates the draft list (draft_vocab.h) when the head can use one: Q38_MTP_VOCAB is above 0,
 * Q38_MTP_DUMP is unset (the dump contains the logits of the whole vocabulary), Q38_DRAFT_HEAD
 * has built no int4 copy of the lm_head, the lm_head has int8 rows on the host and the counts
 * file is not the file of the expert history, which the counts would replace. It runs after the
 * trunk is int8 and before COLI_VK_DENSE_HOST releases host copies, so the lm_head rows can stay
 * on the host. */
static void q38_vocab_decide(Model *m, const char *snap) {
    if (!m->mtp) return;
    int top = q38_env_int_in_range("Q38_MTP_VOCAB", DRAFT_VOCAB_DEFAULT_TOP, 0, m->c.vocab);
    if (!top || g_q38_mtp_dump) return;
    if (m->draft_codes) {
        fprintf(stderr, "[qwen38 MTP] draft vocabulary off: Q38_DRAFT_HEAD=int4 scores the whole "
                        "vocabulary from its own copy of the lm_head\n");
        return;
    }
    if (!m->lm_head.q8) {
        fprintf(stderr, "[qwen38 MTP] draft vocabulary: the lm_head has no int8 rows on the host, "
                        "so the head scores the whole vocabulary (Q38_MTP_VOCAB=0 silences this)\n");
        return;
    }
    char *counts = q38_state_path(snap, "COLI_VOCAB_USAGE", ".coli_vocab");
    char *usage = q38_state_path(snap, "COLI_USAGE", ".coli_usage");
    int same = coli_own_same_path(counts, usage);
    if (same)
        fprintf(stderr, "[qwen38 MTP] draft vocabulary off, the head scores the whole vocabulary: "
                        "COLI_VOCAB_USAGE and COLI_USAGE are the same file, %s. Set COLI_VOCAB_USAGE "
                        "to another file.\n", counts);
    free(counts);
    free(usage);
    if (same) return;
    if (!(m->draft_vocab = draft_vocab_new(m->c.vocab, top))) { fprintf(stderr, "OOM draft vocabulary\n"); exit(1); }
}

/* Reads the token counts of the draft list from <snap>/.coli_vocab or COLI_VOCAB_USAGE. */
static void q38_vocab_init(const char *snap, Model *m) {
    DraftVocab *v = m->draft_vocab;
    if (!v) return;
    char *path = q38_state_path(snap, "COLI_VOCAB_USAGE", ".coli_vocab");
    fprintf(stderr, "[qwen38 MTP] draft vocabulary: top %d + %d/%d rule + conversation, ",
            v->top, DRAFT_VOCAB_NEAR_NUM, DRAFT_VOCAB_NEAR_DEN);
    double tokens; int distinct;
    switch (draft_vocab_load(v, path)) {
    case DRAFT_VOCAB_LOADED:
        draft_vocab_totals(v, &tokens, &distinct);
        fprintf(stderr, "counts from %s (%.0f tokens, %d distinct)\n", v->path, tokens, distinct);
        break;
    case DRAFT_VOCAB_NO_FILE:
        fprintf(stderr, "no counts file at %s yet\n", v->path);
        break;
    case DRAFT_VOCAB_NOT_COUNTS:
        fprintf(stderr, "%s cannot be read as a counts file\n", v->path);
        break;
    case DRAFT_VOCAB_OTHER_SIZE:
        fprintf(stderr, "%s has counts for another vocabulary size\n", v->path);
        break;
    case DRAFT_VOCAB_DAMAGED:
        draft_vocab_totals(v, &tokens, &distinct);
        fprintf(stderr, "counts from %s up to a damaged record, after %d records (%.0f tokens, %d distinct)\n",
                v->path, v->records, tokens, distinct);
        break;
    }
}

static void q38_vocab_save(const Model *m) {
    DraftVocab *v = m->draft_vocab;
    if (!v || !rt_save_enabled()) return;
    double tokens; int distinct;
    draft_vocab_totals(v, &tokens, &distinct);
    switch (draft_vocab_save(v)) {
    case DRAFT_VOCAB_SAVED:
        fprintf(stderr, "[STATS] %.0f tokens across %d distinct -> %s\n", tokens, distinct, v->path);
        break;
    case DRAFT_VOCAB_LEFT_ALONE:
        fprintf(stderr, "[STATS] no counts are written to %s. Set COLI_VOCAB_USAGE to use another file.\n", v->path);
        break;
    case DRAFT_VOCAB_NOT_SAVED:
        fprintf(stderr, "[STATS] the draft vocabulary counts were not written to %s. Make the directory "
                        "writable, or point COLI_VOCAB_USAGE at a file that is.\n", v->path);
        break;
    }
}

static void q38_vocab_report(const Model *m, const char *scope) {
    if (!m->draft_vocab) return;
    DraftVocabSummary s = draft_vocab_summary(m->draft_vocab);
    fprintf(stderr, "[qwen38 MTP] %s: draft list %.0f tokens on average, %.1f%% of picks inside, "
                    "%llu ids appended, %llu rebuilds\n", scope, s.average_list_tokens, s.inside_percent,
            (unsigned long long)s.appended, (unsigned long long)s.rebuilds);
}

static int q38_context_total(const Cfg *c, int prompt_tokens, int new_tokens,
                             const char *operation) {
    int limit = c->max_positions < QWEN38_ATTN_MAX_CTX
              ? c->max_positions : QWEN38_ATTN_MAX_CTX;
    if (prompt_tokens < 1 || new_tokens < 1 || prompt_tokens > limit ||
        new_tokens > limit - prompt_tokens) {
        fprintf(stderr, "[ctx] %s requires prompt=%d + new=%d tokens, capacity=%d\n",
                operation, prompt_tokens, new_tokens, limit);
        exit(1);
    }
    return prompt_tokens + new_tokens;
}

static void q38_validate_ids(const Cfg *c, const int *ids, int count,
                             const char *label) {
    if (!ids || count < 1) {
        fprintf(stderr, "%s must contain at least one token\n", label);
        exit(1);
    }
    for (int i = 0; i < count; i++) {
        if (ids[i] < 0 || ids[i] >= c->vocab) {
            fprintf(stderr, "%s[%d]=%d outside vocabulary [0,%d)\n",
                    label, i, ids[i], c->vocab);
            exit(1);
        }
    }
}

/* A decode run's speculation (qwen38_core.h, "speculative decoding"): the MTP
 * head's drafts when it is attached, Q38_MTP_DRAFTS of them per verify (1..3,
 * default 2, the depth measured fastest on a Ryzen 8700GE, CPU and Vulkan chain
 * alike, docs/speculative.md, and 1 where q38_mtp_igpu_defaults sets it; 0 or
 * auto lets the gate pick); prompt-lookup drafts under
 * COLI_LOOKUP=1, up to COLI_LOOKUP_DRAFTS (1..5, default 5); the forced modes
 * the tests use (Q38_MTP_FORCE, COLI_LOOKUP_FORCE), and COLI_SPEC_GATE=0,
 * which drafts every proposal in full. */
static int q38_spec_force_mode(const char *name, const char *value, int max_row, int lookup, int *row) {
    *row = 0;
    if (!value || !*value) return 0;
    if (!lookup && !strcmp(value, "reject")) return 'r';
    if (!strcmp(value, "accept")) return 'a';
    if (!strcmp(value, "mixed")) return 'm';
    if (!strcmp(value, "cycle")) return 'c';
    if (!strncmp(value, "row", 3) && value[3] >= '1' && value[3] <= '0' + max_row && !value[4]) {
        *row = value[3] - '0'; return 'w';
    }
    fprintf(stderr, "%s must be %saccept, mixed, cycle or row1..row%d\n", name, lookup ? "" : "reject, ", max_row);
    exit(1);
}
static Q38Spec q38_spec_begin(Model *m, const int *prompt, int np) {
    Q38Spec sp; memset(&sp, 0, sizeof sp);
    sp.on = m->mtp;
    sp.force = q38_spec_force_mode("Q38_MTP_FORCE", getenv("Q38_MTP_FORCE"), 3, 0, &sp.force_row);
    const char *depth = getenv("Q38_MTP_DRAFTS");
    sp.depth = m->mtp_drafts;
    if (depth && *depth) {
        if (!strcmp(depth, "auto") || !strcmp(depth, "0")) sp.depth = 0;
        else if (depth[0] >= '1' && depth[0] <= '3' && !depth[1]) sp.depth = depth[0] - '0';
        else { fprintf(stderr, "Q38_MTP_DRAFTS must be 1, 2, 3, or 0 (auto: the gate picks)\n"); exit(1); }
    }
    sp.lookup = q38_env_bool("COLI_LOOKUP", 1);   /* on by default, always gated (docs/speculative.md) */
    sp.lookup_max = q38_env_positive_int("COLI_LOOKUP_DRAFTS", Q38_SPEC_ROWS - 1, Q38_SPEC_ROWS - 1);
    sp.lk_force = q38_spec_force_mode("COLI_LOOKUP_FORCE", getenv("COLI_LOOKUP_FORCE"), Q38_SPEC_ROWS - 1, 1,
                                      &sp.lk_force_row);
    spec_gate_init(&sp.gate, !q38_env_bool("COLI_SPEC_GATE", 1));
    sp.pstep = q38_env_bool("Q38_MTP_PSTEP", 0);   /* opt-in: measured 1-5% slower on the Vulkan chain at depth 2 */
    if (sp.lookup && prompt && np > 0) {
        sp.hist_cap = np + 256;
        sp.hist = (int *)malloc((size_t)sp.hist_cap * sizeof(int));
        if (sp.hist) { memcpy(sp.hist, prompt, (size_t)np * sizeof(int)); sp.hist_n = np; }
        else { sp.lookup = 0; sp.hist_cap = 0; }
    }
    return sp;
}

/* Acceptance and tokens per forward, colibri.c's speculation line: a run's
 * at the end, a serve turn's after its DONE (stderr, never the wire). Tokens
 * are the decode tokens fed after the prompt, forwards the ones that fed them;
 * the MTP head's acceptance follows by draft position when it drafts deeper
 * than one, and prompt lookup has a line of its own. */
static void q38_spec_report(const Model *m, const Q38Spec *sp, const char *scope) {
    if (m->mtp) {
        char depth[160] = "";
        if (sp->depth != 1) {
            int at = snprintf(depth, sizeof depth, " | %s, by position:", sp->depth ? "fixed depth" : "depth by the gate");
            for (int j = 0; j < 3 && at < (int)sizeof depth; j++)
                at += snprintf(depth + at, sizeof depth - (size_t)at, " %d %.1f%% (%llu/%llu)", j + 1,
                               sp->depth_prop[j] ? 100.0 * sp->depth_hit[j] / sp->depth_prop[j] : 0.0,
                               (unsigned long long)sp->depth_hit[j], (unsigned long long)sp->depth_prop[j]);
        }
        fprintf(stderr, "[qwen38 MTP] %s: %.2f tokens/forward (%llu forwards per %llu tokens) | "
                        "acceptance %.1f%% (%llu/%llu drafts) | wiring %c%s%s%s%s\n", scope,
                sp->forwards ? (double)sp->tokens / sp->forwards : 0.0,
                (unsigned long long)sp->forwards, (unsigned long long)sp->tokens,
                sp->drafts ? 100.0 * sp->accepted / sp->drafts : 0.0,
                (unsigned long long)sp->accepted, (unsigned long long)sp->drafts, m->mtp_wiring,
                sp->force ? ", Q38_MTP_FORCE=" : "",
                sp->force == 'r' ? "reject" : sp->force == 'a' ? "accept" : sp->force == 'm' ? "mixed" :
                sp->force == 'c' ? "cycle" : sp->force == 'w' ? "row" : "", depth,
                sp->ended_ahead ? " | ended mid-verify" : "");
    }
    if (!sp->gate.off && ((m->mtp && sp->depth == 0) || sp->lookup)) {
        char g[384];
        spec_gate_describe(&sp->gate, m->mtp && sp->depth == 0 ? SPEC_SRC_MTP : SPEC_SRC_LOOKUP, g, sizeof g);
        fprintf(stderr, "[qwen38 spec gate] %s: %s\n", scope, g);
    }
    if (sp->lookup || sp->lk_verifies)
        fprintf(stderr, "[qwen38 lookup] %s: %.2f tokens/forward (%llu forwards per %llu tokens) | "
                        "acceptance %.1f%% (%llu/%llu drafts in %llu verifies) | gate %s, %llu declined, %llu probes%s\n",
                scope, sp->forwards ? (double)sp->tokens / sp->forwards : 0.0,
                (unsigned long long)sp->forwards, (unsigned long long)sp->tokens,
                sp->lk_drafts ? 100.0 * sp->lk_accepted / sp->lk_drafts : 0.0,
                (unsigned long long)sp->lk_accepted, (unsigned long long)sp->lk_drafts,
                (unsigned long long)sp->lk_verifies, sp->gate.off ? "off" : "on",
                (unsigned long long)sp->gate.declined[SPEC_SRC_LOOKUP],
                (unsigned long long)sp->gate.probes[SPEC_SRC_LOOKUP],
                sp->ended_ahead && !m->mtp ? " | ended mid-verify" : "");
}

static Q38Spec g_q38_run_spec;   /* generate()'s, reported by main() */

static void generate(Model *m, const int *prompt, int np, int n_new, int *out) {
    Cfg *c = &m->c;
    /* Same ceiling serve_one() enforces. Past max_position_embeddings the RoPE
     * positions leave the range the model was trained on, so this is a
     * correctness limit, not just a memory one. */
    m->max_t = q38_context_total(c, np, n_new, "generation");
    q38_validate_ids(c, prompt, np, "prompt_ids");
    reset_recurrent(m);
    ensure_kv(m);
    m->kv_len = 0;
    for (int i = 0; i < np; i++) out[i] = prompt[i];
    float *logit = step(m, prompt, np, 0);
    q38_tm_snapshot_prefill(m);        /* COLI_TIMERS: decode bank starts here */
    Q38Spec *sp = &g_q38_run_spec;
    if (m->draft_vocab) draft_vocab_begin(m->draft_vocab, prompt, np, 0);
    *sp = q38_spec_begin(m, prompt, np);   /* Q38_MTP=1, COLI_LOOKUP=1: drafts, every token still the argmax below */
    int len = np;
    for (int s = 0; s < n_new; s++) {
        int best = 0; float bv = logit[0];
        for (int i = 1; i < c->vocab; i++) if (logit[i] > bv) { bv = logit[i]; best = i; }
        if (s == 0 && g_ttft < 0) g_ttft = now_s() - g_gen_t0;   /* record TTFT */
        if (g_stream) { stream_token(best); fflush(stdout); }
        if (s == n_new - 1) {
            if (g_capture_last_logit) {
                g_last_logit = malloc((size_t)c->vocab * sizeof(float));
                if (!g_last_logit) {
                    fprintf(stderr, "OOM capturing Qwen3.8 oracle logits\n"); exit(1);
                }
                memcpy(g_last_logit, logit, (size_t)c->vocab * sizeof(float));
            }
            free(logit); out[len++] = best; break;
        }
        free(logit); out[len++] = best;
        if (m->draft_vocab) draft_vocab_count_token(m->draft_vocab, best);
        logit = q38_spec_step(m, sp, best, len - 1, n_new - 1 - s);
    }
    q38_spec_end(m, sp);
}

static int tf_nll(Model *m, const int *full, int nfull, int np, double *nll_out) {
    Cfg *c = &m->c;
    if (nfull <= np) {
        fprintf(stderr, "PPL requires full_ids to extend prompt_ids\n");
        exit(1);
    }
    m->max_t = q38_context_total(c, np, nfull - np, "PPL");
    q38_validate_ids(c, full, nfull, "full_ids");
    reset_recurrent(m);
    ensure_kv(m);
    m->kv_len = 0;
    double nll = 0; int scored = 0;
    float *logit = step(m, full, np, 0);
    for (int i = np; i < nfull; i++) {
        float mx = logit[0]; for (int v = 1; v < c->vocab; v++) if (logit[v] > mx) mx = logit[v];
        double Z = 0; for (int v = 0; v < c->vocab; v++) Z += exp((double)logit[v] - mx);
        nll += -((double)logit[full[i]] - mx - log(Z));
        scored++;
        free(logit); logit = NULL;
        if (i == nfull - 1) break;
        logit = step(m, &full[i], 1, i);
    }
    if (logit) free(logit);
    *nll_out = nll / scored;
    return scored;
}

static int *read_int_array(jval *o, const char *key, int *n_out) {
    jval *a = json_get(o, key);
    if (!a || a->t != J_ARR) { fprintf(stderr, "ref.json: missing array \"%s\"\n", key); exit(1); }
    if (a->len < 1 || (uint64_t)a->len > SIZE_MAX / sizeof(int)) {
        fprintf(stderr, "ref.json: invalid array length for \"%s\"\n", key); exit(1);
    }
    int *r = malloc((size_t)a->len * sizeof(int));
    if (!r) { fprintf(stderr, "ref.json: OOM reading \"%s\"\n", key); exit(1); }
    for (int i = 0; i < a->len; i++) {
        jval *v = a->kids[i];
        if (!v || v->t != J_NUM || !isfinite(v->num) || v->num < 0 ||
            v->num > INT_MAX || floor(v->num) != v->num) {
            fprintf(stderr, "ref.json: %s[%d] must be a non-negative integer\n", key, i);
            exit(1);
        }
        r[i] = (int)v->num;
    }
    *n_out = a->len; return r;
}

static jval *read_reference_logits(jval *root,int vocab){
    jval *schema=json_get(root,"schema_version");
    if(!schema||schema->t!=J_NUM||!isfinite(schema->num)||
       floor(schema->num)!=schema->num||
       (schema->num!=1.0&&schema->num!=2.0)){
        fprintf(stderr,"ref.json: schema_version must be the supported integer 1 or 2\n");exit(1);
    }
    int requires_logits=schema->num==2.0;
    jval *values=json_get(root,"final_logits");
    if(!values){
        if(requires_logits){
            fprintf(stderr,"ref.json: schema version 2 requires final_logits\n");exit(1);
        }
        return NULL;
    }
    if(values->t!=J_ARR||values->len!=vocab){
        fprintf(stderr,"ref.json: final_logits must contain exactly %d numbers\n",vocab);exit(1);
    }
    for(int i=0;i<values->len;i++){
        jval *value=values->kids[i];
        if(!value||value->t!=J_NUM||!isfinite(value->num)||
           value->num>FLT_MAX||value->num<-FLT_MAX){
            fprintf(stderr,"ref.json: final_logits[%d] must be a finite float\n",i);exit(1);
        }
    }
    return values;
}

static int compare_reference_logits(const float *actual,const jval *expected){
    if(!actual||!expected||expected->t!=J_ARR)return 0;
    double dot=0.0,actual_ss=0.0,expected_ss=0.0,max_abs=0.0,max_ref=0.0;
    for(int i=0;i<expected->len;i++){
        double a=actual[i],b=expected->kids[i]->num;
        if(!isfinite(a)){
            fprintf(stderr,"Numeric oracle: non-finite C logit at %d\n",i);return 0;
        }
        dot+=a*b;actual_ss+=a*a;expected_ss+=b*b;
        double delta=fabs(a-b);if(delta>max_abs)max_abs=delta;
        double magnitude=fabs(b);if(magnitude>max_ref)max_ref=magnitude;
    }
    double cosine=actual_ss>0.0&&expected_ss>0.0?
                  dot/sqrt(actual_ss*expected_ss):(actual_ss==expected_ss?1.0:0.0);
    /* The C path accumulates in FP32 while the released PyTorch oracle carries
     * BF16 activations. Bound both pointwise drift and vector direction. */
    double max_allowed=fmax(0.01,0.02*max_ref);
    int match=cosine>=0.9999&&max_abs<=max_allowed;
    printf("Numeric oracle: cosine=%.8f max_abs=%.6g (limit %.6g) %s\n",
           cosine,max_abs,max_allowed,match?"PASS":"FAIL");
    return match;
}

#if !defined(QWEN38_NO_MAIN) || defined(QWEN38_TEST_SERVE)

/* ===================== coli serve mode (SERVE=1) ===================== *
 * Implements the colibri gateway wire protocol so `coli chat` / `coli web` /
 * `coli serve` can drive this engine. Without it the engine is unreachable:
 * users run `coli chat`, not the binary directly.
 * Protocol (matches kimi_k3.c / inkling.c, the other non-GLM engines):
 *   engine:  \x01\x01READY\x01\x01\n
 *            STAT 0 0.00 0.0 <rss>\n
 *   gateway: SUBMIT <id> <slot> <plen> <max_tok> <temp> <top_p>\n <payload bytes>\n
 *   Qwen3.8 accepts slot 0 only; its single hybrid context is reused when
 *   the next prompt begins with the exact token sequence it already covers.
 *   engine:  ACCEPT <id> <np>\n
 *            DATA <id> <n>\n <bytes>\n     (repeated per decoded chunk)
 *            DONE <id> STAT <gen> <tps> <hit%> <rss> <np> <limited>\n
 *   gateway: CANCEL <id>  (abort current turn)
 * Windows: stdout/stdin must go binary BEFORE the READY sentinel or the CRT
 * rewrites the trailing \n as \r\n and the gateway never matches it -> the
 * session hangs forever (#748). compat.h's coli_serve_binary_mode (#749)
 * carries that fix for every engine; see its comment for the full story. */

typedef struct {
    char id[64];
    int slot;
    int max_tok;
    float temp, top_p;
    char *payload;
    int plen;
    int logprobs, pin;   /* SUBMIT logprobs=k / pin=1 */
} ServeReq;
static const ColiServeWireProfile q38_wire = {
    .max_header_bytes = 511,
    .max_payload_bytes = 1u << 24,
    .max_tokens = 1 << 20,
    .require_exact_lf = 1,
    .require_finite_sampling = 1,
};

/* Returns 2=SUBMIT, 1=STOP(active), 3=CANCEL(active), 0=ignored, -1=EOF/fatal.
 * A SUBMIT encountered during a synchronous turn is consumed and rejected so
 * its payload cannot desynchronize the following control frame. */
/* Un'immagine in attesa del SUBMIT che la usa. Se ne arriva una seconda prima
 * del SUBMIT, la prima viene buttata e lo si dice: rispondere sulla foto
 * precedente senza avvisare sarebbe peggio di rifiutare. */
static struct { unsigned char *patches; uint64_t bytes; int grid_h, grid_w; int present; } g_pending_image;
/* Il modello del turno in corso, per poter rifiutare un'immagine gia' alla
 * lettura del frame invece che dopo averla accettata. */
static Model *g_serve_model;

static void q38_pending_image_clear(void){
    free(g_pending_image.patches);
    memset(&g_pending_image,0,sizeof g_pending_image);
}

/* IMAGE: the patches wait for the SUBMIT they belong to. */
static int q38_serve_take_image(FILE *out,ColiServeCommand *command){
    if(!g_serve_model||!g_serve_model->vis_ready){
        coli_serve_write_error(out,command->id,
            "this engine has no vision tower; images are not supported");
        coli_serve_command_dispose(command);return 0;
    }
    if(g_pending_image.present)
        fprintf(stderr,"[qwen38] a second image arrived before its SUBMIT; dropping the first\n");
    q38_pending_image_clear();
    g_pending_image.patches=coli_serve_command_take_payload(command);
    g_pending_image.bytes=command->payload_bytes;
    g_pending_image.grid_h=command->grid_h;
    g_pending_image.grid_w=command->grid_w;
    g_pending_image.present=1;
    coli_serve_command_dispose(command);return 0;
}

static int serve_read_req(FILE *in,FILE *out,ServeReq *q,const char *active_id){
    ColiServeCommand command;
    ColiServeReadResult result=coli_serve_read_command(in,&q38_wire,&command);
    if(result==COLI_SERVE_READ_EOF||result==COLI_SERVE_READ_BAD_FRAME)return -1;
    if(result==COLI_SERVE_READ_NOMEM){coli_serve_write_error(out,command.id,"out of memory");return -1;}
    if(result==COLI_SERVE_READ_BAD_REQUEST){
        if(command.kind==COLI_SERVE_COMMAND_SUBMIT)
            coli_serve_write_error(out,command.id,"bad submit header");
        coli_serve_command_dispose(&command);return 0;
    }
    if(result!=COLI_SERVE_READ_OK)return 0;
    if(command.kind==COLI_SERVE_COMMAND_STOP||command.kind==COLI_SERVE_COMMAND_CANCEL){
        int active=active_id&&!strcmp(command.id,active_id);
        int control=active?(command.kind==COLI_SERVE_COMMAND_STOP?1:3):0;
        coli_serve_command_dispose(&command);return control;
    }
    if(command.kind==COLI_SERVE_COMMAND_IMAGE)return q38_serve_take_image(out,&command);
    if(command.kind!=COLI_SERVE_COMMAND_SUBMIT){coli_serve_command_dispose(&command);return 0;}
    if(active_id){
        coli_serve_write_error(out,command.id,"engine busy");
        coli_serve_command_dispose(&command);return 0;
    }
    /* Qwen3.8 owns one recurrent/KV state.  The gateway still sends the
     * common cache-slot field, so reject every slot except that sole slot
     * after the codec has consumed the complete frame. */
    if(command.slot!=0){
        coli_serve_write_error(out,command.id,"invalid cache slot");
        coli_serve_command_dispose(&command);return 0;
    }
    if(!q){coli_serve_command_dispose(&command);return 0;}
    snprintf(q->id,sizeof(q->id),"%s",command.id);
    q->slot=command.slot;
    q->max_tok=command.max_tokens;q->temp=command.temperature;q->top_p=command.top_p;
    q->payload=(char*)coli_serve_command_take_payload(&command);q->plen=(int)command.payload_bytes;
    q->logprobs=command.logprobs;q->pin=command.pin;
    coli_serve_command_dispose(&command);return 2;
}

static void serve_data(const char *id, const char *p, int n){
    if(n<=0) return;
    printf("DATA %s %d\n",id,n);
    fwrite(p,1,(size_t)n,stdout); fputc('\n',stdout); fflush(stdout);
}

/* Come serve_data ma con la coda numerica del canale logprobs. Emette anche a
 * n==0: un token che non chiude un carattere UTF-8 ha comunque il suo logprob,
 * e perderlo bucherebbe la sequenza proprio dove il conto deve tornare. */
static void serve_data_lp(const char *id, const char *p, int n, const char *tail){
    if(n<0) n=0;
    printf("DATA %s %d%s\n",id,n,tail?tail:"");
    if(n>0) fwrite(p,1,(size_t)n,stdout);
    fputc('\n',stdout); fflush(stdout);
}

/* temperature + top-p sampler. The nucleus is the head of the probabilities in
 * descending order (ties by id), and the tokens at or above a threshold are such a
 * head: when their mass covers top_p only they are sorted, else the threshold goes
 * down. A full qsort of the ~250k vocabulary per token took ~22 ms on one thread, 2-3
 * tokens a forward with MTP: most of a chat's time beyond the forward at temperature
 * > 0. The same probabilities, the same head in the same order, the same draw. With
 * top_p >= 1 there is no nucleus: the draw walks the vocabulary in id order (the same
 * distribution, without the sort). */
typedef struct { float p; int id; } SampleProb;
static int sample_prob_desc(const void *a, const void *b){
    const SampleProb *x=(const SampleProb*)a,*y=(const SampleProb*)b;
    if(x->p!=y->p) return x->p>y->p?-1:1;
    return (x->id>y->id)-(x->id<y->id);
}
static int serve_sample(const float *lo, int V, float temp, float top_p){
    if(temp<=0.f) return argmax_first(lo, V);
    float *p=malloc((size_t)V*sizeof(float)); SampleProb *head=malloc((size_t)V*sizeof(SampleProb)); float mx=lo[0];
    if(!p||!head){ fprintf(stderr,"OOM sampling\n"); exit(1); }
    for(int i=1;i<V;i++) if(lo[i]>mx) mx=lo[i];
    double sum=0;
    for(int i=0;i<V;i++){ p[i]=expf((lo[i]-mx)/temp); sum+=p[i]; }
    int pick=0;
    if(!(top_p>0.f&&top_p<1.f)){
        double r=((double)rand()/RAND_MAX)*sum, acc=0; pick=V-1;
        for(int i=0;i<V;i++){ acc+=p[i]; if(acc>=r){ pick=i; break; } }
    } else {
        const double cut=top_p*sum; const float ths[3]={1e-4f,1e-9f,0.f};
        double kept=0; int n=0;
        for(int a=0;a<3;a++){
            int m=0;
            for(int i=0;i<V;i++) if(p[i]>=ths[a]) head[m++]=(SampleProb){p[i],i};
            qsort(head,(size_t)m,sizeof(SampleProb),sample_prob_desc);
            kept=0; n=0;
            while(n<m&&kept<cut) kept+=head[n++].p;
            if(kept>=cut||m==V) break;           /* else the nucleus reaches below the threshold */
        }
        double r=((double)rand()/RAND_MAX)*kept, acc=0; pick=head[0].id;
        for(int i=0;i<n;i++){ acc+=head[i].p; if(acc>=r){ pick=head[i].id; break; } }
    }
    free(p); free(head); return pick;
}

/* Chat turns end on <|im_end|>, base completions on <|endoftext|>. Resolve
 * both ids from the tokenizer's added_tokens: Qwen3.8's 248320-token vocab
 * puts them at 248044+, so the old hardcoded 151645 (the 151k-vocab Qwen id)
 * silently never matched and every serve turn ran into max_tok. Q38_EOS
 * still overrides for experiments. */
static int serve_eos_ids(int *ids,int cap,int config_eos,int vocab){
    int n=0;
    const char *override=getenv("Q38_EOS");
    if(override){
        char *end=NULL;errno=0;long value=strtol(override,&end,10);
        if(errno||end==override||*end||value<0||value>=vocab){
            fprintf(stderr,"Q38_EOS must be an integer in [0,%d)\n",vocab);exit(1);
        }
        ids[n++]=(int)value;return n;
    }
    for(int k=0;k<g_nspecial && n<cap;k++)
        if(!strcmp(g_sp_str[k],"<|im_end|>")||!strcmp(g_sp_str[k],"<|endoftext|>"))
            ids[n++]=g_sp_id[k];
    if(!n && config_eos>=0) ids[n++]=config_eos;
    return n;
}

/* ---------- one-slot hybrid prompt prefix -----------------------------
 *
 * Qwen3.8 has two different kinds of state.  DeltaNet and PLE carry a
 * recurrent state which generation mutates in place; QSA carries position-
 * indexed K/V/index rows which are append-only.  A prompt cache therefore
 * keeps a bounded snapshot of only the recurrent state and leaves the QSA
 * rows in the model's existing buffers.  Generation writes rows strictly
 * after the cached prompt, so those rows remain valid for the next turn.
 *
 * There is deliberately one process-local cache: the Qwen serve ABI exposes
 * one slot and the serve loop owns one Model.  This is not a second KV cache
 * and cannot grow with the number of requests.  The snapshot is published
 * only after the complete prompt has been evaluated; a cancelled/stopped
 * decode consequently cannot damage the prompt state that follows it. */
typedef struct {
    Model *owner;
    int valid;
    int layers;
    int vocab;
    size_t rec_cells;
    size_t conv_cells;
    size_t ple_cells;
    int *ids;
    int id_cap;
    int len;
    int pinned;     /* fotografia chiesta con SUBMIT pin=1: la tengono le
                     * richieste che la estendono, invece di sovrascriverla.
                     * Senza questo la seconda opzione di un menu cancella la
                     * fotografia costruita dalla prima e ogni opzione rifa il
                     * prompt intero: il riuso ci sarebbe ma non scatterebbe
                     * mai. */
    float *logits;
    float **dn_rec;
    float **dn_conv;
    float *ple_conv;
    int64_t ple_history[2];
    int ple_history_len;
    /* the MTP head where the prompt left it: its settled rows and the
     * streams still waiting for their next token (Model.mtp_*) */
    float *mtp_pend;
    int mtp_len, mtp_pend_n, mtp_pend_tok[Q38_SPEC_ROWS];
} Q38PrefixCache;

static Q38PrefixCache g_q38_prefix;

/* La cache automatica sopra resta quella della chat: una sola, riscritta a
 * ogni prompt. Accanto sta un pool di scatti CHIESTI (SUBMIT pin=1), che non
 * si sovrascrivono a vicenda: i prefissi utili a un insieme chiuso sono
 * annidati (istruzioni, istruzioni+domanda) e con uno solo se ne perde sempre
 * uno. Due meccanismi separati perche' hanno due politiche diverse: uno
 * insegue l'ultimo prompt, l'altro tiene i punti di ritorno che il client ha
 * dichiarato. Vedi pin_pool.h. */
static int q38_prefix_geometry(const Model *m,size_t *rec_cells,
                               size_t *conv_cells,size_t *ple_cells);
static ColiPinPool g_q38_pins;
typedef struct { float **rec, **conv, *ple; int64_t ple_hist[2]; int ple_len; int n_layers;
                 float *mtp_pend; int mtp_len, mtp_pend_n, mtp_pend_tok[Q38_SPEC_ROWS]; } Q38PinState;

/* The MTP head's place in the sequence travels with every snapshot of the
 * recurrent state: its KV rows below mtp_len stay valid wherever the
 * model's rows do (the head only writes a row together with the row
 * after it), and the pending streams are what lets the next prompt's
 * first token reach it. */
static void q38_mtp_state_copy(Model *m, float *pend, int *len, int *pend_n,
                               int *pend_tok, int to_state){
    if(!m->mtp||!pend) return;
    size_t bytes=(size_t)Q38_SPEC_ROWS*m->c.hc_width*sizeof(float);
    size_t toks=(size_t)Q38_SPEC_ROWS*sizeof(int);
    if(to_state){
        memcpy(pend,m->mtp_pend,bytes);
        *len=m->mtp_len; *pend_n=m->mtp_pend_n; memcpy(pend_tok,m->mtp_pend_tok,toks);
    } else {
        memcpy(m->mtp_pend,pend,bytes);
        m->mtp_len=*len; m->mtp_pend_n=*pend_n; memcpy(m->mtp_pend_tok,pend_tok,toks);
    }
}

static void q38_pin_state_free(void *v){
    Q38PinState *st = (Q38PinState *)v;
    if (!st) return;
    for (int i = 0; i < st->n_layers; i++){
        if (st->rec)  free(st->rec[i]);
        if (st->conv) free(st->conv[i]);
    }
    free(st->rec); free(st->conv); free(st->ple); free(st->mtp_pend); free(st);
}

/* Copia la ricorrenza DeltaNet (piu le righe PLE) fra motore e scatto. */
static int q38_pin_state_copy(Model *m, Q38PinState **slot, int to_state){
    const Cfg *c = &m->c;
    size_t rec = 0, conv = 0, ple = 0;
    if (to_state) q38_dn_gpu_pull_all(m);   /* the card may be ahead of the host copy */
#ifdef COLI_VULKAN
    if (to_state) q38c_sync_host(m);   /* the dense chain keeps the newest state on the device */
#endif
#ifdef COLI_CUDA
    if (to_state) q38cc_sync_host(m);
#endif
    if (!q38_prefix_geometry(m, &rec, &conv, &ple)) return 0;
    Q38PinState *st = *slot;
    if (st && st->n_layers != c->layers){ q38_pin_state_free(st); st = NULL; }
    if (!st){
        if (!to_state) return 0;
        st = (Q38PinState *)calloc(1, sizeof(*st));
        if (!st) return 0;
        st->n_layers = c->layers;
        st->rec  = (float**)calloc((size_t)c->layers, sizeof(float*));
        st->conv = (float**)calloc((size_t)c->layers, sizeof(float*));
        if (!st->rec || !st->conv){ q38_pin_state_free(st); return 0; }
        for (int i = 0; i < c->layers; i++){
            if (c->is_attn[i]) continue;
            st->rec[i]  = (float*)malloc(rec * sizeof(float));
            st->conv[i] = (float*)malloc(conv * sizeof(float));
            if (!st->rec[i] || !st->conv[i]){ q38_pin_state_free(st); return 0; }
        }
        if (ple){
            st->ple = (float*)malloc(ple * sizeof(float));
            if (!st->ple){ q38_pin_state_free(st); return 0; }
        }
        if (m->mtp){
            st->mtp_pend = (float*)malloc((size_t)Q38_SPEC_ROWS * c->hc_width * sizeof(float));
            if (!st->mtp_pend){ q38_pin_state_free(st); return 0; }
        }
        *slot = st;
    }
    for (int i = 0; i < c->layers; i++){
        if (c->is_attn[i] || !st->rec[i]) continue;
        if (to_state){
            memcpy(st->rec[i],  m->DN_rec[i],  rec * sizeof(float));
            memcpy(st->conv[i], m->DN_conv[i], conv * sizeof(float));
        } else {
            memcpy(m->DN_rec[i],  st->rec[i],  rec * sizeof(float));
            memcpy(m->DN_conv[i], st->conv[i], conv * sizeof(float));
        }
    }
    if (ple && st->ple){
        if (to_state){
            memcpy(st->ple, m->PLE_conv_state, ple * sizeof(float));
            st->ple_len = m->ple_history_len;
            memcpy(st->ple_hist, m->ple_history, sizeof(st->ple_hist));
        } else {
            memcpy(m->PLE_conv_state, st->ple, ple * sizeof(float));
            m->ple_history_len = st->ple_len;
            memcpy(m->ple_history, st->ple_hist, sizeof(st->ple_hist));
        }
    }
    q38_mtp_state_copy(m, st->mtp_pend, &st->mtp_len, &st->mtp_pend_n, st->mtp_pend_tok, to_state);
    if (!to_state) q38_dn_gpu_invalidate(m);   /* restored on the host: the card's copy is from another prompt */
#ifdef COLI_VULKAN
    if (!to_state) q38c_host_wrote(m, 0);   /* up to the device before the next chain step */
#endif
#ifdef COLI_CUDA
    if (!to_state) q38cc_host_wrote(m, 0);
#endif
    return 1;
}

static int q38_size_mul(size_t left,size_t right,size_t *out){
    if(!out||(right&&left>SIZE_MAX/right))return 0;
    *out=left*right;return 1;
}

static int q38_prefix_geometry(const Model *m,size_t *rec_cells,
                               size_t *conv_cells,size_t *ple_cells){
    if(!m||!rec_cells||!conv_cells||!ple_cells||m->c.layers<1||
       m->c.layers>Q38_MAX_LAYERS||m->c.vocab<1||!m->c.is_attn)return 0;
    const Cfg *c=&m->c;size_t rec=0,conv=0,ple=0,cells=0;
    if(c->dn_vheads<=0||c->dn_kdim<=0||c->dn_vdim<=0||
       c->dn_conv_dim<=0||c->dn_convk<2)return 0;
    if(!q38_size_mul((size_t)c->dn_vheads,(size_t)c->dn_kdim,&cells)||
       !q38_size_mul(cells,(size_t)c->dn_vdim,&cells))return 0;
    rec=cells;
    if(!q38_size_mul((size_t)c->dn_conv_dim,(size_t)(c->dn_convk-1),&cells))return 0;
    conv=cells;
    if(c->ple_layer>=0&&c->ple_layer<c->layers){
        if(c->hc_width<=0||c->ple_convk<2||c->ngram_size<=0||
           !q38_size_mul((size_t)c->hc_width,(size_t)(c->ple_convk-1),&cells)||
           !q38_size_mul(cells,(size_t)c->ngram_size,&ple))return 0;
        if(!m->PLE_conv_state||!m->ple_history)return 0;
    }
    *rec_cells=rec;*conv_cells=conv;*ple_cells=ple;return 1;
}

static void q38_prefix_cache_dispose(Q38PrefixCache *cache){
    if(!cache)return;
    if(cache->dn_rec)for(int i=0;i<cache->layers;i++)free(cache->dn_rec[i]);
    if(cache->dn_conv)for(int i=0;i<cache->layers;i++)free(cache->dn_conv[i]);
    free(cache->dn_rec);free(cache->dn_conv);free(cache->ple_conv);free(cache->mtp_pend);
    free(cache->ids);free(cache->logits);memset(cache,0,sizeof(*cache));
}

static void q38_prefix_cache_invalidate(void){
    g_q38_prefix.valid=0;g_q38_prefix.len=0;g_q38_prefix.pinned=0;
}

static int q38_prefix_cache_layout(Model *m){
    if(!m)return 0;
    size_t rec=0,conv=0,ple=0;
    if(!q38_prefix_geometry(m,&rec,&conv,&ple))return 0;
    if(g_q38_prefix.owner!=m||g_q38_prefix.layers!=m->c.layers||
       g_q38_prefix.vocab!=m->c.vocab||g_q38_prefix.rec_cells!=rec||
       g_q38_prefix.conv_cells!=conv||g_q38_prefix.ple_cells!=ple){
        q38_prefix_cache_dispose(&g_q38_prefix);g_q38_prefix.owner=m;
        g_q38_prefix.layers=m->c.layers;g_q38_prefix.vocab=m->c.vocab;
        g_q38_prefix.rec_cells=rec;g_q38_prefix.conv_cells=conv;
        g_q38_prefix.ple_cells=ple;
    }
    if(m->mtp&&!g_q38_prefix.mtp_pend){
        g_q38_prefix.mtp_pend=(float*)malloc((size_t)Q38_SPEC_ROWS*m->c.hc_width*sizeof(float));
        if(!g_q38_prefix.mtp_pend){q38_prefix_cache_dispose(&g_q38_prefix);return 0;}
    }
    if(g_q38_prefix.dn_rec&&g_q38_prefix.dn_conv&&g_q38_prefix.logits&&
       (!ple||g_q38_prefix.ple_conv))return 1;
    size_t logits_bytes=0;
    if(!q38_size_mul((size_t)m->c.vocab,sizeof(float),&logits_bytes))return 0;
    g_q38_prefix.dn_rec=(float**)calloc((size_t)m->c.layers,sizeof(float*));
    g_q38_prefix.dn_conv=(float**)calloc((size_t)m->c.layers,sizeof(float*));
    g_q38_prefix.logits=(float*)malloc(logits_bytes);
    if(!g_q38_prefix.dn_rec||!g_q38_prefix.dn_conv||!g_q38_prefix.logits){
        q38_prefix_cache_dispose(&g_q38_prefix);return 0;
    }
    for(int i=0;i<m->c.layers;i++)if(!m->c.is_attn[i]){
        if(!m->DN_rec[i]||!m->DN_conv[i]||
           (g_q38_prefix.rec_cells>SIZE_MAX/sizeof(float))||
           (g_q38_prefix.conv_cells>SIZE_MAX/sizeof(float)))
            {q38_prefix_cache_dispose(&g_q38_prefix);return 0;}
        g_q38_prefix.dn_rec[i]=(float*)malloc(g_q38_prefix.rec_cells*sizeof(float));
        g_q38_prefix.dn_conv[i]=(float*)malloc(g_q38_prefix.conv_cells*sizeof(float));
        if(!g_q38_prefix.dn_rec[i]||!g_q38_prefix.dn_conv[i]){
            q38_prefix_cache_dispose(&g_q38_prefix);return 0;
        }
    }
    if(ple){
        if(g_q38_prefix.ple_cells>SIZE_MAX/sizeof(float)){
            q38_prefix_cache_dispose(&g_q38_prefix);return 0;
        }
        g_q38_prefix.ple_conv=(float*)malloc(g_q38_prefix.ple_cells*sizeof(float));
        if(!g_q38_prefix.ple_conv){q38_prefix_cache_dispose(&g_q38_prefix);return 0;}
    }
    return 1;
}

static int q38_prefix_ids_reserve(int len){
    if(len<1||(size_t)len>SIZE_MAX/sizeof(int))return 0;
    if(g_q38_prefix.ids&&len<=g_q38_prefix.id_cap)return 1;
    size_t bytes=(size_t)len*sizeof(int);int *ids=(int*)malloc(bytes);
    if(!ids)return 0;
    if(g_q38_prefix.ids&&g_q38_prefix.len>0)
        memcpy(ids,g_q38_prefix.ids,(size_t)g_q38_prefix.len*sizeof(int));
    free(g_q38_prefix.ids);g_q38_prefix.ids=ids;g_q38_prefix.id_cap=len;return 1;
}

static void q38_prefix_copy_state(Model *m,int to_cache){
    if(to_cache)q38_dn_gpu_pull_all(m); else q38_dn_gpu_invalidate(m);
#ifdef COLI_VULKAN
    if(to_cache)q38c_sync_host(m);
    else q38c_host_wrote(m,0);
#endif
#ifdef COLI_CUDA
    if(to_cache)q38cc_sync_host(m);
    else q38cc_host_wrote(m,0);
#endif
    for(int i=0;i<m->c.layers;i++)if(!m->c.is_attn[i]){
        float *rec=to_cache?g_q38_prefix.dn_rec[i]:m->DN_rec[i];
        float *conv=to_cache?g_q38_prefix.dn_conv[i]:m->DN_conv[i];
        const float *src_rec=to_cache?m->DN_rec[i]:g_q38_prefix.dn_rec[i];
        const float *src_conv=to_cache?m->DN_conv[i]:g_q38_prefix.dn_conv[i];
        memcpy(rec,src_rec,g_q38_prefix.rec_cells*sizeof(float));
        memcpy(conv,src_conv,g_q38_prefix.conv_cells*sizeof(float));
    }
    if(g_q38_prefix.ple_cells){
        if(to_cache){
            memcpy(g_q38_prefix.ple_conv,m->PLE_conv_state,
                   g_q38_prefix.ple_cells*sizeof(float));
            g_q38_prefix.ple_history_len=m->ple_history_len;
            memcpy(g_q38_prefix.ple_history,m->ple_history,sizeof(g_q38_prefix.ple_history));
        }else{
            memcpy(m->PLE_conv_state,g_q38_prefix.ple_conv,
                   g_q38_prefix.ple_cells*sizeof(float));
            m->ple_history_len=g_q38_prefix.ple_history_len;
            memcpy(m->ple_history,g_q38_prefix.ple_history,sizeof(g_q38_prefix.ple_history));
        }
    }
    q38_mtp_state_copy(m,g_q38_prefix.mtp_pend,&g_q38_prefix.mtp_len,&g_q38_prefix.mtp_pend_n,
                       g_q38_prefix.mtp_pend_tok,to_cache);
}

static int q38_prefix_cache_save(Model *m,const int *ids,int len,const float *logits,
                                 int pinned){
    if(!m||!ids||len<1||!logits||!q38_prefix_cache_layout(m)||
       !q38_prefix_ids_reserve(len))return 0;
    memcpy(g_q38_prefix.ids,ids,(size_t)len*sizeof(int));
    memcpy(g_q38_prefix.logits,logits,(size_t)m->c.vocab*sizeof(float));
    q38_prefix_copy_state(m,1);g_q38_prefix.len=len;g_q38_prefix.valid=1;
    g_q38_prefix.pinned=pinned;return 1;
}

/* Restore only when the complete cached prompt is an exact prefix.  A shorter
 * request would require rewinding append-only QSA rows and is therefore a
 * safe miss; equality is useful because the saved prompt logits let the
 * caller enter decode without feeding the final prompt token twice. */
static int q38_prefix_restore(Model *m,const int *ids,int len){
    if(!m||!ids||len<1||!g_q38_prefix.valid||g_q38_prefix.owner!=m||
       g_q38_prefix.len<1||g_q38_prefix.len>len||
       memcmp(g_q38_prefix.ids,ids,(size_t)g_q38_prefix.len*sizeof(int))||
       !kv_prefix_holds(&m->kvp,g_q38_prefix.ids,g_q38_prefix.len))return 0;
    q38_prefix_copy_state(m,0);m->kv_len=g_q38_prefix.len;
    m->kvp.len=g_q38_prefix.len;return g_q38_prefix.len;
}

static const float *q38_prefix_cached_logits(Model *m){
    return m&&g_q38_prefix.valid&&g_q38_prefix.owner==m?g_q38_prefix.logits:NULL;
}

static void q38_prefix_cache_release(Model *m){
    if(!m||g_q38_prefix.owner!=m)return;
    q38_prefix_cache_dispose(&g_q38_prefix);
}

/* Allocate the complete served QSA bank once, before READY.  Prefix reuse
 * relies on append-only position rows; one planned allocation both preserves
 * those rows and avoids a growth peak containing the old and new banks at the
 * same time.  An initialized serve model is therefore never grown in place. */
static int q38_serve_ensure_kv(Model *m,int capacity){
    if(!m||capacity<1)return 0;
    if(m->kv_cap>0)return m->K&&m->kv_cap>=capacity;
    m->max_t=capacity;ensure_kv(m);
    return m->K&&m->kv_cap>=capacity;
}

static double q38_cache_hit_percent(uint64_t hits,uint64_t misses){
    double total=(double)hits+(double)misses;
    return total?100.0*(double)hits/total:0.0;
}

static int q38_format_prof(char *out,size_t capacity,double wall_s,int prompt_tokens,
                            int completion_tokens,const Q38Timers *timers){
    double expert_read=timers->seconds[Q38_TM_EXPERT_READ];
    double fp8_expand=timers->seconds[Q38_TM_FP8_EXPAND];
    double expert_compute=timers->seconds[Q38_TM_ROUTED_EXPERT]+
                          timers->seconds[Q38_TM_SHARED_EXPERT];
    double attention=timers->seconds[Q38_TM_DELTANET]+
                     timers->seconds[Q38_TM_QSA_INDEX]+
                     timers->seconds[Q38_TM_QSA_ATTENTION];
    int count=snprintf(out,capacity,
        "PROF %.3f %d %d %.3f %.3f %.3f %.3f %.3f %llu\n",
        wall_s,prompt_tokens,completion_tokens,expert_read,
        expert_read+fp8_expand,expert_compute,attention,
        timers->seconds[Q38_TM_LM_HEAD],
        (unsigned long long)timers->forwards);
    return count>=0&&(size_t)count<capacity?count:-1;
}

/* ---------- dashboard protocol: EMAP / HITS ----------
 * Same stdout lines colibri.c emits for the web dashboard's Brain tab. Every
 * layer here is a MoE layer, so rows are all layers, columns the experts.
 * EMAP: one byte per expert as two hex digits, tier<<6 | heat (tier 1 =
 * resident in the layer cache; heat 0, no usage counter here). Printed after
 * READY and STAT, and again after every turn. HITS: one bit per expert routed
 * in the turn, packed 8 per hex pair, printed after DONE next to PROF. */
static void serve_emap(Model *m){
    const Cfg *c=&m->c; int E=c->experts, rows=c->layers;
    char *hex=(char*)malloc((size_t)rows*E*2+1); int w=0;
    for(int i=0;i<rows;i++){
        LCache *lc=&m->cache[i];
        for(int e=0;e<E;e++){
            int si=lc->by_expert?lc->by_expert[e]:-1;
            int b=(vkt_resident(i,e)?2:si>=0&&si<lc->n&&lc->slots[si].eid==e?1:0)<<6;   /* 2 = on the Vulkan device */
            hex[w++]="0123456789abcdef"[b>>4]; hex[w++]="0123456789abcdef"[b&15];
        }
    }
    hex[w]=0;
    printf("EMAP %d %d %s\n",rows,E,hex); fflush(stdout); free(hex);
}
static void serve_hits(Model *m){
    const Cfg *c=&m->c; int E=c->experts, rows=c->layers;
    if(!m->ehit)q38_ehit_mark(m,-1,-1);   /* a turn that routed nothing still reports a bitmap: all zero */
    int nb=(rows*E+7)/8; uint8_t *bm=(uint8_t*)calloc((size_t)nb,1); int bit=0;
    for(int i=0;i<rows;i++)
        for(int e=0;e<E;e++,bit++)
            if(m->ehit[i][e]){ bm[bit>>3]|=(uint8_t)(1<<(bit&7)); m->ehit[i][e]=0; }
    char *hex=(char*)malloc((size_t)nb*2+1); int w=0;
    for(int b=0;b<nb;b++){ hex[w++]="0123456789abcdef"[bm[b]>>4]; hex[w++]="0123456789abcdef"[bm[b]&15]; }
    hex[w]=0;
    printf("HITS %d %d %s\n",rows,E,hex); fflush(stdout); free(hex); free(bm);
}

/* The generation budget a request gets. max_tokens is a CEILING, not a
 * target (#260/#382, the rule GLM and DeepSeek V4 already apply): the prompt
 * must fit with room for one token (none for a read-only logprobs request,
 * docs/systemone.md), and the budget is then clamped to what the context can hold.
 * Returns the budget, or -1 when the PROMPT does not fit. Refusing when
 * prompt + budget exceeded the context (#1641) turned the gateway's default
 * output budget -- 8192 here, the whole default context -- into a 400 on
 * every message of `coli chat` and on every request without max_tokens. */
static int q38_serve_budget(int np, int max_tok, int max_ctx, int read_only){
    if (np < 1) return -1;
    int room = max_ctx - np;
    if (read_only) return room < 0 ? -1 : (max_tok < room ? max_tok : room);
    if (room < 1) return -1;
    return max_tok > room ? room : max_tok;
}

/* When a request was accepted, and the counters then: the DONE and PROF frames
 * report the request's share from them. */
typedef struct { double started; uint64_t hits, misses; Q38Timers timers; } Q38ReqClock;

/* A request's prompt into the conversation the Model holds: its tokens and image,
 * the budget, ACCEPT, the pins and the prefix cache, the prefill and its read-out.
 * 1 with the prompt's ids and the logits after it; 0 when the request ended here,
 * its ERROR frame written. serve_one and serve_mux start every request here. */
/* A served prompt in segments, so that a STOP or CANCEL arriving while it is read stops the
 * reading instead of waiting for its end (a 40,000-token prompt took about 17 minutes on an
 * 8-core CPU, and a client that gave up kept the engine busy all that time).
 *
 * Between two segments the state is the prompt read so far, recorded in the kv_prefix as any
 * step leaves it, so a request that sends the same conversation again reuses all of it. On
 * the CPU's layers the control is also polled before every layer (g_q38_breaker): a stop
 * there puts back the recurrent state copied at the segment's start, and the rows the segment
 * wrote are a stale tail. Segment boundaries change no result: the attention rows, the
 * DeltaNet recurrence and the MoE routing are per row and in row order (qwen38_core.h).
 *
 * A chain takes segments of 8192 rows, the size of its own layer-by-layer segments, and checks
 * between two layers (layer by layer) or two chunks inside them; it then declines the step,
 * the CPU's loop sees the stop before its first layer, and the copy goes back here too. An
 * echo (logprobs) and a prompt with an image are read in one call, as before.
 * COLI_PROMPT_SEGMENT sets the rows (2048 on the CPU, 8192 for a chain). */
static int q38_prompt_poll(ColiPromptBreak *b){   /* control: 1 STOP, 3 CANCEL (serve_read_req) */
    while(!b->control&&!b->eof&&coli_stdin_readable()){
        int r=serve_read_req(stdin,stdout,NULL,b->id);
        if(r<0)b->eof=1;
        else if(r==1||r==3)b->control=r;
    }
    return b->control!=0;
}
/* ids[from..np) at position from. NULL when a control stopped it (ctl->control says which).
 * ctl NULL (the multiplexed loop, which owns its command stream): the same segments, no poll.
 * One forward holds a segment's rows, never the context's: the planner prices that
 * (family_registry.py, _qwen38_prompt_rows). */
static float *q38_serve_prefill(Model *m,const int *ids,int from,int np,ColiPromptBreak *ctl){
    int chain=0;
#ifdef COLI_VULKAN
    chain|=g_vk_chain!=0;
#endif
#ifdef COLI_CUDA
    chain|=g_cuda_chain!=0;
#endif
    if(g_echo_k>0||(m->vis_map&&m->vis_rows_n>0))return step(m,ids+from,np-from,from);
    /* a chain's segment is the one its own layer-by-layer prompt takes (q38cc_lm_rows), so it
     * does the same work as when it took the prompt in one call */
    const int seg=coli_prompt_segment_rows(chain?8192:2048);
    if(!ctl){
        float *lo=NULL;
        for(int at=from;at<np;){
            int n=np-at<seg?np-at:seg;
            float *next=step(m,ids+at,n,at);
            free(lo);lo=next;
            if(!next)break;
            at+=n;
        }
        return lo;
    }
    Q38PinState *st=NULL;
    float *lo=NULL;
    for(int at=from;at<np;){
        if(coli_prompt_poll(ctl)){free(lo);lo=NULL;break;}
        int n=np-at<seg?np-at:seg;
        /* the state at the segment's start (from the device too, for a chain), so a stop inside
         * the segment can put it back */
        if(q38_pin_state_copy(m,&st,1))g_coli_prompt_break=ctl;
        float *next=step(m,ids+at,n,at);
        g_coli_prompt_break=NULL;
        if(!next){q38_pin_state_copy(m,&st,0);free(lo);lo=NULL;break;}
        free(lo);lo=next;at+=n;
    }
    q38_pin_state_free(st);
    return lo;
}

/* ---- a long conversation parked for a short request -------------------------------- */
/* A client's short request between two turns of a conversation (Hermes asks for its title
 * after the first) leaves the conversation after a few tokens and would take the only state
 * there is: the conversation's next turn then reads every token again (Qwen3.8 IQ2_XS on the
 * CUDA chain: 14,785 tokens, 86 s). The conversation is parked instead: its tokens, its
 * recurrent state (a pin's copy) and the K/V and index rows the request may write over; the
 * request runs from the start; when its turn ends the conversation is back as it was, and its
 * next turn reads only what is new. One conversation at a time (serve_one), a held one of at
 * least Q38_PARK_MIN tokens (COLI_PARK_MIN sets another), a request shorter than it with what
 * it may write; COLI_PARK=0 never parks. */
#define Q38_PARK_MIN 1024
#define Q38_PARK_GEN 4096    /* the request's tokens whose rows are kept apart: past them it is not a short one */
static struct { int on, len, kv_len, rows, nl; int *fed; Q38PinState *st; float **K, **V, **IK;
                Q38PrefixCache snap; } g_q38_park;   /* snap: the conversation's prompt-end snapshot, kept too */

static void q38_park_free_rows(void){
    for(int i=0;i<g_q38_park.nl;i++){
        if(g_q38_park.K)free(g_q38_park.K[i]);
        if(g_q38_park.V)free(g_q38_park.V[i]);
        if(g_q38_park.IK)free(g_q38_park.IK[i]);
    }
    free(g_q38_park.K);free(g_q38_park.V);free(g_q38_park.IK);free(g_q38_park.fed);
    g_q38_park.K=g_q38_park.V=g_q38_park.IK=NULL;g_q38_park.fed=NULL;g_q38_park.nl=0;g_q38_park.on=0;
}
/* rows [0, n) of an attention layer's K, V (head by head) and index keys, between the cache and a copy */
static void q38_park_rows(Model *m,int i,int n,int out){
    const Cfg *c=&m->c;const size_t D=(size_t)c->head_dim,ID=(size_t)c->idx_dim;
    for(int h=0;h<c->kv_heads;h++){
        float *k=m->K[i]+(size_t)h*m->kv_cap*D,*v=m->V[i]+(size_t)h*m->kv_cap*D;
        float *pk=g_q38_park.K[i]+(size_t)h*n*D,*pv=g_q38_park.V[i]+(size_t)h*n*D;
        if(out){memcpy(pk,k,(size_t)n*D*sizeof(float));memcpy(pv,v,(size_t)n*D*sizeof(float));}
        else{memcpy(k,pk,(size_t)n*D*sizeof(float));memcpy(v,pv,(size_t)n*D*sizeof(float));}
    }
    if(out)memcpy(g_q38_park.IK[i],m->IK[i],(size_t)n*ID*sizeof(float));
    else memcpy(m->IK[i],g_q38_park.IK[i],(size_t)n*ID*sizeof(float));
}
static void q38_park(Model *m,int np,int max_tok){
    const char *e=getenv("COLI_PARK"),*mn=getenv("COLI_PARK_MIN");
    const int H=m->kvp.len,gen=max_tok<Q38_PARK_GEN?max_tok:Q38_PARK_GEN,least=mn&&atoi(mn)>0?atoi(mn):Q38_PARK_MIN;
    if((e&&*e=='0')||g_q38_park.on||!m->kvp.fed||m->kvp.tainted||H<least||m->kv_len!=H||
       g_pending_image.present||np+gen+Q38_SPEC_ROWS>=H)return;
    const Cfg *c=&m->c;const int L=q38_layer_rows(m),n=np+gen+Q38_SPEC_ROWS;
    const size_t D=(size_t)c->head_dim,ID=(size_t)c->idx_dim;
    g_q38_park.nl=L;
    g_q38_park.K=(float**)calloc((size_t)L,sizeof(float*));g_q38_park.V=(float**)calloc((size_t)L,sizeof(float*));
    g_q38_park.IK=(float**)calloc((size_t)L,sizeof(float*));g_q38_park.fed=(int*)malloc((size_t)H*sizeof(int));
    int ok=g_q38_park.K&&g_q38_park.V&&g_q38_park.IK&&g_q38_park.fed;
    for(int i=0;ok&&i<L;i++){
        if(!m->K[i])continue;
        g_q38_park.K[i]=(float*)malloc((size_t)c->kv_heads*n*D*sizeof(float));
        g_q38_park.V[i]=(float*)malloc((size_t)c->kv_heads*n*D*sizeof(float));
        g_q38_park.IK[i]=(float*)malloc((size_t)n*ID*sizeof(float));
        ok=g_q38_park.K[i]&&g_q38_park.V[i]&&g_q38_park.IK[i];
        if(ok)q38_park_rows(m,i,n,1);
    }
    /* the recurrent state from the device too, before anything of the request runs */
    ok=ok&&q38_pin_state_copy(m,&g_q38_park.st,1);
    if(!ok){q38_park_free_rows();return;}
    memcpy(g_q38_park.fed,m->kvp.fed,(size_t)H*sizeof(int));
    g_q38_park.len=H;g_q38_park.kv_len=m->kv_len;g_q38_park.rows=n;g_q38_park.on=1;
    g_q38_park.snap=g_q38_prefix;memset(&g_q38_prefix,0,sizeof g_q38_prefix);   /* the request takes a snapshot of its own */
    if(getenv("COLI_PREFIX_LOG"))
        fprintf(stderr,"[PREFIX] the %d-token conversation parked for a %d-token request (%d rows kept apart)\n",H,np,n);
}
/* the end of the request's turn: the conversation back, its tokens, state and rows; the chains
 * read its rows and state from the host again */
static void q38_unpark(Model *m){
    if(!g_q38_park.on)return;
    q38_prefix_cache_dispose(&g_q38_prefix);   /* the request's snapshot; the conversation's comes back below */
    g_q38_prefix=g_q38_park.snap;memset(&g_q38_park.snap,0,sizeof g_q38_park.snap);
    if(m->kv_len+Q38_SPEC_ROWS>g_q38_park.rows||m->kv_cap<g_q38_park.len){
        if(getenv("COLI_PREFIX_LOG"))
            fprintf(stderr,"[PREFIX] the request wrote past the rows kept apart: the conversation will be read again\n");
        q38_prefix_cache_invalidate();q38_park_free_rows();return;
    }
    for(int i=0;i<g_q38_park.nl;i++)if(m->K[i]&&g_q38_park.K[i])q38_park_rows(m,i,g_q38_park.rows,0);
    q38_pin_state_copy(m,&g_q38_park.st,0);
    memcpy(m->kvp.fed,g_q38_park.fed,(size_t)g_q38_park.len*sizeof(int));
    m->kvp.len=g_q38_park.len;m->kvp.tainted=0;m->kv_len=g_q38_park.kv_len;
#ifdef COLI_VULKAN
    q38c_rollback(m,-1,0);
#endif
#ifdef COLI_CUDA
    q38cc_rollback(m,-1,0);
#endif
    if(getenv("COLI_PREFIX_LOG"))fprintf(stderr,"[PREFIX] the %d-token conversation is back\n",g_q38_park.len);
    q38_park_free_rows();
}

/* Where a chat prompt's answer starts: past its last "<|im_start|>assistant\n", when only the
 * template's opening of the answer follows it (a few tokens: Qwen3.8's "<think>\n"); -1 when
 * the prompt is not such a prompt. */
static int q38_answer_start(const int *ids,int np){
    static int *seq=NULL,n=-1;
    if(n<0){
        n=0;
        if(g_tok){const char *s="<|im_start|>assistant\n";encode_text_n(s,strlen(s),&seq,&n);}
    }
    if(n<=0||!ids)return -1;
    for(int j=np-n;j>=0&&j>=np-n-8;j--)
        if(!memcmp(ids+j,seq,(size_t)n*sizeof(int)))return j+n<np?j+n:-1;
    return -1;
}
/* The prompt [from, np) in two stretches when the answer's opening follows its last turn: the
 * prompt-end snapshot is taken where the answer starts, not after the opening. A client that
 * sends an answer back without its reasoning renders "<think>" with what follows otherwise
 * ("\n\n</think>"): Hermes on Qwen3.8 left the snapshot one token short, and every turn read
 * 14,809 tokens again. *snapped: 1 when the snapshot was taken here. */
static float *q38_serve_prefill_at(Model *m,const int *ids,int from,int np,ColiPromptBreak *ctl,int snap_ok,int *snapped){
    *snapped=0;
    const int a=snap_ok?q38_answer_start(ids,np):-1;
    if(a<=from)return q38_serve_prefill(m,ids,from,np,ctl);
    float *lo=q38_serve_prefill(m,ids,from,a,ctl);
    if(!lo)return NULL;
    *snapped=q38_prefix_cache_save(m,ids,a,lo,0);
    free(lo);
    return q38_serve_prefill(m,ids,a,np,ctl);
}

/* COLI_PREFIX_LOG, a prompt that reused nothing: how far it follows what the engine holds (the
 * live state's tokens, the prompt-end snapshot's) and the text where it stops. A model with
 * recurrent layers restarts only from those two places, so a client that changes its history
 * before them (a system prompt with the time in it, an answer sent back without its
 * reasoning) re-reads the whole conversation every turn: this says where. */
static int q38_common_len(const int *a,int na,const int *b,int nb){
    int n=na<nb?na:nb,i=0;
    if(!a||!b)return 0;
    while(i<n&&a[i]==b[i])i++;
    return i;
}
static void q38_log_ids_text(const char *what,const int *ids,int from,int to){
    if(!g_tok||!ids)return;
    if(from<0)from=0;
    fprintf(stderr,"%s \"",what);
    for(int i=from;i<to;i++){
        unsigned char *t=NULL;int n=0;
        if(decode_id_alloc(ids[i],&t,&n))break;
        for(int j=0;j<n;j++){
            unsigned char ch=t[j];
            if(ch=='\n')fputs("\\n",stderr);else if(ch<32)fprintf(stderr,"\\x%02x",ch);else fputc(ch,stderr);
        }
        free(t);
    }
    fputs("\"\n",stderr);
}
static void q38_prefix_miss_log(Model *m,const int *ids,int np){
    int hl=m->kvp.fed?m->kvp.len:0,sl=g_q38_prefix.valid?g_q38_prefix.len:0;
    int dl=q38_common_len(ids,np,m->kvp.fed,hl),ds=q38_common_len(ids,np,g_q38_prefix.ids,sl);
    fprintf(stderr,"[PREFIX] the prompt follows the live state for %d of its %d tokens, the prompt-end snapshot for %d of %d\n",
            dl,hl,ds,sl);
    const int at=dl>=ds?dl:ds,*held=dl>=ds?m->kvp.fed:g_q38_prefix.ids,len=dl>=ds?hl:sl;
    if(at>=len)return;   /* it follows all of it: what stopped the reuse was not the text */
    q38_log_ids_text("[PREFIX]   before:",ids,at-16,at);
    q38_log_ids_text("[PREFIX]   prompt:",ids,at,at+16<np?at+16:np);
    q38_log_ids_text("[PREFIX]   held:  ",held,at,at+16<len?at+16:len);
}

/* lone: one conversation, whose prompt reads its STOP or CANCEL while it is read
 * (q38_serve_prefill); the multiplexed loop owns its command stream and passes 0. */
static int q38_serve_start(Model *m, ServeReq *q, int **ids_out, int *np_out, float **lo_out,
                           Q38ReqClock *clk, int lone){
    int *ids=NULL, np=0;
    encode_text_n(q->payload,(size_t)q->plen,&ids,&np); /* byte-counted prompt; qwen38 adds no BOS */
    if(g_pending_image.present){
        /* Le patch arrivano gia' float32 dal gateway: qui si controlla solo che
         * ce ne sia un numero intero e che la griglia le giustifichi, perche' un
         * conteggio storto darebbe una torre alimentata con byte disallineati. */
        Cfg *vc=&m->c;
        int features=vc->vis_in_ch*vc->vis_temporal*vc->vis_patch*vc->vis_patch;
        uint64_t want=(uint64_t)g_pending_image.grid_h*g_pending_image.grid_w*features*sizeof(float);
        if(!m->vis_ready||g_pending_image.bytes!=want){
            printf("ERROR %s BAD_IMAGE bytes=%llu expected=%llu\n",q->id,
                   (unsigned long long)g_pending_image.bytes,(unsigned long long)want);
            fflush(stdout); q38_pending_image_clear(); free(ids); return 0;
        }
        if(q38_vision_attach(m,(const float*)g_pending_image.patches,
                             g_pending_image.grid_h,g_pending_image.grid_w,ids,np)<0){
            printf("ERROR %s BAD_IMAGE the prompt and the grid disagree\n",q->id);
            fflush(stdout); q38_pending_image_clear(); free(ids); return 0;
        }
        q38_pending_image_clear();
    }
    int max_ctx=m->kv_cap;
    /* max_tokens=0 in modalita jev: leggere il prompt e fermarsi (serve_codec.h) */
    int budget = q38_serve_budget(np, q->max_tok, max_ctx, q->logprobs > 0);
    if(budget < 0){
        printf("ERROR %s CONTEXT_EXCEEDED prompt_tokens=%d requested=%d capacity=%d\n",q->id,np,q->max_tok,max_ctx);
        fflush(stdout); free(ids); return 0;
    }
    if(budget < q->max_tok){
        fprintf(stderr,"[serve] max_tokens %d clamped to %d (context %d - prompt %d); raise Q38_MAXT for longer answers\n",
                q->max_tok, budget, max_ctx, np);
        q->max_tok = budget;
    }
    printf("ACCEPT %s %d\n",q->id,np); fflush(stdout);
    clk->started=now_s(); clk->hits=m->hits; clk->misses=m->miss; clk->timers=m->timers;
    /* Prima gli scatti CHIESTI, e il piu profondo: sono punti di ritorno che
     * il client ha dichiarato, e battono la cache automatica, che insegue solo
     * l'ultimo prompt. Se nessuno serve, si ricade su quella. */
    int reuse=0; const float *pin_lo=NULL;
    /* Image embeddings are not described by token identity. */
    if(m->vis_map && m->vis_rows_n>0){
        kv_prefix_taint(&m->kvp);q38_prefix_cache_invalidate();
    }
    /* The live state first. After a turn it holds the prompt AND the answer this
     * engine wrote, recorded where they were fed (q38_spec_end undoes the drafts
     * nobody consumed), and a chat's next request begins with both: only its new
     * text is read. The snapshot below stops at the previous prompt's end, so
     * with it every turn re-read the whole answer before (15.8-24.5 s for a
     * 1,712-token second turn on a CPU box). An echo request (logprobs) still
     * goes through a snapshot: its first fresh token's predictor is the logits
     * saved with one. */
    /* COLI_KV_PREFIX=0 reads every prompt from the start (the B arm of the A/B
     * that shows reuse changes nothing but the time); a pin the client asked
     * for still counts. */
    const char *kv_prefix_env=getenv("COLI_KV_PREFIX");
    int prefix_off=kv_prefix_env&&*kv_prefix_env=='0';
    const char *reused_from="the live state";
    if(!q->logprobs&&!prefix_off){
        int live=kv_prefix_reuse(&m->kvp,ids,np);
        if(live>0&&m->kv_len==live)reuse=live;
    }
    if(!reuse)reused_from="a pin";
    if(!reuse){
        int ps=coli_pin_best(&g_q38_pins,ids,np);
        while(ps>=0){
            ColiPin *k=&g_q38_pins.slot[ps];
            Q38PinState *st=(Q38PinState*)k->state;
            /* Pins omit K/V/indexer rows. Reject one whose rows were overwritten. */
            if(st && kv_prefix_holds(&m->kvp,k->ids,k->len) &&
               q38_pin_state_copy(m,&st,0)){
                m->kv_len=k->len; m->kvp.len=k->len;
                reuse=k->len; pin_lo=k->logit;
                coli_pin_touch(&g_q38_pins,ps);
                break;
            }
            k->len=0;
            ps=coli_pin_best(&g_q38_pins,ids,np);
        }
    }
    if(!reuse&&!prefix_off){ reuse=q38_prefix_restore(m,ids,np); reused_from="the prompt-end snapshot"; }
    if(getenv("COLI_PREFIX_LOG")){
        if(reuse)
            fprintf(stderr,"[PREFIX] reusing %d of %d prompt tokens (%.0f%%) from %s\n",
                    reuse,np,100.0*reuse/np,reused_from);
        else{
            fprintf(stderr,"[PREFIX] no reuse: held=%d prompt=%d%s%s\n",m->kvp.len,np,
                    m->kvp.tainted?" tainted":"",prefix_off?" (COLI_KV_PREFIX=0)":"");
            q38_prefix_miss_log(m,ids,np);
        }
        fflush(stderr);
    }
    /* L'eco vale per il prefill, e il predittore del primo token fresco sono i
     * logit salvati con lo stato che si e appena rimesso. reuse==np e il caso
     * "prompt identico": li non c'e nessun token fresco da leggere. */
    g_echo_k=q->logprobs; g_echo_id=q->id;
    g_echo_pin_logit=(reuse>0&&reuse<np)
                     ? (pin_lo?pin_lo:q38_prefix_cached_logits(m)) : NULL;
    float *lo=NULL;
    ColiPromptBreak ctl={.poll=q38_prompt_poll,.id=q->id},*pc=lone?&ctl:NULL;
    /* the prompt-end snapshot where the answer starts (q38_serve_prefill_at): not for an echo
     * (its logits per row), a pin (its own) or a picture's rows */
    int snapped=0;const int snap_ok=!prefix_off&&!q->logprobs&&!q->pin&&!(m->vis_map&&m->vis_rows_n>0);
    if(reuse==np){
        const float *cached=q38_prefix_cached_logits(m);
        if(!cached){
            q38_prefix_cache_invalidate();reset_recurrent(m);m->kv_len=0;
            lo=q38_serve_prefill(m,ids,0,np,pc);reuse=0;
        }else{
            lo=falloc(m->c.vocab);
            memcpy(lo,cached,(size_t)m->c.vocab*sizeof(float));
        }
    }else if(reuse>0){
        lo=q38_serve_prefill_at(m,ids,reuse,np,pc,snap_ok,&snapped);
    }else{
        if(lone&&!prefix_off&&!q->logprobs)q38_park(m,np,q->max_tok);   /* a short request: the conversation kept apart */
        /* A miss invalidates the snapshot before reset so no later request can
         * pair its recurrent state with the old token record. */
        q38_prefix_cache_invalidate();reset_recurrent(m);m->kv_len=0;
        lo=q38_serve_prefill_at(m,ids,0,np,pc,snap_ok,&snapped);
    }
    g_echo_k=0; g_echo_id=NULL; g_echo_pin_logit=NULL;   /* la lettura e finita col prefill */
    if(ctl.control){
        /* stopped while reading: what was read stays the live state; a STOP ends the turn
         * with no token, a CANCEL with the error the gateway waits for */
        coli_prompt_break_log(ctl.control==3,m->kvp.len,np);
        if(ctl.control==3)coli_serve_write_error(stdout,q->id,"CANCELLED");
        else{
            ColiServeDone done={0,0.0,0.0,rss_gb(),np,0};
            coli_serve_write_done(stdout,q->id,&done);
        }
        fflush(stdout);
        free(ids);
        return 0;
    }
    /* Una fotografia chiesta esplicitamente sopravvive alle richieste che la
     * estendono; la si lascia andare solo quando non e servita a niente
     * (reuse==0: il prompt nuovo non comincia piu con lei), cosi la chat
     * normale ritrova subito il suo riuso di prefisso. */
    /* Uno scatto chiesto va nel pool, dove nessun'altra richiesta lo
     * sovrascrive; la cache automatica resta libera di inseguire la chat. */
    if(q->pin&&lo){
        coli_pin_pool_init(&g_q38_pins,m->c.vocab);
        ColiPin *k=coli_pin_store(&g_q38_pins,ids,np,lo);
        if(k){
            Q38PinState *st=(Q38PinState*)k->state;
            if(q38_pin_state_copy(m,&st,1)){ k->state=st; fprintf(stderr,"[PIN] scatto a %d token\n",np); }
            else k->len=0;                 /* senza stato lo scatto e una bugia */
        }
    }
    if(reuse!=np&&!snapped&&
       !q38_prefix_cache_save(m,ids,np,lo,0)&&getenv("Q38_PREFIX_LOG"))
        fprintf(stderr,"[qwen38 prefix] cache disabled for request %s (state snapshot unavailable)\n",q->id);
    if(getenv("Q38_PREFIX_LOG"))
        fprintf(stderr,"[qwen38 prefix] request=%s reused=%d/%d\n",q->id,reuse,np);
    if(m->draft_vocab)draft_vocab_begin(m->draft_vocab,ids,np,reuse);
    *ids_out=ids; *np_out=np; *lo_out=lo;
    return 1;
}

static int serve_one_turn(Model *m, ServeReq *q);
/* one request; a conversation parked for it (q38_park) comes back when it ends, however it ends */
static int serve_one(Model *m, ServeReq *q){
    int r=serve_one_turn(m,q);
    q38_unpark(m);
    return r;
}
static int serve_one_turn(Model *m, ServeReq *q){
    int *ids=NULL, np=0; float *lo=NULL; Q38ReqClock clk;
    if(!q38_serve_start(m,q,&ids,&np,&lo,&clk,1)) return 0;
    double request_started=clk.started;
    uint64_t hits_before=clk.hits, misses_before=clk.misses;
    Q38Timers timers_before=clk.timers;
    int gen=0, limited=1, cancelled=0, stopped=0, input_eof=0;
    int eos_ids[4];int n_eos=serve_eos_ids(eos_ids,4,m->c.eos_id,m->c.vocab);
    /* Q38_MTP=1: the head drafts and a verify forward checks it; every token
     * is still sampled from the exact logits below, greedy or not. */
    Q38Spec spec=q38_spec_begin(m,ids,np);
    double first_token_at=0.0,last_token_at=0.0;
    unsigned char sbuf[16]; int sbn=0;
    for(int s=0;s<q->max_tok;s++){
        while(!input_eof&&coli_stdin_readable()){
            int control=serve_read_req(stdin,stdout,NULL,q->id);
            if(control<0){input_eof=1;break;}
            if(control==1)stopped=1;
            if(control==3)cancelled=1;
        }
        if(cancelled||stopped)break;
        int tk = serve_sample(lo, m->c.vocab, q->temp, q->top_p);
        char lptail[1024]; lptail[0]=0;
        if(q->logprobs>0) coli_logprob_tail(lptail,sizeof lptail,lo,m->c.vocab,tk,q->logprobs);
        free(lo); lo=NULL;
        int is_eos=0; for(int e=0;e<n_eos;e++) if(tk==eos_ids[e]) is_eos=1;
        if(is_eos){ limited=0; break; }
        double token_at=now_s();
        if(!gen)first_token_at=token_at;
        last_token_at=token_at;
        unsigned char *token=NULL;int token_n=0;
        if(decode_id_alloc(tk,&token,&token_n)){fprintf(stderr,"[decode] out of memory\n");exit(1);}
        if(token_n>(INT_MAX-3)/3){free(token);fprintf(stderr,"[decode] token is too large\n");exit(1);}
        int chunk_cap=token_n*3+3;
        unsigned char *chunk=(unsigned char*)malloc((size_t)chunk_cap);int chunk_n=0;
        if(!chunk||utf8_drain(sbuf,&sbn,token,token_n,chunk,chunk_cap,&chunk_n)<0){
            free(chunk);free(token);fprintf(stderr,"[decode] invalid output capacity\n");exit(1);
        }
        if(q->logprobs>0) serve_data_lp(q->id,(char*)chunk,chunk_n,lptail);
        else if(chunk_n>0) serve_data(q->id,(char*)chunk,chunk_n);
        free(chunk);free(token);
        gen++;
        while(!input_eof&&coli_stdin_readable()){
            int control=serve_read_req(stdin,stdout,NULL,q->id);
            if(control<0){input_eof=1;break;}
            if(control==1)stopped=1;
            if(control==3)cancelled=1;
        }
        if(cancelled||stopped){limited=0;break;}
        /* The next logits are not needed after the final requested token.
         * A next request that continues this conversation reads the token in
         * its own prompt, after the live state's last one, so stepping here
         * would only run a decode pass that prefill repeats. */
        if(s == q->max_tok - 1) break;
        if(m->draft_vocab)draft_vocab_count_token(m->draft_vocab,tk);
        lo = q38_spec_step(m, &spec, tk, np+s, q->max_tok-1-s);
    }
    q38_spec_end(m, &spec);
    /* I vettori dell'immagine valgono per QUESTO turno soltanto: lasciarli
     * agganciati farebbe rispondere la richiesta successiva sulla foto
     * precedente, e la mappa e' per posizione assoluta, quindi combacerebbe
     * silenziosamente invece di dare errore. */
    q38_vision_detach(m);
    free(lo); free(ids);
    if(cancelled){coli_serve_write_error(stdout,q->id,"CANCELLED");return input_eof?-1:0;}
    if(stopped)limited=0;
    unsigned char tail[3];int tail_n=0;
    if(utf8_finish(sbuf,&sbn,tail,sizeof tail,&tail_n)<0){
        fprintf(stderr,"[decode] invalid UTF-8 finalization\n");exit(1);
    }
    if(tail_n)serve_data(q->id,(char*)tail,tail_n);
    double wall_s=now_s()-request_started;
    double decode_s=gen>1?last_token_at-first_token_at:0.0;
    uint64_t hits=m->hits-hits_before,misses=m->miss-misses_before;
    Q38Timers timers=q38_tm_delta(&m->timers,&timers_before);
    ColiServeDone done={gen,q38_decode_rate(gen,decode_s),
                        q38_cache_hit_percent(hits,misses),rss_gb(),np,limited};
    coli_serve_write_done(stdout,q->id,&done);
    /* Stable dashboard contract.  Disk service and synchronous miss wait
     * intentionally overlap; all finer Qwen phases remain available through
     * COLI_TIMERS=1 without widening the shared frame. */
    char profile[256];int profile_bytes=q38_format_prof(profile,sizeof profile,wall_s,np,gen,&timers);
    if(profile_bytes>0)fwrite(profile,1,(size_t)profile_bytes,stdout);
    else fprintf(stderr,"[qwen38] internal error: PROF frame overflow\n");
    fflush(stdout);
    serve_hits(m);
    q38_tm_report_bank(&timers,"request");
    {char scope[96];snprintf(scope,sizeof scope,"turn %s",q->id);q38_spec_report(m,&spec,scope);q38_vocab_report(m,scope);}
    q38_spec_free(&spec);
    return input_eof?-1:0;
}

/* ---- several conversations at once (KV_SLOTS>1) -----------------------------
 * The gateway's cache slots, each a conversation with a state of its own (Q38Seq,
 * qwen38_core.h). A SUBMIT on a free slot starts its request at once: the prompt goes
 * in through the same q38_serve_start as a lone request's, on that slot's state, with
 * its pins and its own prefix cache. Then every step picks the next token of each
 * active request from its logits and runs one forward over a row of each
 * (q38_forward_rows): the matrices and the experts are read once for all of them. A
 * request's frames are a lone request's; they interleave by id. Nothing drafts
 * (speculation follows one conversation), and the slot keeps its state between turns,
 * so a conversation's next turn reuses its prompt as a lone serve's does. */
static int g_q38_mux_slots = 1;
static Q38Seq *g_q38_mux_seq;              /* [slots]: the conversations the Model does not hold */
static Q38PrefixCache *g_q38_mux_prefix;   /* [slots]: their prefix caches */
static int g_q38_mux_cur;                  /* the slot the Model holds, -1 when every one is parked */

/* The state a serve allocates once it runs: the attention layers' K, V and index keys
 * at the context for every slot (the MTP head's rows with one), the DeltaNet layers'
 * state for the slots past the Model's. Pages the RAM does not count until they are
 * written, which a host pool (the Vulkan tier's, the CUDA chain's) must leave. */
static size_t q38_state_later(Model *m){
    const Cfg *c=&m->c;
    int ctx=m->max_t>0?m->max_t:qwen38_max_ctx();
    if(ctx>c->max_positions)ctx=c->max_positions;
    size_t t=(size_t)ctx,kv=0,dn=0;
    for(int i=0;i<c->layers;i++)
        if(c->is_attn[i])kv+=t*((size_t)2*c->kv_heads*c->head_dim+(size_t)c->idx_dim)*sizeof(float);
        else dn+=((size_t)c->dn_vheads*c->dn_kdim*c->dn_vdim+(size_t)c->dn_conv_dim*(c->dn_convk-1))*sizeof(float);
    int n=g_q38_mux_slots>1?g_q38_mux_slots:1;
    size_t mtp=q38_layer_rows(m)>c->layers&&n==1?t*((size_t)2*c->kv_heads*c->head_dim+(size_t)c->idx_dim)*sizeof(float):0;
    return kv*(size_t)n+dn*(size_t)(n-1)+mtp;
}


typedef struct {
    ServeReq q;
    int active, stop, cancel, limited;
    int *ids, np, gen;
    float *lo;                      /* the logits the next pick reads */
    Q38ReqClock clk;
    double first_token_at, last_token_at;
    unsigned char sbuf[16]; int sbn;
} Q38MuxReq;

static void q38_mux_bind(Model *m,int slot){
    if(g_q38_mux_cur==slot)return;
    for(int k=0;k<2;k++){   /* the held one back to its place, then the asked one in */
        int x=k?slot:g_q38_mux_cur;
        if(x<0)continue;
        q38_seq_swap(m,&g_q38_mux_seq[x]);
        Q38PrefixCache t=g_q38_prefix; g_q38_prefix=g_q38_mux_prefix[x]; g_q38_mux_prefix[x]=t;
    }
    g_q38_mux_cur=slot;
}

/* Slot 0 is the Model's own state; the others get theirs here. 0: out of memory. */
static int q38_mux_alloc(Model *m){
    int n=g_q38_mux_slots;
    g_q38_mux_seq=(Q38Seq*)calloc((size_t)n,sizeof *g_q38_mux_seq);
    g_q38_mux_prefix=(Q38PrefixCache*)calloc((size_t)n,sizeof *g_q38_mux_prefix);
    if(!g_q38_mux_seq||!g_q38_mux_prefix)return 0;
    for(int i=1;i<n;i++)if(!q38_seq_alloc(m,&g_q38_mux_seq[i]))return 0;
    g_q38_mux_cur=0;
    return 1;
}
static void q38_mux_free(Model *m){
    if(!g_q38_mux_seq)return;
    for(int i=0;i<g_q38_mux_slots;i++){q38_mux_bind(m,i);q38_prefix_cache_release(m);}
    q38_mux_bind(m,0);   /* the Model's own state back where q38_model_free looks */
    for(int i=1;i<g_q38_mux_slots;i++)q38_seq_free(m,&g_q38_mux_seq[i]);
    free(g_q38_mux_seq);free(g_q38_mux_prefix);g_q38_mux_seq=NULL;g_q38_mux_prefix=NULL;
}

/* A request's end, as serve_one ends one: the UTF-8 tail, DONE and PROF, or the
 * ERROR of a cancel. */
static void q38_mux_finish(Model *m,Q38MuxReq *r){
    free(r->lo);r->lo=NULL;free(r->ids);r->ids=NULL;r->active=0;
    if(r->cancel){coli_serve_write_error(stdout,r->q.id,"CANCELLED");return;}
    if(r->stop)r->limited=0;
    unsigned char tail[3];int tail_n=0;
    if(utf8_finish(r->sbuf,&r->sbn,tail,sizeof tail,&tail_n)<0){
        fprintf(stderr,"[decode] invalid UTF-8 finalization\n");exit(1);
    }
    if(tail_n)serve_data(r->q.id,(char*)tail,tail_n);
    double wall_s=now_s()-r->clk.started;
    double decode_s=r->gen>1?r->last_token_at-r->first_token_at:0.0;
    uint64_t hits=m->hits-r->clk.hits,misses=m->miss-r->clk.misses;
    Q38Timers timers=q38_tm_delta(&m->timers,&r->clk.timers);
    ColiServeDone done={r->gen,q38_decode_rate(r->gen,decode_s),
                        q38_cache_hit_percent(hits,misses),rss_gb(),r->np,r->limited};
    coli_serve_write_done(stdout,r->q.id,&done);
    char profile[256];int profile_bytes=q38_format_prof(profile,sizeof profile,wall_s,r->np,r->gen,&timers);
    if(profile_bytes>0)fwrite(profile,1,(size_t)profile_bytes,stdout);
    else fprintf(stderr,"[qwen38] internal error: PROF frame overflow\n");
    fflush(stdout);
    serve_hits(m);
    q38_tm_report_bank(&timers,"request");
}

/* The next token of an active request, as serve_one's loop picks and sends it: 1
 * with the token when the request goes on, 0 when it ended. */
static int q38_mux_pick(Model *m,Q38MuxReq *r,const int *eos_ids,int n_eos,int *tk_out){
    if(r->cancel||r->stop||r->gen>=r->q.max_tok){q38_mux_finish(m,r);return 0;}
    int tk=serve_sample(r->lo,m->c.vocab,r->q.temp,r->q.top_p);
    char lptail[1024];lptail[0]=0;
    if(r->q.logprobs>0)coli_logprob_tail(lptail,sizeof lptail,r->lo,m->c.vocab,tk,r->q.logprobs);
    free(r->lo);r->lo=NULL;
    for(int e=0;e<n_eos;e++)if(tk==eos_ids[e]){r->limited=0;q38_mux_finish(m,r);return 0;}
    double token_at=now_s();
    if(!r->gen)r->first_token_at=token_at;
    r->last_token_at=token_at;
    unsigned char *token=NULL;int token_n=0;
    if(decode_id_alloc(tk,&token,&token_n)){fprintf(stderr,"[decode] out of memory\n");exit(1);}
    if(token_n>(INT_MAX-3)/3){free(token);fprintf(stderr,"[decode] token is too large\n");exit(1);}
    int chunk_cap=token_n*3+3;
    unsigned char *chunk=(unsigned char*)malloc((size_t)chunk_cap);int chunk_n=0;
    if(!chunk||utf8_drain(r->sbuf,&r->sbn,token,token_n,chunk,chunk_cap,&chunk_n)<0){
        free(chunk);free(token);fprintf(stderr,"[decode] invalid output capacity\n");exit(1);
    }
    if(r->q.logprobs>0)serve_data_lp(r->q.id,(char*)chunk,chunk_n,lptail);
    else if(chunk_n>0)serve_data(r->q.id,(char*)chunk,chunk_n);
    free(chunk);free(token);
    r->gen++;
    /* the next logits are not needed after the last requested token (serve_one) */
    if(r->gen>=r->q.max_tok){q38_mux_finish(m,r);return 0;}
    *tk_out=tk;return 1;
}

/* One command: a SUBMIT on a free slot starts its request, STOP and CANCEL mark the
 * request they name, IMAGE waits for its SUBMIT. -1 at the end of the input. */
static int q38_serve_take_image(FILE *out,ColiServeCommand *command);
static int q38_mux_read(Model *m,Q38MuxReq *rq,int n){
    ColiServeCommand command;
    ColiServeReadResult result=coli_serve_read_command(stdin,&q38_wire,&command);
    if(result==COLI_SERVE_READ_EOF||result==COLI_SERVE_READ_BAD_FRAME)return -1;
    if(result==COLI_SERVE_READ_NOMEM){coli_serve_write_error(stdout,command.id,"out of memory");return -1;}
    if(result==COLI_SERVE_READ_BAD_REQUEST){
        if(command.kind==COLI_SERVE_COMMAND_SUBMIT)
            coli_serve_write_error(stdout,command.id,"bad submit header");
        coli_serve_command_dispose(&command);return 0;
    }
    if(result!=COLI_SERVE_READ_OK)return 0;
    if(command.kind==COLI_SERVE_COMMAND_STOP||command.kind==COLI_SERVE_COMMAND_CANCEL){
        for(int i=0;i<n;i++)if(rq[i].active&&!strcmp(rq[i].q.id,command.id)){
            if(command.kind==COLI_SERVE_COMMAND_STOP)rq[i].stop=1; else rq[i].cancel=1;
        }
        coli_serve_command_dispose(&command);return 0;
    }
    if(command.kind==COLI_SERVE_COMMAND_IMAGE)return q38_serve_take_image(stdout,&command);
    if(command.kind!=COLI_SERVE_COMMAND_SUBMIT){coli_serve_command_dispose(&command);return 0;}
    if(command.slot<0||command.slot>=n){
        coli_serve_write_error(stdout,command.id,"invalid cache slot");
        coli_serve_command_dispose(&command);return 0;
    }
    Q38MuxReq *r=&rq[command.slot];
    if(r->active){
        coli_serve_write_error(stdout,command.id,"SLOT_BUSY");
        coli_serve_command_dispose(&command);return 0;
    }
    memset(r,0,sizeof *r);
    snprintf(r->q.id,sizeof(r->q.id),"%s",command.id);
    r->q.slot=command.slot;
    r->q.max_tok=command.max_tokens;r->q.temp=command.temperature;r->q.top_p=command.top_p;
    r->q.payload=(char*)coli_serve_command_take_payload(&command);r->q.plen=(int)command.payload_bytes;
    r->q.logprobs=command.logprobs;r->q.pin=command.pin;
    coli_serve_command_dispose(&command);
    q38_mux_bind(m,r->q.slot);
    int ok=q38_serve_start(m,&r->q,&r->ids,&r->np,&r->lo,&r->clk,0);
    free(r->q.payload);r->q.payload=NULL;
    if(!ok)return 0;
    q38_vision_detach(m);   /* the image's rows are the prompt's: no decode row reads them */
    r->active=1;r->limited=1;
    return 1;
}

static void serve_mux(Model *m){
    int n=g_q38_mux_slots,V=m->c.vocab,input_eof=0;
    Q38MuxReq *rq=(Q38MuxReq*)calloc((size_t)n,sizeof *rq);
    Q38Row *rows=(Q38Row*)malloc((size_t)n*sizeof *rows);
    int *tok=(int*)malloc((size_t)n*sizeof(int)),*who=(int*)malloc((size_t)n*sizeof(int));
    if(!rq||!rows||!tok||!who){fprintf(stderr,"[serve] out of memory\n");exit(1);}
    int eos_ids[4];int n_eos=serve_eos_ids(eos_ids,4,m->c.eos_id,V);
    unsigned long long steps=0,nrows=0;
    fprintf(stderr,"[qwen38] serving %d conversations at once (KV_SLOTS)\n",n);
    for(;;){
        int active=0;for(int i=0;i<n;i++)active+=rq[i].active;
        /* idle: wait for a command; decoding: take one only when one is there */
        if(!input_eof&&(!active||coli_stdin_readable())&&q38_mux_read(m,rq,n)<0)input_eof=1;
        active=0;for(int i=0;i<n;i++)active+=rq[i].active;
        if(!active){if(input_eof)break;continue;}
        int S=0,ended=0;
        for(int i=0;i<n;i++)if(rq[i].active){
            int tk;
            if(!q38_mux_pick(m,&rq[i],eos_ids,n_eos,&tk)){ended=1;continue;}
            rows[S]=(Q38Row){&g_q38_mux_seq[i],rq[i].np+rq[i].gen-1};tok[S]=tk;who[S]=i;S++;
        }
        if(S){
            /* every conversation parked: the rows read theirs from g_q38_mux_seq */
            q38_mux_bind(m,-1);
            float *lo=q38_forward_rows(m,rows,tok,S);
            steps++;nrows+=(unsigned long long)S;
            for(int s=0;s<S;s++){
                Q38MuxReq *r=&rq[who[s]];
                r->lo=falloc(V);memcpy(r->lo,lo+(int64_t)s*V,(size_t)V*sizeof(float));
            }
            free(lo);
        }
        if(ended){
#ifdef COLI_VULKAN
            q38_vk_report();
            vkt_report("turn", m->hits, m->miss);
#endif
            serve_emap(m);
        }
    }
    fprintf(stderr,"[qwen38] KV_SLOTS=%d: %llu decode steps, %llu rows (%.2f a step)\n",n,steps,nrows,
            steps?(double)nrows/(double)steps:0.0);
    free(rq);free(rows);free(tok);free(who);
}

static void serve_loop(Model *m){
    g_serve_model=m;
    coli_serve_binary_mode();
    setvbuf(stdin,NULL,_IONBF,0);
    int max_ctx=qwen38_max_ctx();
    if(max_ctx>m->c.max_positions)max_ctx=m->c.max_positions;
    if(!q38_serve_ensure_kv(m,max_ctx)){
        fprintf(stderr,"[serve] unable to allocate QSA state\n");return;
    }
    if(g_q38_mux_slots>1&&!q38_mux_alloc(m)){
        fprintf(stderr,"[serve] unable to allocate the state of %d conversations (KV_SLOTS)\n",g_q38_mux_slots);return;
    }
    fputs("\x01\x01READY\x01\x01\n",stdout);
    /* between READY and STAT: the gateway reads it in the handshake, so it knows
     * the served modalities before the first request (docs/serve_protocol.md) */
    printf("CAPS vision=%d\n",m->vis_ready?1:0);
    printf("STAT 0 0.00 0.0 %.2f\n",rss_gb());
    fflush(stdout);
    serve_emap(m);                       /* after READY and STAT: the boot reader discards what precedes them */
    if(g_q38_mux_slots>1){serve_mux(m);q38_mux_free(m);return;}
    for(;;){
        ServeReq q={0}; int r;
        do r=serve_read_req(stdin,stdout,&q,NULL); while(r!=2&&r>=0);
        if(r<0){q38_prefix_cache_release(m);return;}
        if(r==2){
            int status=serve_one(m,&q);free(q.payload);
#ifdef COLI_CUDA
            q38cc_report(m);
#endif
#ifdef COLI_VULKAN
            q38_vk_report();   /* stderr: the wire protocol on stdout is untouched */
            q38c_report(m);
            vkt_report("turn", m->hits, m->miss);
#endif
            if(status<0){q38_prefix_cache_release(m);return;}
            serve_emap(m);
        }
    }
}

static int q38_reference_mode(const char *path,int serve_mode){
    if(serve_mode||!path)return 0;
    size_t length=strlen(path);
    return length>=5&&!strcmp(path+length-5,".json");
}

static void q38_expert_report(Model *m, int cap);   /* below, beside the expert layout accounting */
#ifdef COLI_VULKAN
static void q38_vk_tier_start(Model *m, int cap);   /* below: the Vulkan routed-expert tier */
#endif

#ifdef COLI_VULKAN
/* After the device and the chain are decided, before the expert tier sizes its budget:
 * the trunk goes up now, so the tier sees it placed. */
static void q38_dho_start(Model *m) {
    if(!g_vk_ready)return;
    g_q38_dho_model=m;
    size_t bytes=0; int n=0,layers=m->c.layers,head=1,dev=(g_vk_chain||g_vk_dense)&&!qt_ready();
    q38c_dho_bound(&layers,&head,&dev);   /* a partial chain: its N layers' matrices only (qwen38_chain.h) */
    q38_dho_each(m,q38_dho_count,&bytes,&n,layers,head);
    if(!coli_vk_dense_host_decide("qwen38",dev,bytes))return;
    g_vk_dense=1;   /* the steps the chain declines run their matrices on the device too: the CPU has none */
    bytes=0; n=0;
    /* the full chain fitted: layer by layer, each dropped once all of it is on the device */
    if(!q38c_dho_place(m,&bytes,&n))q38_dho_each(m,q38_dho_drop,&bytes,&n,layers,head);
    q38c_dho_layers();
    coli_vk_dense_host_placed("qwen38",m->draft_vocab
        ? "the embedding (its rows are gathered on the CPU), the lm_head's int8 rows (the MTP draft list is scored from them), the vision tower, norms"
        : "the embedding (its rows are gathered on the CPU), the vision tower, norms");
}
#endif

#ifndef QWEN38_TEST_SERVE
int main(int argc, char **argv) {
    /* Physical-core team sizing, as colibri/inkling/kimi_k3/olmoe/deepseek-v41
     * do. Without it this engine takes one thread per logical CPU, which on an
     * SMT host doubles the team for no arithmetic and pays a barrier per tiny
     * per-expert region (#718 measured +2.3x from the sizing alone on a
     * 16C/32T part). OMP_NUM_THREADS wins, COLI_NO_OMP_TUNE=1 disables. Before it,
     * the hot team (omp_tune.h), which re-runs the engine once with libgomp's settings. */
    coli_omp_hot_team(argv, "qwen38", coli_omp_env_on("COLI_CUDA") || coli_omp_env_on("COLI_METAL"));
    coli_omp_tune_threads("qwen38");
    const char *snap = getenv("SNAP");
    if (!snap) { fprintf(stderr, "set SNAP=<snapshot directory>\n"); return 1; }
    {   /* a model directory made by tools/gguf_import.py: gguf.json names llama.cpp's
         * qwen4exp GGUF, read in place (qwen38_core.h, "GGUF mode") */
        char gj[4096]; snprintf(gj, sizeof gj, "%s/gguf.json", snap);
        FILE *f = fopen(gj, "rb");
        if (f) {
            char buf[8192], gp[4096]; size_t n = fread(buf, 1, sizeof buf - 1, f); fclose(f); buf[n] = 0;
            char *arena = NULL; jval *r = json_parse(buf, &arena);
            const char *g = r ? jstr(r, "gguf") : NULL;
            if (!g || !*g) { fprintf(stderr, "%s: no \"gguf\" path\n", gj); return 1; }
            gguf_path_join(gp, sizeof gp, snap, g);
            const char *mt = jstr(r, "mtp");   /* the MTP head's own GGUF (unsloth's mtp-*.gguf), optional */
            char mp[4096] = "";
            if (mt && *mt) gguf_path_join(mp, sizeof mp, snap, mt);
            free(arena);
            if (gguf_open(&g_q38gg, gp)) { fprintf(stderr, "GGUF: %s\n", g_q38gg.err); return 1; }
            if (mp[0]) {
                if (gguf_open(&g_q38gg_mtp, mp)) { fprintf(stderr, "GGUF (MTP head): %s\n", g_q38gg_mtp.err); return 1; }
                const char *ma = gguf_get_str(&g_q38gg_mtp, "general.architecture");
                const gguf_kv *nx = gguf_get(&g_q38gg_mtp, "qwen4exp.nextn_predict_layers");
                if (!ma || strcmp(ma, "qwen4exp") || !nx) {
                    fprintf(stderr, "GGUF %s: not a qwen4exp MTP head (architecture %s, nextn_predict_layers %s)\n",
                            mp, ma ? ma : "(none)", nx ? "present" : "missing"); return 1;
                }
                fprintf(stderr, "[gguf] MTP head %s: %d tensors\n", mp, g_q38gg_mtp.n_tensors);
            }
            const char *arch = gguf_get_str(&g_q38gg, "general.architecture");
            if (!arch || strcmp(arch, "qwen4exp")) { fprintf(stderr, "GGUF %s: architecture %s, not qwen4exp\n", gp, arch ? arch : "(none)"); return 1; }
            g_q38_gguf = 1; g_q38_a_direct = 1; g_q38_dn_tiled = 1;
            fprintf(stderr, "[gguf] %s: %d file(s), %d tensors, read in place (native ggml types, no conversion)\n",
                    gp, g_q38gg.n_files, g_q38gg.n_tensors);
            /* The CUDA chain runs a GGUF whose experts' types its frame computes (their blocks on
             * the card and in a host pool; Qwen3.8-Flash-Next IQ2_XS on an RTX PRO 4000: prompt
             * 209-213 tok/s and decode 49.6-50.8 against the Vulkan chain's 194-197 and 44-51). Any
             * other GGUF runs on Vulkan in a build with both backends when CUDA was asked for and
             * COLI_VULKAN was not set; COLI_VULKAN=0 keeps CUDA. */
            int cuda_blocks = 1;
#ifdef COLI_CUDA
            for (int i = 0; i < g_q38gg.n_tensors && cuda_blocks; i++) {
                if (!strstr(g_q38gg.t[i].name, "_exps.weight")) continue;
                const int t = g_q38gg.t[i].type;
                cuda_blocks = cc_moe_block_type(t) && coli_cuda_block_elems(100 + t) > 0;
            }
#else
            cuda_blocks = 0;
#endif
            {   const char *cu = getenv("COLI_CUDA"), *vk = getenv("COLI_VULKAN");
                if (cu && *cu == '1' && !(vk && *vk) && !cuda_blocks) {
#if defined(COLI_CUDA) && defined(COLI_VULKAN)
                    setenv("COLI_VULKAN", "1", 1); setenv("COLI_CUDA", "0", 1);
                    fprintf(stderr, "[gguf] the CUDA chain's frame does not take every expert type of this GGUF: it runs on "
                                    "Vulkan, the same card (COLI_VULKAN=0 keeps CUDA, those experts then on the CPU)\n");
#endif
                }
            }
        }
    }
    if (getenv("OPENAI")) g_openai = 1;                       /* OpenAI-compatible output */
    const char *mv = getenv("MODEL");
    if (mv && *mv) snprintf(g_model, sizeof g_model, "%s", mv);
    int cap   = argc > 1 ? coli_arg_int(argv[1], "cache/layer") : 1;
    int bits  = argc > 2 ? coli_arg_int(argv[2], "expert bits") : 8;
    /* cap < 1 leaves every layer cache empty, so expert_get finds no slot to
     * evict and waits for a publish that can never come. The old lru=0 fallback
     * turned that into a heap OOB instead; neither is a failure mode to ship. */
    if (cap < 1) { fprintf(stderr, "cache/layer must be >= 1 (got %d)\n", cap); return 1; }
    if (bits < 2 || bits > 8) { fprintf(stderr, "reserved bits argument must be 2..8 (got %d)\n", bits); return 1; }
    const char *refpath = argc > 3 ? argv[3] : "ref.json";
    int serve_mode=getenv("SERVE")&&getenv("SERVE")[0]=='1';

    fprintf(stderr, "== Qwen3.8-Flash-Next native text engine | cache=%d/layer | CPU ==\n", cap);

    int is_ref=q38_reference_mode(refpath,serve_mode);

    int *prompt=NULL, *full=NULL, *out=NULL;
    int np=0, nfull=0, n_new=0;
    char *buf=NULL, *arena=NULL; jval *ref_root=NULL,*ref_logits=NULL;
    /* serve mode gets its prompts over the wire: skip the argv prompt file
     * entirely, or the default "ref.json" kills the engine before serve_loop
     * is ever reached — which is exactly how `coli` launches it (SERVE=1, no
     * prompt argument). */
    /* Load before model_init so malformed/missing tokenizer state cannot spend
     * minutes materializing a model that serve/text mode must then refuse. A
     * numeric reference run deliberately remains tokenizer-optional. */
    int tokenizer_status=-1;
    {
        const char *tokpath = getenv("TOK");
        if (tokpath && *tokpath) tokenizer_status=load_tokenizer(tokpath);
        else if (argc > 4 && argv[4] && *argv[4])
            tokenizer_status=load_tokenizer(argv[4]);
        else {
            char tpb[2048];snprintf(tpb,sizeof tpb,"%s/tokenizer.json",snap);
            tokenizer_status=load_tokenizer(tpb);
        }
    }
    if(tokenizer_status&&(serve_mode||!is_ref)){
        fprintf(stderr,serve_mode?
                "[serve] a complete tokenizer.json is required (put it in SNAP or set TOK)\n":
                "[enc] a complete tokenizer.json is required (put it in SNAP or set TOK)\n");
        free_tokenizer();return 1;
    }

    if (serve_mode) {
        /* no argv prompt to load */
    } else if (is_ref) {
        FILE *f = fopen(refpath, "rb"); if (!f) { perror(refpath); return 1; }
        if (fseek(f,0,SEEK_END)) { perror(refpath); fclose(f); return 1; }
        long n=ftell(f);
        if (n<0 || n>(256L<<20) || fseek(f,0,SEEK_SET)) {
            fprintf(stderr, "%s: invalid or oversized reference file\n", refpath);
            fclose(f); return 1;
        }
        buf=malloc((size_t)n+1);
        if (!buf || fread(buf,1,(size_t)n,f)!=(size_t)n) {
            fprintf(stderr, "cannot read %s\n", refpath); free(buf); fclose(f); return 1;
        }
        buf[n]=0; fclose(f);
        ref_root = json_parse(buf, &arena);
        if (!ref_root || ref_root->t != J_OBJ) {
            fprintf(stderr, "%s: expected a JSON object\n", refpath); json_free(ref_root); free(buf); free(arena); return 1;
        }
        prompt = read_int_array(ref_root,"prompt_ids",&np);
        full   = read_int_array(ref_root,"full_ids",&nfull);
        if (nfull<=np) {
            fprintf(stderr, "%s: full_ids must extend prompt_ids\n", refpath); return 1;
        }
        for (int i=0;i<np;i++) if (prompt[i]!=full[i]) {
            fprintf(stderr, "%s: full_ids does not begin with prompt_ids at token %d\n",
                    refpath,i); return 1;
        }
        n_new  = nfull - np;
    } else {
        /* text-prompt mode: read file as raw text, encode in C */
        FILE *f = fopen(refpath, "rb"); if (!f) { perror(refpath); return 1; }
        if (fseek(f,0,SEEK_END)) { perror(refpath); fclose(f); return 1; }
        long n=ftell(f);
        if (n<0 || n>(256L<<20) || fseek(f,0,SEEK_SET)) {
            fprintf(stderr, "%s: invalid or oversized prompt file\n", refpath);
            fclose(f); return 1;
        }
        char *txt=malloc((size_t)n+1);
        if (!txt || fread(txt,1,(size_t)n,f)!=(size_t)n) {
            fprintf(stderr, "cannot read %s\n", refpath); free(txt); fclose(f); return 1;
        }
        txt[n]=0; fclose(f);
        if (!g_tok) { fprintf(stderr, "[enc] no tokenizer loaded; cannot encode text. Put tokenizer.json in SNAP or set TOK.\n"); free(txt); return 1; }
        encode_text_n(txt,(size_t)n,&prompt,&np);
        free(txt);
        n_new = 64;
        const char *nnew_env=getenv("N_NEW");
        if (nnew_env && *nnew_env) {
            char *end=NULL; errno=0; long value=strtol(nnew_env,&end,10);
            if (errno || end==nnew_env || *end || value<1 || value>INT_MAX) {
                fprintf(stderr, "N_NEW must be an integer in [1,%d]\n",INT_MAX); return 1;
            }
            n_new=(int)value;
        }
        fprintf(stderr, "[enc] prompt tokens: %d | generating %d new tokens\n", np, n_new);
        if (getenv("ENC_DEBUG") && np <= 300) { fprintf(stderr, "[enc] prompt ids: "); for (int i=0;i<np;i++) fprintf(stderr, "%d ", prompt[i]); fprintf(stderr, "\n"); }
    }

    Model m; model_init(&m, snap, cap, bits);
    q38_expert_int4_attach(&m, snap);   /* <snap>/experts-int4g64/ when present (Q38_EXPERT_INT4) */
    if (serve_mode) {   /* KV_SLOTS: how many conversations the serve decodes at once */
        const char *ks=getenv("KV_SLOTS");
        if (ks && *ks) {
            char *end=NULL; long v=strtol(ks,&end,10);
            if (end==ks || *end || v<1 || v>16) { fprintf(stderr, "KV_SLOTS must be between 1 and 16\n"); return 2; }
            g_q38_mux_slots=(int)v;
        }
    }
    if (g_q38_mux_slots>1)
        fprintf(stderr, "[qwen38] KV_SLOTS=%d: the MTP head stays unloaded and nothing drafts "
                        "(speculation follows one conversation)\n", g_q38_mux_slots);
    else q38_mtp_attach(&m, cap);       /* Q38_MTP=1: the checkpoint's MTP head drafts (qwen38_core.h) */
    q38_act_init(&m);                   /* Q38_ACT_STATS: the experts' input statistics, for a calibrated quantizer */
    q38_cov_init(&m);                   /* Q38_ACT_COV: their input second moments, for the error-compensating one */
    q38_dump_init(&m);                  /* Q38_ACT_DUMP: their inputs and routes, row by row */
    if (g_q38_gguf) {   /* a tensor the files have and nothing loaded: a weight the engine would ignore */
        int unused = 0, head = 0; char hp[32]; snprintf(hp, sizeof hp, "blk.%d.", m.c.layers);
        const gguf_ctx *files[2] = { &g_q38gg, &g_q38gg_mtp };
        for (int f = 0; f < 2; f++)
            for (int i = 0; i < files[f]->n_tensors; i++) {
                const gguf_tensor *t = &files[f]->t[i];
                if (t->used || strstr(t->name, "_exps.weight")) continue;   /* the experts load on demand */
                if (f == 1 && (!strcmp(t->name, "token_embd.weight") || !strcmp(t->name, "output.weight"))) continue;   /* the model's own are used */
                if (g_q38_gg_mtp_layer < 0 && !strncmp(t->name, hp, strlen(hp))) { head++; continue; }   /* the head, not attached */
                fprintf(stderr, "[gguf] not used by the engine: %s\n", t->name); unused++;
            }
        if (head) fprintf(stderr, "[gguf] the MTP head's %d tensors (%s*) stay unread: it is not attached\n", head, hp);
        if (unused && getenv("GGUF_STRICT") && getenv("GGUF_STRICT")[0] == '1') return 3;
    }
    q38_tier_start(&m, cap);   /* COLI_CUDA=1: hot experts stream to VRAM (qwen36_tier.c) */
    if (g_q38_mux_slots>1 && m.dn_dev) {
        m.dn_dev=0;
        fprintf(stderr, "[qwen38] KV_SLOTS=%d: DeltaNet on the CPU (Q38_DN_GPU keeps one conversation's state on the card)\n",
                g_q38_mux_slots);
    }
    q38_trunk_cpu_int8(&m);    /* the trunk's int8 rows on the CPU, BF16 released (Q38_TRUNK_CPU_INT8=0 keeps BF16) */
    q38_draft_head_build(&m);  /* Q38_DRAFT_HEAD=int4: the MTP drafts' lm_head in int4 */
#ifdef COLI_CUDA
    /* COLI_CUDA_CHAIN=1: every layer on the device as one chain (qwen38_cuda_chain.h), set up
     * now that the tier placed the trunk and the CPU holds its int8 rows (the chain's own
     * copies of the rest come from the same bytes) */
    if (q38cc_env_on() && q38cc_setup(&m, g_q38_mux_slots)) { g_cuda_chain=1; atexit(cc_shutdown); }
    /* The MTP head stays on the CPU beside the CUDA chain, and its drafts cost more than they
     * save there (an RTX PRO 4000, Qwen3.8-Flash-Next IQ2_XS with the host pool: plain decode
     * 46-48 tok/s, the head's drafts 42.5-44.7, the prompt 180 against 150 tok/s as the head
     * reads every prompt row): unset, Q38_MTP leaves it off as beside the Vulkan chain. */
    if (g_cuda_chain && m.mtp && !(getenv("Q38_MTP") && *getenv("Q38_MTP"))) {
        m.mtp = 0;
        fprintf(stderr, "[qwen38] speculative decoding with the MTP head: off (the CUDA chain runs every layer on the device, "
                        "the head would run on the CPU; Q38_MTP=1 drafts)\n");
    }
#endif
    if(m.mtp&&getenv("Q38_MTP_DUMP")&&*getenv("Q38_MTP_DUMP")){
        g_q38_mtp_dump=fopen(getenv("Q38_MTP_DUMP"),"wb");
        if(!g_q38_mtp_dump){perror(getenv("Q38_MTP_DUMP"));return 1;}
    }
    q38_vocab_decide(&m, snap);   /* the draft list or the whole vocabulary, before COLI_VK_DENSE_HOST releases the lm_head rows */
    q38_expert_report(&m, cap);         /* expert format, bytes per expert, what the cache costs */
#ifdef COLI_VULKAN
    /* After the trunk is int8: those rows upload at their first matmul. No
     * device (or COLI_VULKAN unset) leaves g_vk_ready 0, the CPU path. */
    g_vk_ready=coli_vk_init_env_tier("qwen38",vkt_wanted()&&m.c.experts>0&&!qt_ready());
    g_vk_dense=coli_vk_dense();   /* COLI_VK_DENSE; unset, off on a device sharing the CPU's RAM with the tier on */
    /* COLI_VK_CHAIN: every layer's dense chain on the device (qwen38_chain.h); the CUDA
     * tier keeps its priority */
    /* measured on a Radeon 780M: prefill faster, decode slower in either mode, so opt-in on an
     * integrated GPU, and on by default from many compute units (docs/vulkan.md, "The dense chain") */
    if(g_vk_ready&&!qt_ready())
        g_vk_chain=coli_vk_chain_decide("qwen38",vkt_wanted()&&m.c.experts>0,
                                        coli_vk_device_igpu_many_cu()?COLI_VK_CHAIN_ON:COLI_VK_CHAIN_OFF);
    if(g_vk_chain&&g_q38_mux_slots>1){
        g_vk_chain=0;
        fprintf(stderr,"[VK] qwen38: KV_SLOTS=%d: the dense chain is off (it keeps one conversation's state on the device); "
                       "the expert tier runs every conversation's experts\n",g_q38_mux_slots);
    }
    q38c_start(&m);      /* the layers that fit the device, before anything of the chain goes up (a partial chain placed now; qwen38_chain.h) */
    if(g_vk_chain&&!vkc_init())g_vk_chain=0;
    q38_dho_start(&m);   /* COLI_VK_DENSE_HOST: the trunk on the device only, before the tier sizes its budget */
#endif
    if(is_ref)ref_logits=read_reference_logits(ref_root,m.c.vocab);
    g_capture_last_logit=ref_logits!=NULL||getenv("DUMP")!=NULL;
    if(is_ref){g_q38_mtp_oracle=full;g_q38_mtp_oracle_n=nfull;}   /* Q38_MTP_FORCE=accept|mixed */
    int64_t hist = q38_telemetry_init(snap, &m);
    if (g_q38_gguf_tier) q38_tier_warm(&m, hist > 0);   /* the CUDA tier's warm start, the history's most used experts first */
#ifdef COLI_CUDA
    if (g_cuda_chain) q38cc_pool_init(&m);    /* the experts the card leaves, in RAM it reads over the bus */
#endif
    q38_vocab_init(snap, &m);
#ifdef COLI_VULKAN
    q38_vk_tier_start(&m, cap);   /* COLI_VULKAN=1: hot routed experts on the device (vk_tier.c) */
    if(g_vk_ready&&!vkt_ready()&&!g_vk_dense)g_vk_dense=coli_vk_dense_decide("qwen38",0,1);   /* no tier after all */
    if(g_vk_chain)atexit(vkc_shutdown_all);   /* registered after the tier's: runs before the device goes */
#endif
    {   /* the trunk's int8 rows interleaved for the CPU, when no device reads them as rows */
        int dev=qt_ready();
#ifdef COLI_VULKAN
        dev=dev||g_vk_ready;
#endif
        if(!dev)q38_trunk_q8_interleave(&m);
    }
    fprintf(stderr, "resident weights loaded in %.1fs | RSS after load: %.2f GB\n", m.dense_load_s, rss_gb());

    /* coli serve mode: speak the gateway wire protocol instead of argv
     * generation. AFTER the tier init: serve sessions ride the VRAM experts
     * exactly like argv runs, and serve_loop never returns. */
    if (getenv("SERVE") && getenv("SERVE")[0] == '1') {
        if (!g_tok) { fprintf(stderr, "[serve] tokenizer.json required (put in SNAP or set TOK)\n");
            q38_model_free(&m); rt_destroy(); return 1; }
        coli_rt_term_arm();   /* SIGTERM must reach the save below (#1629) */
        serve_loop(&m);
        rt_save(g_q38_usage, 0);
        q38_vocab_save(&m);
        q38_prefix_cache_release(&m);
        q38_model_free(&m); free_tokenizer(); rt_destroy();
        return 0;
    }

    if (is_ref && getenv("PPL") && atoi(getenv("PPL")) == 1) {
        double nll; double t = now_s();
        int scored = tf_nll(&m, full, nfull, np, &nll);
        double dt = now_s() - t;
        double tot = m.hits + m.miss;
        printf("TF-NLL: %.4f nats/token over %d tokens | ppl = %.2f\n", nll, scored, exp(nll));
        qt_stats();   /* VRAM tier hits/misses/swaps, if on */
        printf("Expert cache hit rate: %.1f%% (hit=%llu miss=%llu)\n", tot?100.0*m.hits/tot:0.0,
               (unsigned long long)m.hits, (unsigned long long)m.miss);
        printf("Speed: %.2f tok/s (%.1fs for %d tokens) | PEAK RSS: %.2f GB\n", scored/dt, dt, scored, rss_gb());
#ifdef COLI_CUDA
        q38cc_report(&m);
#endif
#ifdef COLI_VULKAN
        q38_vk_report();
        q38c_report(&m);
        vkt_report("run", m.hits, m.miss);
#endif
        rt_save(g_q38_usage,0);
        q38_vocab_save(&m);
        q38_model_free(&m); free(prompt); free(full); json_free(ref_root);
        free(buf); free(arena); free_tokenizer(); rt_destroy(); return 0;
    }

    q38_validate_ids(&m.c,prompt,np,"prompt_ids");
    if(is_ref) q38_validate_ids(&m.c,full,nfull,"full_ids");
    int total_tokens=q38_context_total(&m.c,np,n_new,"generation");
    out = malloc((size_t)total_tokens * sizeof(int));
    if(!out){fprintf(stderr,"OOM allocating generation token buffer\n");
        q38_model_free(&m); free(prompt); free(full); json_free(ref_root);
        free(buf); free(arena); free_tokenizer(); rt_destroy(); return 1;}
    /* timing + OpenAI id setup (before generation) */
    g_ttft = -1; g_gen_t0 = now_s();
    if (g_openai){
        g_oa_created = (long)time(NULL);
        snprintf(g_oa_id,sizeof g_oa_id,"chatcmpl-%ld%04d",g_oa_created,
                 q38_completion_nonce(now_s()));
    }
    /* streaming text: emit tokens as they are produced (text mode + tokenizer only) */
    if (!is_ref && g_tok && !getenv("NOSTREAM")) {
        g_stream = 1; g_sbn = 0;
        if (g_openai){
            char *model=json_escape_alloc((const unsigned char*)g_model,strlen(g_model));
            char *jb=model?q38_format_alloc(
              "{\"id\":\"%s\",\"object\":\"chat.completion.chunk\",\"created\":%ld,\"model\":\"%s\","
              "\"choices\":[{\"index\":0,\"delta\":{\"role\":\"assistant\"},\"finish_reason\":null}]}",
              g_oa_id,g_oa_created,model):NULL;
            free(model);if(!jb){fprintf(stderr,"[openai] out of memory formatting response\n");exit(1);}
            sse_chunk(jb);free(jb);
        } else {
            fprintf(stderr, "Generated (%d new tokens):\nText : ", n_new); fflush(stderr);
        }
    }
    double t = now_s();
    generate(&m, prompt, np, n_new, out);
    double dt = now_s() - t;

    /* DUMP=<path>: write last-token logits (raw float32, vocab) for a torch-free
     * cosine comparison against tools/_ref_dn.py --dump. */
    if (g_last_logit && getenv("DUMP")) {
        const char *dp = getenv("DUMP");
        FILE *df = fopen(dp && *dp ? dp : "qwen38_logits.f32", "wb");
        if (df) { fwrite(g_last_logit, sizeof(float), (size_t)m.c.vocab, df); fclose(df);
                  fprintf(stderr, "[dump] wrote %d logits -> %s\n", m.c.vocab, dp && *dp ? dp : "qwen38_logits.f32"); }
        else fprintf(stderr, "[dump] cannot open %s\n", dp ? dp : "qwen38_logits.f32");
    }

    int ref_match = 0,ref_numeric_match=1;
    if (is_ref) {
        int match = 0;
        printf("\nReference: ");  for (int i=np;i<nfull;i++) printf("%d ", full[i]);
        printf("\nC engine : ");  for (int i=np;i<nfull;i++) { printf("%d ", out[i]); if (out[i]==full[i]) match++; }
        if (g_tok) { printf("Text      : "); print_decoded(stdout,out,np,nfull); printf("\n"); }
        printf("\nMatching tokens: %d/%d\n", match, n_new);
        if(ref_logits)ref_numeric_match=compare_reference_logits(g_last_logit,ref_logits);
        ref_match = match;
    } else {
    if (g_openai) {
        emit_openai_result(out, np, n_new, g_stream);
    } else if (g_stream) {
        stream_flush(); fprintf(stderr, "\n");
    } else {
        fprintf(stderr, "\nGenerated (%d new tokens):\n", n_new);
        if (g_tok) { fprintf(stderr,"Text      : "); print_decoded(stderr,out,np,np+n_new); fprintf(stderr,"\n"); }
        else { fprintf(stderr, "Ids       : "); for (int i=np;i<np+n_new;i++) fprintf(stderr, "%d ", out[i]); fprintf(stderr, "\n"); }
    }
    }
    double tot = m.hits + m.miss;
    if (g_ttft >= 0) fprintf(stderr, "TTFT: %.2f s (time to first token)\n", g_ttft);
    q38_spec_report(&m, &g_q38_run_spec, "run");
    q38_vocab_report(&m, "run");
    q38_spec_free(&g_q38_run_spec);
    if (g_q38_mtp_dump) { fclose(g_q38_mtp_dump); g_q38_mtp_dump = NULL; }
    tm_report(&m);
    fprintf(stderr, "\nPEAK RSS: %.2f GB\n", rss_gb());
    qt_stats();   /* VRAM tier hits/misses/swaps, if on */
    fprintf(stderr, "Expert cache hit rate: %.1f%% (hit=%llu miss=%llu)\n", tot?100.0*m.hits/tot:0.0,
           (unsigned long long)m.hits, (unsigned long long)m.miss);
    fprintf(stderr, "Speed: %.2f tok/s (%.1fs for %d tokens)\n", n_new/dt, dt, n_new);
#ifdef COLI_CUDA
    q38cc_report(&m);
#endif
#ifdef COLI_VULKAN
    q38_vk_report();
    q38c_report(&m);
    vkt_report("run", m.hits, m.miss);
#endif
    rt_save(g_q38_usage, 0);
    q38_vocab_save(&m);
    free(g_last_logit); g_last_logit=NULL;
    q38_model_free(&m); free(out); free(prompt); free(full); json_free(ref_root);
    free(buf); free(arena); free_tokenizer(); rt_destroy();
    /* Oracle mode is a gate, not a report: a mismatch must fail the caller.
     * inkling.c does the same (`return (match == ngen) ? 0 : 1;`) and its CI
     * job relies on it — without this, tools/make_qwen38_oracle.py could be
     * wired into a workflow that stays green through any regression. */
    if (is_ref) return ref_match == n_new && ref_numeric_match ? 0 : 1;
    return 0;
}
#endif /* QWEN38_TEST_SERVE */
#endif /* !QWEN38_NO_MAIN || QWEN38_TEST_SERVE */
#if defined(QWEN38_NO_MAIN) && !defined(QWEN38_TEST_SERVE)
/* q38_state_later (above) counts what a serve allocates once it runs; a test build has no
 * serve, and the tier's start (below) still asks */
static size_t q38_state_later(Model *m){ (void)m; return 0; }
#endif

static int q38_u64_mul(uint64_t left,uint64_t right,uint64_t *out){
    if(!out||(right&&left>UINT64_MAX/right))return -1;*out=left*right;return 0;
}
static int q38_u64_add(uint64_t *total,uint64_t value){
    if(!total||*total>UINT64_MAX-value)return -1;*total+=value;return 0;
}

static int q38_segment_tensor_storage_valid(const st_tensor *tensor){
    uint64_t expected_bytes;
    if(!tensor||tensor->dtype<0||tensor->dtype>6||tensor->numel<1||
       tensor->nbytes<1||q38_u64_mul((uint64_t)tensor->numel,
                                    (uint64_t)st_dtype_esz(tensor->dtype),
                                    &expected_bytes)||
       expected_bytes>INT64_MAX)return 0;
    return tensor->nbytes==(int64_t)expected_bytes;
}

enum {
    Q38_EXPERT_FP8_BLOCK = 1u << 0,
    Q38_EXPERT_FP8_EXPANDED = 1u << 1,
    Q38_EXPERT_BF16 = 1u << 2,
    Q38_EXPERT_F16 = 1u << 3,
    Q38_EXPERT_F32 = 1u << 4
};

/* Return the bytes retained by one cache matrix after loading.  The source
 * dtype alone is not enough: native FP8 retains its F32 block scales, native
 * BF16 retains two-byte elements, and both opt-out modes retain expanded F32.
 * Keeping this calculation beside the loader's representation choices makes
 * Segment's memory contract describe the allocation it actually performs. */
static int q38_segment_matrix_bytes(Model *m,const char *weight_name,
                                    int rows,int cols,uint64_t *bytes,
                                    unsigned *numeric_kinds){
    uint64_t elements;
    if(!m||!weight_name||!bytes||!numeric_kinds||rows<1||cols<1||
       q38_u64_mul((uint64_t)rows,(uint64_t)cols,&elements)||
       elements>INT64_MAX)return -1;
    st_tensor *weight=st_find(&m->S,weight_name);
    if(!weight||!q38_segment_tensor_storage_valid(weight)||
       (weight->dtype>2&&weight->dtype!=4)||weight->rank!=2||
       weight->shape[0]!=rows||weight->shape[1]!=cols||
       weight->numel!=(int64_t)elements)return -1;
    if(weight->dtype==4){
        char scale_name[340];
        int length=snprintf(scale_name,sizeof scale_name,"%s_scale_inv",weight_name);
        int64_t block_rows=fp8_nblk(rows),block_cols=fp8_nblk(cols);
        st_tensor *scale=length>0&&(size_t)length<sizeof scale_name?
                         st_find(&m->S,scale_name):NULL;
        if(!scale||scale->dtype<0||scale->dtype>2||scale->rank!=2||
           scale->shape[0]!=block_rows||scale->shape[1]!=block_cols||
           scale->numel!=block_rows*block_cols||
           !q38_segment_tensor_storage_valid(scale))return -1;
        if(m->native_fp8){
            uint64_t scale_bytes;
            if(q38_u64_mul((uint64_t)scale->numel,sizeof(float),&scale_bytes)||
               q38_u64_add(&elements,scale_bytes))return -1;
            *bytes=elements;*numeric_kinds|=Q38_EXPERT_FP8_BLOCK;
        }else{
            if(q38_u64_mul(elements,sizeof(float),bytes))return -1;
            *numeric_kinds|=Q38_EXPERT_FP8_EXPANDED;
        }
        return 0;
    }
    if(weight->dtype<0||weight->dtype>2)return -1;
    uint64_t element_bytes=weight->dtype==0&&m->native_bf16?
                           sizeof(uint16_t):sizeof(float);
    if(q38_u64_mul(elements,element_bytes,bytes))return -1;
    *numeric_kinds|=weight->dtype==0?Q38_EXPERT_BF16:
                    weight->dtype==1?Q38_EXPERT_F16:Q38_EXPERT_F32;
    return 0;
}

static int q38_segment_fused_matrix_bytes(Model *m,const st_tensor *tensor,
                                          int64_t elements,uint64_t *bytes,
                                          unsigned *numeric_kinds){
    if(!m||!bytes||!numeric_kinds||!tensor||tensor->dtype<0||
       tensor->dtype>2||elements<1||elements>tensor->numel||
       !q38_segment_tensor_storage_valid(tensor))return -1;
    uint64_t element_bytes=tensor->dtype==0&&m->native_bf16?
                           sizeof(uint16_t):sizeof(float);
    if(q38_u64_mul((uint64_t)elements,element_bytes,bytes))return -1;
    *numeric_kinds|=tensor->dtype==0?Q38_EXPERT_BF16:
                    tensor->dtype==1?Q38_EXPERT_F16:Q38_EXPERT_F32;
    return 0;
}

/* Sum the maximum possible resident expert slot for every layer in the loaded
 * range.  Individual-expert containers are allowed to be heterogeneous, so a
 * layer is priced at its largest expert rather than assuming expert zero is
 * representative.  Fused containers have one dtype/geometry for every expert. */
static int q38_segment_expert_layout(Model *m,uint32_t begin,uint32_t end,
                                     uint64_t *bytes_per_capacity,
                                     uint64_t *fixed_scale_bytes,
                                     unsigned *numeric_kinds){
    if(!m||!bytes_per_capacity||!fixed_scale_bytes||!numeric_kinds||begin>=end||
       end>(uint32_t)q38_layer_rows(m))return -1;
    Cfg *c=&m->c;uint64_t range_bytes=0,range_scales=0;unsigned kinds=0;
    for(uint32_t layer=begin;layer<end;layer++){
        char name[320];q38_name(m,name,sizeof name,(int)layer,
                                "mlp.experts.gate_up_proj");
        st_tensor *gate_up=st_find(&m->S,name);uint64_t layer_bytes=0;
        if(gate_up){
            if(gate_up->rank!=3||gate_up->shape[0]!=c->experts||
               gate_up->shape[1]!=(int64_t)2*c->inter||
               gate_up->shape[2]!=c->hidden)return -1;
            uint64_t part;
            if(q38_segment_fused_matrix_bytes(m,gate_up,
                 (int64_t)2*c->inter*c->hidden,&part,&kinds)||
               q38_u64_add(&layer_bytes,part))return -1;
            q38_name(m,name,sizeof name,(int)layer,"mlp.experts.down_proj");
            st_tensor *down=st_find(&m->S,name);
            if(!down||down->rank!=3||down->shape[0]!=c->experts||
               down->shape[1]!=c->hidden||down->shape[2]!=c->inter||
               q38_segment_fused_matrix_bytes(m,down,
                    (int64_t)c->hidden*c->inter,&part,&kinds)||
               q38_u64_add(&layer_bytes,part))return -1;
        }else{
            const char *projection[3]={"gate_proj","up_proj","down_proj"};
            int rows[3]={c->inter,c->inter,c->hidden};
            int cols[3]={c->hidden,c->hidden,c->inter};
            int all_native_fp8=m->native_fp8;
            for(int expert=0;expert<c->experts;expert++){
                uint64_t expert_bytes=0;
                for(int projection_index=0;projection_index<3;projection_index++){
                    char suffix[192];
                    int length=snprintf(suffix,sizeof suffix,
                        "mlp.experts.%d.%s.weight",expert,
                        projection[projection_index]);
                    if(length<0||(size_t)length>=sizeof suffix)return -1;
                    q38_name(m,name,sizeof name,(int)layer,suffix);
                    st_tensor *weight=st_find(&m->S,name);
                    if(!weight||weight->dtype!=4)all_native_fp8=0;
                    uint64_t part;
                    if(q38_segment_matrix_bytes(m,name,rows[projection_index],
                         cols[projection_index],&part,&kinds)||
                       q38_u64_add(&expert_bytes,part))return -1;
                }
                if(expert_bytes>layer_bytes)layer_bytes=expert_bytes;
            }
            if(all_native_fp8){
                uint64_t scale_count=(uint64_t)fp8_nblk(c->inter)*
                                     (uint64_t)fp8_nblk(c->hidden);
                uint64_t per_slot_scales,layer_scale_bank;
                if(q38_u64_mul(3u,scale_count,&per_slot_scales)||
                   q38_u64_mul(per_slot_scales,sizeof(float),&per_slot_scales)||
                   layer_bytes<per_slot_scales||
                   q38_u64_mul(per_slot_scales,(uint64_t)c->experts,
                               &layer_scale_bank)||
                   q38_u64_add(&range_scales,layer_scale_bank))return -1;
                /* Eligible checkpoints borrow normalized scales from one
                 * per-layer bank, so only raw FP8 payload belongs to a slot.
                 * Charging the full bank even for a repacked checkpoint that
                 * later falls back is conservative and keeps tight Segment
                 * memory limits safe. */
                layer_bytes-=per_slot_scales;
            }
        }
        if(!layer_bytes||q38_u64_add(&range_bytes,layer_bytes))return -1;
    }
    *bytes_per_capacity=range_bytes;*fixed_scale_bytes=range_scales;
    *numeric_kinds=kinds;return 0;
}

/* Said once at startup: the representation the routed-expert cache holds,
 * what one expert costs in it, what the cache costs full at this cap, and
 * how many experts per layer the RAM still available now (resident weights
 * loaded, cache empty) would hold at that size -- the number a cap is chosen
 * against, and the one the int4-g64 sidecar moves. */
static void q38_expert_report(Model *m, int cap) {
    Cfg *c = &m->c;
    int layers = m->range_end - m->range_begin;
    if (g_q38_gguf) {
        char nm[3][64]; const char *kn[3] = {"ffn_gate_exps", "ffn_up_exps", "ffn_down_exps"};
        uint64_t bytes = 0; const gguf_tensor *t[3];
        for (int k = 0; k < 3; k++) {
            snprintf(nm[k], sizeof nm[k], "blk.%d.%s.weight", m->range_begin, kn[k]);
            t[k] = gguf_find(&g_q38gg, nm[k]);
            if (t[k]) bytes += (uint64_t)(t[k]->nbytes / c->experts);
        }
        fprintf(stderr, "[qwen38] routed experts: GGUF %s/%s/%s (layer %d), %.2f MiB per expert; cache %d/layer\n",
                t[0] ? gq_type_name(t[0]->type) : "?", t[1] ? gq_type_name(t[1]->type) : "?",
                t[2] ? gq_type_name(t[2]->type) : "?", m->range_begin, bytes / 1048576.0, cap);
        return;
    }
    uint64_t per_capacity = 0, fixed = 0, snapshot_expert = 0;
    unsigned kinds = 0;
    if (layers < 1) return;
    if (!q38_segment_expert_layout(m, (uint32_t)m->range_begin, (uint32_t)m->range_end,
                                   &per_capacity, &fixed, &kinds))
        snapshot_expert = per_capacity / (uint64_t)layers;
    const char *what = kinds == Q38_EXPERT_FP8_BLOCK ? "native FP8" :
                       kinds == Q38_EXPERT_FP8_EXPANDED ? "FP8 expanded to f32 (Q38_NATIVE_FP8=0)" :
                       kinds == Q38_EXPERT_BF16 ? (m->native_bf16 ? "BF16" : "BF16 expanded to f32") :
                       kinds == Q38_EXPERT_F16 || kinds == Q38_EXPERT_F32 ? "f32" : "mixed";
    uint64_t per_expert = snapshot_expert;
    char extra[160] = "";
    if (m->x4) {
        per_expert = (uint64_t)m->x4->record_bytes;
        snprintf(extra, sizeof extra, " (the snapshot's %s: %llu bytes)", what,
                 (unsigned long long)snapshot_expert);
        what = m->x4->lb ? m->x4->lb->dir : "int4-g64 from " Q38_INT4_DIR "/";   /* and no FP8 scale bank is built */
    } else if (fixed) {
        snprintf(extra, sizeof extra, " + %.1f MiB resident scale bank", fixed / 1048576.0);
    }
    if (!per_expert) {
        fprintf(stderr, "[qwen38] routed experts: %s, size unknown; cache %d/layer\n", what, cap);
        return;
    }
    double full = (double)per_expert * (double)cap * (double)layers;
    fprintf(stderr, "[qwen38] routed experts: %s, %llu bytes (%.2f MiB) per expert%s; "
                    "cache %d/layer x %d layers = %.2f GiB full",
            what, (unsigned long long)per_expert, per_expert / 1048576.0, extra,
            cap, layers, full / 1073741824.0);
    double available = compat_mem_available_gb() * 1e9;
    if (available > 0) {
        double room = available / ((double)per_expert * (double)layers);
        int holds = room > (double)c->experts ? c->experts : (int)room;
        fprintf(stderr, "; %.1f GB available now holds %d/layer", available / 1e9, holds);
    }
    fprintf(stderr, "\n");
}

/* ---- the Vulkan routed-expert tier (vk_tier.c) ---------------------------------
 * After the dense trunk is int8, the device is open and the history is read: tell
 * the tier how this snapshot's experts sit in RAM, what else will live on the
 * device, and how much RAM the expert cache may still take; then fill it from the
 * history, reading the planned experts straight from the files (not through the
 * LRU, which keeps its own working set). The MTP head's layer goes on the tier as
 * an extra layer, its experts in the form the snapshot keeps them (FP8 beside the
 * int4 sidecar); it has no history, so the drafts fill it. */
#ifdef COLI_VULKAN
static void q38_vk_dense_add(const Q38Weight *w,size_t *bytes){
    if(!w||!q38_vk_eligible(w))return;
    *bytes+=w->q8?(size_t)w->rows*w->cols+(size_t)w->rows*sizeof(float):(size_t)q38_weight_bytes(w);
}
static size_t q38_vk_dense_bytes(Model *m){
    size_t b=0;
    if(!g_vk_dense&&!g_vk_chain)return 0;
    if(coli_vk_dense_device_only())return 0;   /* placed already (q38_dho_start): the free memory the tier reads counts them */
    if(g_q38_vk_noup)return 0;   /* a partial chain placed its layers already, and nothing else goes up */
    q38_vk_dense_add(&m->lm_head,&b);
    const GatedResidual *f=&m->final_gr;
    q38_vk_dense_add(&f->down,&b);q38_vk_dense_add(&f->up,&b);q38_vk_dense_add(&f->inject,&b);
    for(int i=0;i<q38_layer_rows(m);i++){
        const Layer *L=&m->L[i];
        const Q38Weight *w[]={&L->router,&L->sh_g,&L->sh_u,&L->sh_d,&L->q,&L->k,&L->v,&L->o,&L->idx_qk,
                              &L->dn_qkv,&L->dn_z,&L->dn_b,&L->dn_a,&L->dn_out,&L->ple_key,&L->ple_value,
                              &L->attn_gr.down,&L->attn_gr.up,&L->attn_gr.inject,
                              &L->mlp_gr.down,&L->mlp_gr.up,&L->mlp_gr.inject};
        for(size_t k=0;k<sizeof w/sizeof *w;k++)q38_vk_dense_add(w[k],&b);
    }
    if(m->mtp){
        q38_vk_dense_add(&m->mtp_fc_emb,&b);q38_vk_dense_add(&m->mtp_fc_hid,&b);
        q38_vk_dense_add(&m->mtp_mixer.down,&b);q38_vk_dense_add(&m->mtp_mixer.up,&b);
    }
    return b;
}
/* One planned expert read without the LRU: the int4 record, or the native FP8
 * ranges with the layer's scale bank. buf holds the bytes; 0 when this layout has
 * no direct read (the caller loads it through a temporary slot instead). */
static int q38_vk_read_direct(Model *m,int layer,int e,uint8_t *buf,int64_t cap,VktExpertSrc *src){
    Cfg *c=&m->c;
    if(q38_layer_int4(m,layer)){
        Q38Int4Experts *x=m->x4;
        if(x->record_bytes>cap)return 0;
        st_read_range_raw_cap(&x->S,x->fd[layer],x->off[(int64_t)layer*c->experts+e],x->record_bytes,buf,cap,1,
                              "pread Qwen3.8 int4 expert (Vulkan tier)");
        const float *sc=(const float*)(buf+x->scale_off);
        *src=(VktExpertSrc){buf,buf+x->code_bytes[0],buf+x->code_bytes[0]+x->code_bytes[1],
                            sc,sc+x->scale_count[0],sc+x->scale_count[0]+x->scale_count[1]};
        return 1;
    }
    st_tensor *w[3];
    if(!q38_native_fp8_expert_tensors(m,layer,e,w)||m->expert_scales[layer].ready!=1)return 0;
    int64_t pair=w[0]->nbytes+w[1]->nbytes;
    if(pair+w[2]->nbytes>cap)return 0;
    st_read_range_raw_cap(&m->S,w[0]->fd,w[0]->off,pair,buf,cap,1,"pread Qwen3.8 gate/up expert (Vulkan tier)");
    st_read_range_raw_cap(&m->S,w[2]->fd,w[2]->off,w[2]->nbytes,buf+pair,cap-pair,1,"pread Qwen3.8 down expert (Vulkan tier)");
    const Q38ExpertScaleCache *bank=&m->expert_scales[layer];
    const float *sc=bank->values+(int64_t)e*3*bank->scale_count;
    *src=(VktExpertSrc){buf,buf+w[0]->nbytes,buf+pair,sc,sc+bank->scale_count,sc+2*bank->scale_count};
    return 1;
}
/* Is the expert in this layer's RAM cache now (the tier's balance asks)? */
static int q38_vk_in_ram(void *ctx,int layer,int e){
    Model *m=(Model*)ctx; LCache *lc=&m->cache[layer];
    int si=lc->by_expert?lc->by_expert[e]:-1;
    return si>=0&&si<lc->n&&lc->slots[si].eid==e;
}
/* The tier's host pool took `bytes` of the RAM the expert cache was sized from (vk_tier.h,
 * ram_given): fewer slots a layer, top-k at least (COLI_VK_TIER_HOST_GB sizes the pool
 * instead, and the cache keeps its size). */
static size_t g_q38_vk_slot_bytes;
static void q38_vk_ram_given(void *ctx,size_t bytes){
    Model *m=(Model*)ctx;Cfg *c=&m->c;int L=0,was=0,now=0;
    for(int i=0;m->cache&&i<c->layers;i++)L+=m->cache[i].slots!=NULL;
    if(L<1||!g_q38_vk_slot_bytes)return;
    const size_t per=g_q38_vk_slot_bytes*(size_t)L;
    const int cut=(int)((bytes+per-1)/per);
    for(int i=0;i<c->layers;i++){
        LCache *lc=&m->cache[i];
        if(!lc->slots)continue;
        int cap=lc->cap-cut;
        if(cap<c->topk)cap=c->topk;
        if(cap<lc->n)cap=lc->n;   /* slots filled already stay */
        if(cap>lc->cap)cap=lc->cap;
        was=lc->cap;now=cap;lc->cap=cap;
    }
    fprintf(stderr,"[VK] qwen38: the tier's host pool took %.1f GiB of the RAM the expert cache was sized from: %d slots a layer, not %d\n",
            bytes/1073741824.0,now,was);
}
/* The tier's streaming (a big prompt chunk's cold experts on the device): an expert's
 * bytes as the CPU path has them, through the layer's RAM cache (a slot stays valid
 * until the next load); several at once through the parallel reads. */
static int q38_vk_load(void *ctx,int layer,int e,VktExpertSrc *src,void **h){
    Model *m=(Model*)ctx;Slot *s=q38_expert_get(m,layer,e);
    if(!s)return 0;
    *src=q38_vk_src(s);*h=s;return 1;
}
static void q38_vk_release(void *ctx,void *h){(void)ctx;q38_vk_src_done((Slot*)h);}   /* GGUF: the int8-g32 copy the tier read */
static int q38_vk_load_batch(void *ctx,int layer,const int *e,int n,VktExpertSrc *srcs,void **h){
    Model *m=(Model*)ctx;Slot *sl[64];
    if(n>m->cache[layer].cap)n=m->cache[layer].cap;
    if(n<2||n>64||!q38_expert_get_batch(m,layer,e,n,sl))return 0;
    for(int i=0;i<n;i++){srcs[i]=q38_vk_src(sl[i]);h[i]=sl[i];}
    return n;
}
/* The GGUF experts of layers [begin,end) as the device takes them: their ggml blocks, gate
 * and up of one type in a layer, whole blocks in both widths. The types may change from
 * layer to layer (published files give a few layers bigger ones): *gu, *dn the commonest
 * layer's, lgu/ldn [end-begin] every layer's, *mixed whether they differ (lgu NULL: they
 * may not). *ram_expert: the biggest expert's bytes in RAM. 0 when they do not go raw. */
static int q38_vk_gguf_fmts(Model *m,int begin,int end,VktFmt *gu,VktFmt *dn,size_t *ram_expert,
                            VktFmt *lgu,VktFmt *ldn,int *mixed){
    Cfg *c=&m->c;int n=end-begin,mx=0,best=0,bestn=0;
    const char *e=getenv("COLI_VK_GGUF_RAW");
    if(e&&e[0]=='0')return 0;
    if(begin>=c->layers&&g_q38_gg_mtp_layer<0)return 0;
    int *ty=(int*)malloc((size_t)n*2*sizeof(int));
    if(!ty)return 0;
    *ram_expert=0;
    for(int l=begin;l<end;l++){
        const gguf_tensor *t[3];q38_gg_expert_tensors(m,l,t);
        int bg=coli_vk_block_elems(100+t[0]->type),bd=coli_vk_block_elems(100+t[2]->type);
        if(t[0]->type!=t[1]->type||!bg||!bd||c->hidden%bg||c->inter%bd){free(ty);return 0;}
        size_t b=0;for(int k=0;k<3;k++)b+=(size_t)(t[k]->nbytes/c->experts);
        if(b>*ram_expert)*ram_expert=b;
        ty[2*(l-begin)]=t[0]->type;ty[2*(l-begin)+1]=t[2]->type;
        if(ty[2*(l-begin)]!=ty[0]||ty[2*(l-begin)+1]!=ty[1])mx=1;
    }
    if(mx&&!lgu){free(ty);return 0;}
    for(int a=0;a<n;a++){
        int k=0;for(int b=0;b<n;b++)k+=ty[2*b]==ty[2*a]&&ty[2*b+1]==ty[2*a+1];
        if(k>bestn){bestn=k;best=a;}
        if(lgu){lgu[a]=(VktFmt){(VktSrc)(VKT_SRC_GGML+ty[2*a]),0};ldn[a]=(VktFmt){(VktSrc)(VKT_SRC_GGML+ty[2*a+1]),0};}
    }
    gu->kind=(VktSrc)(VKT_SRC_GGML+ty[2*best]);gu->gs=0;dn->kind=(VktSrc)(VKT_SRC_GGML+ty[2*best+1]);dn->gs=0;
    if(mixed)*mixed=mx;
    free(ty);
    return 1;
}
/* The tier's source form of layers [begin,end)'s routed experts as the snapshot
 * keeps them (not the int4 sidecar's), and one expert's bytes in RAM; VKT_SRC_NONE
 * when they mix formats. */
static VktFmt q38_vk_native_fmt(Model *m,int begin,int end,size_t *ram_expert){
    Cfg *c=&m->c;int H=c->hidden,F=c->inter;
    uint64_t per_capacity=0,fixed=0;unsigned kinds=0;
    VktFmt f={VKT_SRC_NONE,0};
    if(g_q38_gguf){   /* the ggml blocks go to the device as int8 per 32 (q38_vk_src); in RAM, what the file holds */
        if(begin>=c->layers&&g_q38_gg_mtp_layer<0)return f;
        const gguf_tensor *t[3]; q38_gg_expert_tensors(m,begin,t);
        *ram_expert=0; for(int k=0;k<3;k++)*ram_expert+=(size_t)(t[k]->nbytes/c->experts);
        f.kind=VKT_SRC_I8_GS; f.gs=32; (void)H; (void)F; return f;
    }
    if(q38_segment_expert_layout(m,(uint32_t)begin,(uint32_t)end,&per_capacity,&fixed,&kinds))return f;
    if(kinds==Q38_EXPERT_FP8_BLOCK&&m->native_fp8){
        for(int l=begin;l<end;l++)
            if(!q38_prepare_expert_scale_bank(m,l))return f;
        f.kind=VKT_SRC_FP8_BLOCK; f.gs=FP8_BLOCK; *ram_expert=(size_t)3*H*F;
    } else if(kinds==Q38_EXPERT_BF16&&m->native_bf16){ f.kind=VKT_SRC_BF16; *ram_expert=(size_t)3*H*F*2; }
    else if(kinds==Q38_EXPERT_BF16||kinds==Q38_EXPERT_F16||kinds==Q38_EXPERT_F32||kinds==Q38_EXPERT_FP8_EXPANDED){
        f.kind=VKT_SRC_F32; *ram_expert=(size_t)3*H*F*4;
    }
    return f;
}
/* the context the chain's KV mirror will hold: the cache's when it is there, else what a
 * server allocates at its start (q38_serve_ensure_kv) */
static int q38_vk_chain_ctx(const Model *m){
    if(m->max_t>0)return m->max_t;
    int n=qwen38_max_ctx();
    return n>m->c.max_positions?m->c.max_positions:n;
}
static void q38_vk_tier_start(Model *m,int cap){
    if(!g_vk_ready||qt_ready()){
        if(g_vk_ready&&qt_ready())
            fprintf(stderr,"[VK] tier qwen38: the CUDA expert tier is on and wins; the Vulkan tier stays off\n");
        return;
    }
    Cfg *c=&m->c;int H=c->hidden,F=c->inter,mixed=0;
    VktFmt f={VKT_SRC_NONE,0},fd;size_t ram_expert=0;
    /* a GGUF's types by layer, for the tier when they differ */
    VktFmt *lgu=g_q38_gguf?(VktFmt*)malloc((size_t)c->layers*sizeof(VktFmt)):NULL,
           *ldn=g_q38_gguf?(VktFmt*)malloc((size_t)c->layers*sizeof(VktFmt)):NULL;
    if(m->x4&&m->x4->lb&&m->x4->lb->vq==2){
        fprintf(stderr,"[VK] tier qwen38: the vq1 experts have no device form yet; they stay on the CPU\n");
        free(lgu);free(ldn);return;
    }
    if(m->x4&&m->x4->lb&&m->x4->lb->vq&&coli_vk_set_vq2_books(&m->x4->vqb->a[0][0],&m->x4->vqb->b[0][0])){
        fprintf(stderr,"[VK] tier qwen38: the device's block table already holds other vq2 codebooks; the experts stay on the CPU\n");
        free(lgu);free(ldn);return;
    }
    if(m->x4&&m->x4->lb){
        /* colibri's low-bit experts: the same codes and scales on the device (blockdec.glsl;
         * vq2's codebooks in its table buffer, set above) */
        f.kind=m->x4->lb->vq?VKT_SRC_LB_VQ2:!strcmp(m->x4->lb->name,"int2g32")?VKT_SRC_LB_I2G32:
               !strcmp(m->x4->lb->name,"int2g16")?VKT_SRC_LB_I2G16:VKT_SRC_LB_I3G16;
        f.gs=0;ram_expert=(size_t)m->x4->record_bytes;
    }
    else if(m->x4){ f.kind=VKT_SRC_I4U_PLANAR64; f.gs=64; ram_expert=(size_t)m->x4->record_bytes; }
    else if(g_q38_gguf&&lgu&&ldn&&q38_vk_gguf_fmts(m,0,c->layers,&f,&fd,&ram_expert,lgu,ldn,&mixed)){
        g_q38_vk_raw=1;
        int same=0;for(int l=0;l<c->layers;l++)same+=lgu[l].kind==f.kind&&ldn[l].kind==fd.kind;
        fprintf(stderr,"[VK] tier qwen38: the GGUF experts' blocks go to the device as the file has them (%s gate/up, %s down",
                gq_type_name((int)(f.kind-VKT_SRC_GGML)),gq_type_name((int)(fd.kind-VKT_SRC_GGML)));
        if(mixed)fprintf(stderr," on %d of %d layers, the others their own types",same,c->layers);
        fprintf(stderr,"; COLI_VK_GGUF_RAW=0: int8 per 32)\n");
    }
    else f=q38_vk_native_fmt(m,0,c->layers,&ram_expert);
    if(!g_q38_vk_raw)fd=f;
    if(!mixed){free(lgu);free(ldn);lgu=ldn=NULL;}
    if(f.kind==VKT_SRC_NONE){
        fprintf(stderr,"[VK] tier qwen38: the routed experts mix formats; they stay on the CPU\n");
        free(lgu);free(ldn);
        return;
    }
    /* the MTP head's layer (index c->layers): by default on a discrete GPU only. On a
     * Radeon 780M (shared RAM) it ran 3.44 tok/s against 3.48 on the CPU, its share of
     * the budget taken from the model's layers; COLI_VK_TIER_MTP=1 or 0 decides. */
    VktFmt fm={VKT_SRC_NONE,0};size_t ram_mtp=0;
    const char *tm=getenv("COLI_VK_TIER_MTP");
    int want_mtp=tm&&*tm?*tm!='0':!coli_vk_device_shares_ram();
    VktFmt fmd={VKT_SRC_NONE,0};
    if(m->mtp&&want_mtp){
        if(g_q38_vk_raw){ if(!q38_vk_gguf_fmts(m,c->layers,c->layers+1,&fm,&fmd,&ram_mtp,NULL,NULL,NULL))fm.kind=VKT_SRC_NONE; }
        else { fm=q38_vk_native_fmt(m,c->layers,c->layers+1,&ram_mtp); fmd=fm; }
        if(fm.kind==VKT_SRC_NONE)fprintf(stderr,"[VK] tier qwen38: the MTP head's experts mix formats; they stay on the CPU\n");
    }
    g_q38_vk_slot_bytes=ram_expert;
    int igpu=q38_mtp_igpu_wanted(m,coli_vk_device_igpu_many_cu(),g_vk_chain==COLI_VK_CHAIN_ON);
    VktConfig vc={.engine="qwen38",.layers=c->layers,.experts=c->experts,.hidden=H,.inter=F,.topk=c->topk,
                  .gate_up=f,.down=fd,.act=VKT_ACT_SWIGLU,
                  .extra_layers=fm.kind!=VKT_SRC_NONE,.extra_gate_up=fm,.extra_down=fmd,
                  .extra_whole=q38c_mtp_planned(m),   /* the head's layer on the device: its experts whole, in the frame */
                  .max_rows=q38_moe_prefill_rows(c,q38_prefill_batch_rows())*c->topk,
                  .ram_reserve=q38_vk_tier_ram_reserve(m,cap,ram_expert,igpu),
                  .ram_floor=q38_vk_tier_ram_reserve(m,c->topk,ram_expert,igpu),.ram_given=q38_vk_ram_given,
                  .ram_later=q38_state_later(m),
                  .dense_bytes=q38_vk_dense_bytes(m),
                  .chain_bytes=g_vk_chain?q38c_late_bytes(m,q38_vk_chain_ctx(m)):0,
                  .stage=g_vk_chain,   /* the chain stages a prompt chunk's host pool experts */
                  .in_ram=q38_vk_in_ram,.ram_ctx=m,
                  .load=q38_vk_load,.release=q38_vk_release,.load_ctx=m,.load_batch=q38_vk_load_batch,
                  .layer_gate_up=lgu,.layer_down=ldn};
    if(vc.max_rows<64)vc.max_rows=64;
    uint32_t **heat=rt_counts_all();
    atexit(coli_vk_shutdown);   /* before vkt_init, which makes the expert batch's pipelines and can still refuse (no room): the device goes at exit either way, after the tier's teardown */
    int tier_on=vkt_init(&vc,heat);
    free(lgu);free(ldn);   /* read during vkt_init only */
    if(!tier_on)return;
    atexit(vkt_shutdown);
    if(igpu)q38_mtp_igpu_defaults(m);   /* the tier is up and has left room for the cache of the head */
    /* the warm start: the history's hottest experts, read in parallel */
    int all=(c->layers+(m->mtp?1:0))*c->experts,*pl=(int*)malloc((size_t)all*sizeof(int)),*pe=(int*)malloc((size_t)all*sizeof(int));
    if(!pl||!pe){free(pl);free(pe);return;}
    const char *warm=getenv("COLI_VK_TIER_WARM");   /* 0: no warm start, the tier fills as experts pass by */
    int n=warm&&*warm=='0'?0:vkt_plan(pl,pe,all);
    if(n>0){
        double t0=now_s();
        int64_t bufb=m->x4?m->x4->record_bytes:(int64_t)3*H*F;
        int direct=(m->x4&&!m->x4->lb)||f.kind==VKT_SRC_FP8_BLOCK;   /* the int4 record or FP8 ranges read straight */
        if(direct){
            #pragma omp parallel
            {
                uint8_t *buf=(uint8_t*)malloc((size_t)bufb);
                #pragma omp for schedule(dynamic,4)
                for(int i=0;i<n;i++){
                    VktExpertSrc src;
                    if(buf&&q38_vk_read_direct(m,pl[i],pe[i],buf,bufb,&src))vkt_put(pl[i],pe[i],&src);
                    else vkt_put(pl[i],pe[i],NULL);
                }
                free(buf);
            }
        } else {
            /* BF16/f32 experts (the small fixtures): through a temporary slot, serially */
            for(int i=0;i<n;i++){
                Slot tmp; memset(&tmp,0,sizeof tmp);
                q38_load_expert(m,pl[i],pe[i],&tmp);
                VktExpertSrc src=q38_vk_src(&tmp); vkt_put(pl[i],pe[i],&src); q38_vk_src_done(&tmp);
                q38_weight_free(&tmp.gate);q38_weight_free(&tmp.up);q38_weight_free(&tmp.down);
                free(tmp.fp8_slab);free(tmp.int4_slab);
            }
        }
        vkt_put_done();
        vkt_warm_report("qwen38", n, now_s() - t0);
    }
    free(pl);free(pe);
}
#endif


static int q38_segment_cache_capacity(uint64_t bytes_per_capacity,
                                      uint64_t fixed_scale_bytes,int experts,
                                      uint64_t memory_limit,int *capacity){
    if(!bytes_per_capacity||experts<1||!capacity)return -1;
    if(!memory_limit){*capacity=1;return 0;}
    if(memory_limit<=fixed_scale_bytes)return -1;
    uint64_t slots=(memory_limit-fixed_scale_bytes)/bytes_per_capacity;
    if(!slots)return -1;
    if(slots>(uint64_t)experts)slots=(uint64_t)experts;
    *capacity=(int)slots;return 0;
}

static void q38_segment_numeric_class(char *out,size_t capacity,
                                      unsigned numeric_kinds){
    const char *known=NULL;
    switch(numeric_kinds){
        case Q38_EXPERT_FP8_BLOCK:
            known="qwen38/fp8-block-f32dot-f64blocksum/cpu-v1";break;
        case Q38_EXPERT_FP8_EXPANDED:
            known="qwen38/fp8-expanded-f32dot/cpu-v1";break;
        case Q38_EXPERT_BF16:
            known="qwen38/bf16-values-f32dot/cpu-v1";break;
        case Q38_EXPERT_F16:
            known="qwen38/f16-expanded-f32dot/cpu-v1";break;
        case Q38_EXPERT_F32:
            known="qwen38/f32dot/cpu-v1";break;
        default:
            /* The bitset is part of this opaque compatibility identifier. In
             * particular, FP8_BLOCK and FP8_EXPANDED are different bits, so a
             * heterogeneous range cannot silently change its reduction rules
             * while continuing to claim snapshot/numeric compatibility. */
            snprintf(out,capacity,"qwen38/mixed-expert-arithmetic-%02x/cpu-v1",
                     numeric_kinds);return;
    }
    snprintf(out,capacity,"%s",known);
}

static int q38_segment_cache_resize(Model *m,int capacity){
    if(!m||capacity<1)return -1;
    for(int layer=m->range_begin;layer<m->range_end;layer++){
        LCache *cache=&m->cache[layer];
        if(cache->n||q38_cache_slots_set(cache,capacity))return -1;
    }
    return 0;
}

static int q38_segment_session_state_bytes(const Cfg *c,uint32_t begin,
                                            uint32_t end,uint32_t context,
                                            uint64_t *out){
    if(!c||!out||begin>=end||end>(uint32_t)c->layers||!context)return -1;
    uint64_t total=0,cells,bytes;
    for(uint32_t layer=begin;layer<end;layer++){
        if(c->is_attn[layer]){
            if(q38_u64_mul((uint64_t)c->kv_heads,context,&cells)||
               q38_u64_mul(cells,(uint64_t)c->head_dim,&cells)||
               q38_u64_mul(cells,2u*sizeof(float),&bytes)||
               q38_u64_add(&total,bytes)||
               q38_u64_mul(context,(uint64_t)c->idx_dim,&cells)||
               q38_u64_mul(cells,sizeof(float),&bytes)||q38_u64_add(&total,bytes))return -1;
        }else{
            if(q38_u64_mul((uint64_t)c->dn_vheads,(uint64_t)c->dn_kdim,&cells)||
               q38_u64_mul(cells,(uint64_t)c->dn_vdim,&cells)||
               q38_u64_mul(cells,sizeof(float),&bytes)||q38_u64_add(&total,bytes)||
               q38_u64_mul((uint64_t)c->dn_conv_dim,(uint64_t)(c->dn_convk-1),&cells)||
               q38_u64_mul(cells,sizeof(float),&bytes)||q38_u64_add(&total,bytes))return -1;
        }
    }
    if(c->ple_layer>=0&&(uint32_t)c->ple_layer>=begin&&(uint32_t)c->ple_layer<end){
        if(q38_u64_mul((uint64_t)c->hc_width,(uint64_t)(c->ple_convk-1),&cells)||
           q38_u64_mul(cells,(uint64_t)c->ngram_size,&cells)||
           q38_u64_mul(cells,sizeof(float),&bytes)||q38_u64_add(&total,bytes)||
           q38_u64_add(&total,2u*sizeof(int64_t)+sizeof(int)))return -1;
    }
    *out=total;return 0;
}

#ifdef COLI_SEGMENT_ADAPTER
/* ---------- engine-owned Segment adapter ------------------------------ */

typedef struct {
    Model model;
    uint32_t layer_begin, layer_end, context_tokens;
    pthread_mutex_t run_lock;
} Qwen38SegmentEngine;

typedef struct {
    Qwen38SegmentEngine *engine;
    float **K, **V, **IK, **DN_rec, **DN_conv;
    int64_t ple_history[2];
    int ple_history_len;
    float *PLE_conv_state;
    uint32_t context_tokens, position;
} Qwen38SegmentSession;

static void qwen38_segment_session_state_free(Qwen38SegmentSession *s) {
    if (!s) return;
    Cfg *c=&s->engine->model.c;
    for (uint32_t i=s->engine->layer_begin;i<s->engine->layer_end;i++) {
        free(s->K ? s->K[i] : NULL); free(s->V ? s->V[i] : NULL); free(s->IK ? s->IK[i] : NULL);
        free(s->DN_rec ? s->DN_rec[i] : NULL); free(s->DN_conv ? s->DN_conv[i] : NULL);
    }
    free(s->K); free(s->V); free(s->IK); free(s->DN_rec); free(s->DN_conv);
    (void)c;
    free(s->PLE_conv_state);
}

static int qwen38_segment_engine_open(
    void **engine_impl, ColiSegmentCapabilities *capabilities,
    const ColiSegmentEngineOptions *options, char *error, size_t error_size) {
    if (!engine_impl || !capabilities || !options || !options->model_dir)
        return coli_segment_adapter_error(error,error_size,"invalid Qwen3.8 Segment open");
    *engine_impl=NULL;
    if (options->backend_mask && (options->backend_mask & ~COLI_SEGMENT_CAP_CPU))
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment currently supports CPU");
    Cfg probe; q38_load_cfg(&probe,options->model_dir); q38_validate_cfg(&probe);
    int layers=probe.layers, maxctx=probe.max_positions;
    uint32_t end=options->layer_end ? options->layer_end : (uint32_t)layers;
    if (options->layer_begin>=end || end>(uint32_t)layers){free(probe.is_attn);
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment range exceeds model");
    }
    if (!options->context_tokens || options->context_tokens>(uint32_t)maxctx || options->context_tokens>INT_MAX){free(probe.is_attn);
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment context exceeds model limit");
    }
    free(probe.is_attn);
    Qwen38SegmentEngine *e=(Qwen38SegmentEngine*)calloc(1,sizeof(*e));
    if(!e) return coli_segment_adapter_error(error,error_size,"out of memory opening Qwen3.8 Segment");
    e->layer_begin=options->layer_begin; e->layer_end=end; e->context_tokens=options->context_tokens;
    if(pthread_mutex_init(&e->run_lock,NULL)){free(e);return coli_segment_adapter_error(error,error_size,"cannot initialize Qwen3.8 Segment lock");}
    /* Open with a single empty cache slot so tensor metadata and the effective
     * native-storage switches are available before honoring the caller's
     * budget. No expert is loaded during model_init_range, so resizing here
     * cannot discard data or perturb LRU state. */
    model_init_range(&e->model,options->model_dir,1,8,
                     (int)e->layer_begin,(int)e->layer_end,0,0);
    uint64_t bytes_per_capacity=0,fixed_scale_bytes=0;
    unsigned numeric_kinds=0;int cap=1;
    if(q38_segment_expert_layout(&e->model,e->layer_begin,e->layer_end,
                                 &bytes_per_capacity,&fixed_scale_bytes,
                                 &numeric_kinds)){
        q38_model_free(&e->model);pthread_mutex_destroy(&e->run_lock);free(e);
        return coli_segment_adapter_error(error,error_size,
            "Qwen3.8 Segment checkpoint has an unsupported expert layout");
    }
    if(q38_segment_cache_capacity(bytes_per_capacity,fixed_scale_bytes,
                                  e->model.c.experts,
                                  options->memory_limit_bytes,&cap)){
        q38_model_free(&e->model);pthread_mutex_destroy(&e->run_lock);free(e);
        return coli_segment_adapter_error(error,error_size,
            "Qwen3.8 Segment memory limit cannot hold one expert per loaded layer");
    }
    if(cap!=1&&q38_segment_cache_resize(&e->model,cap)){
        q38_model_free(&e->model);pthread_mutex_destroy(&e->run_lock);free(e);
        return coli_segment_adapter_error(error,error_size,
            "out of memory sizing Qwen3.8 Segment expert cache");
    }
    e->model.max_t=(int)e->context_tokens; e->model.kv_cap=(int)e->context_tokens;
    memset(capabilities,0,sizeof(*capabilities)); capabilities->struct_size=sizeof(*capabilities);
    capabilities->abi_version=COLI_SEGMENT_ABI_VERSION;
    capabilities->flags=COLI_SEGMENT_CAP_TOKEN_IDS|COLI_SEGMENT_CAP_SNAPSHOT|COLI_SEGMENT_CAP_RANGE_NATIVE|
                        COLI_SEGMENT_CAP_MULTI_SESSION|COLI_SEGMENT_CAP_CPU;
    coli_segment_capability_string(capabilities->engine_id,sizeof(capabilities->engine_id),"qwen38");
    coli_segment_capability_string(capabilities->state_schema,sizeof(capabilities->state_schema),"qwen38/hyper-kv-deltanet-ple-f32-v1");
    q38_segment_numeric_class(capabilities->numeric_class,
                              sizeof(capabilities->numeric_class),numeric_kinds);
    capabilities->state_dtype=COLI_SEGMENT_DTYPE_F32; capabilities->state_width=(uint32_t)e->model.c.hc_width;
    capabilities->max_batch_rows=128; capabilities->max_context_tokens=(uint32_t)maxctx; capabilities->num_layers=(uint32_t)layers;
    *engine_impl=e; return 0;
}

static void qwen38_segment_engine_destroy(void *impl) {
    Qwen38SegmentEngine *e=(Qwen38SegmentEngine*)impl; if(!e)return;
    q38_model_free(&e->model); pthread_mutex_destroy(&e->run_lock); free(e);
}

static int qwen38_segment_session_create(void *impl,void **out,const ColiSegmentSessionOptions *options,char *error,size_t error_size) {
    Qwen38SegmentEngine *e=(Qwen38SegmentEngine*)impl;
    if(!e||!out||!options)
        return coli_segment_adapter_error(error,error_size,"invalid Qwen3.8 Segment session context");
    *out=NULL;
    if(!options->context_tokens||options->context_tokens>e->context_tokens)
        return coli_segment_adapter_error(error,error_size,"invalid Qwen3.8 Segment session context");
    uint64_t state_bytes=0;
    if(q38_segment_session_state_bytes(&e->model.c,e->layer_begin,e->layer_end,
                                       options->context_tokens,&state_bytes))
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 session state size overflow");
    if(options->memory_limit_bytes&&state_bytes>options->memory_limit_bytes)
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 session state exceeds memory limit");
    Qwen38SegmentSession *s=(Qwen38SegmentSession*)calloc(1,sizeof(*s)); if(!s)return coli_segment_adapter_error(error,error_size,"out of memory creating Qwen3.8 session");
    s->engine=e;s->context_tokens=options->context_tokens;
    int n=e->model.c.layers; s->K=(float**)calloc((size_t)n,sizeof(float*));s->V=(float**)calloc((size_t)n,sizeof(float*));s->IK=(float**)calloc((size_t)n,sizeof(float*));
    s->DN_rec=(float**)calloc((size_t)n,sizeof(float*));s->DN_conv=(float**)calloc((size_t)n,sizeof(float*));
    if(!s->K||!s->V||!s->IK||!s->DN_rec||!s->DN_conv)goto oom;
    Cfg *c=&e->model.c;
    for(uint32_t i=e->layer_begin;i<e->layer_end;i++){
        size_t cells,bytes;
        if(c->is_attn[i]){
            if(coli_segment_size_mul((size_t)c->kv_heads,s->context_tokens,&cells)||coli_segment_size_mul(cells,(size_t)c->head_dim,&cells))goto oom;
            if(coli_segment_size_mul(cells,sizeof(float),&bytes))goto oom;
            s->K[i]=(float*)calloc(cells,sizeof(float));s->V[i]=(float*)calloc(cells,sizeof(float));
            if(coli_segment_size_mul((size_t)s->context_tokens,(size_t)c->idx_dim,&cells)||coli_segment_size_mul(cells,sizeof(float),&bytes))goto oom;s->IK[i]=(float*)calloc(cells,sizeof(float));
            if(!s->K[i]||!s->V[i]||!s->IK[i])goto oom;
        }else{
            if(coli_segment_size_mul((size_t)c->dn_vheads,(size_t)c->dn_kdim,&cells)||coli_segment_size_mul(cells,(size_t)c->dn_vdim,&cells))goto oom;s->DN_rec[i]=(float*)calloc(cells,sizeof(float));
            if(coli_segment_size_mul(cells,sizeof(float),&bytes))goto oom;
            if(coli_segment_size_mul((size_t)c->dn_conv_dim,(size_t)c->dn_convk-1,&cells)||coli_segment_size_mul(cells,sizeof(float),&bytes))goto oom;s->DN_conv[i]=(float*)calloc(cells,sizeof(float));
            if(!s->DN_rec[i]||!s->DN_conv[i])goto oom;
        }
    }
    if(c->ple_layer>=0&&(uint32_t)c->ple_layer>=e->layer_begin&&(uint32_t)c->ple_layer<e->layer_end){
        size_t cells,bytes;if(coli_segment_size_mul((size_t)c->hc_width,(size_t)c->ple_convk-1,&cells)||coli_segment_size_mul(cells,(size_t)c->ngram_size,&cells)||coli_segment_size_mul(cells,sizeof(float),&bytes))goto oom;
        s->PLE_conv_state=(float*)calloc(cells,sizeof(float));if(!s->PLE_conv_state)goto oom;
    }
    *out=s;return 0;
oom:qwen38_segment_session_state_free(s);free(s);return coli_segment_adapter_error(error,error_size,"out of memory allocating Qwen3.8 state");
}

static void qwen38_segment_session_destroy(void *impl){Qwen38SegmentSession *s=(Qwen38SegmentSession*)impl;if(!s)return;qwen38_segment_session_state_free(s);free(s);}

static int qwen38_segment_session_run(void *impl,const ColiSegmentRunRequest *r,char *error,size_t error_size){
    Qwen38SegmentSession *s=(Qwen38SegmentSession*)impl; Qwen38SegmentEngine *e=s?s->engine:NULL; Cfg *c=e?&e->model.c:NULL;
    if(!s||!r||r->position!=s->position)return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment requires contiguous positions");
    if(!r->rows||r->rows>128||r->rows>s->context_tokens||
       r->position>s->context_tokens-r->rows||!r->input||!r->output||
       !r->token_ids||r->token_count!=r->rows)
        return coli_segment_adapter_error(error,error_size,"invalid Qwen3.8 Segment run request");
    size_t cells,bytes;if(coli_segment_size_mul((size_t)r->rows,(size_t)c->hc_width,&cells)||coli_segment_size_mul(cells,sizeof(float),&bytes)||r->input_bytes!=bytes||r->output_bytes!=bytes)
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment activation size mismatch");
    for(uint32_t i=0;i<r->rows;i++)if(r->token_ids[i]<0||r->token_ids[i]>=c->vocab)return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment token id outside vocabulary");
    if(r->should_cancel&&r->should_cancel(r->cancel_user_data))return coli_segment_adapter_error(error,error_size,"Qwen3.8 Segment run cancelled");
    if(r->output!=r->input)memcpy(r->output,r->input,bytes);
    pthread_mutex_lock(&e->run_lock); Model *m=&e->model;
    m->K=s->K;m->V=s->V;m->IK=s->IK;m->DN_rec=s->DN_rec;m->DN_conv=s->DN_conv;m->ple_history=s->ple_history;m->ple_history_len=s->ple_history_len;m->PLE_conv_state=s->PLE_conv_state;m->kv_cap=(int)s->context_tokens;m->kv_len=(int)s->position;
    q38_layers_forward_range(m,(float*)r->output,r->token_ids,(int)r->rows,(int)r->position,(int)e->layer_begin,(int)e->layer_end);
    s->ple_history_len=m->ple_history_len;m->K=NULL;m->V=NULL;m->IK=NULL;m->DN_rec=NULL;m->DN_conv=NULL;m->ple_history=NULL;m->PLE_conv_state=NULL;m->kv_len=0;
    pthread_mutex_unlock(&e->run_lock);s->position+=r->rows;return 0;
}

static int qwen38_segment_spans(Qwen38SegmentSession *s,uint32_t position,ColiSegmentStateSpan **out,size_t *count,char *error,size_t error_size){
    Cfg *c=&s->engine->model.c;
    if(position>s->context_tokens)return coli_segment_adapter_error(error,error_size,"Qwen3.8 snapshot position exceeds context");
    size_t cap=0;
    for(uint32_t i=s->engine->layer_begin;i<s->engine->layer_end;i++){
        size_t add=2;
        if(c->is_attn[i]){
            /* One indexer span plus one K and one V span for every KV head. */
            if((uint64_t)c->kv_heads>(SIZE_MAX-1)/2)
                return coli_segment_adapter_error(error,error_size,"Qwen3.8 state span count overflow");
            add=2*(size_t)c->kv_heads+1;
        }
        if(add>SIZE_MAX-cap){return coli_segment_adapter_error(error,error_size,"Qwen3.8 state span count overflow");}
        cap+=add;
    }
    if(c->ple_layer>=0&&(uint32_t)c->ple_layer>=s->engine->layer_begin&&(uint32_t)c->ple_layer<s->engine->layer_end){if(cap>SIZE_MAX-3)return coli_segment_adapter_error(error,error_size,"Qwen3.8 state span count overflow");cap+=3;}
    if(cap>SIZE_MAX/sizeof(ColiSegmentStateSpan))return coli_segment_adapter_error(error,error_size,"Qwen3.8 state span count overflow");
    ColiSegmentStateSpan *v=(ColiSegmentStateSpan*)calloc(cap,sizeof(*v));if(cap&&!v)return coli_segment_adapter_error(error,error_size,"out of memory describing Qwen3.8 state");size_t n=0;
    for(uint32_t i=s->engine->layer_begin;i<s->engine->layer_end;i++)if(c->is_attn[i]){
        size_t cells,rb,stride;
        if(coli_segment_size_mul((size_t)position,(size_t)c->head_dim,&cells)||coli_segment_size_mul(cells,sizeof(float),&rb)||coli_segment_size_mul((size_t)s->context_tokens,(size_t)c->head_dim,&stride)){free(v);return coli_segment_adapter_error(error,error_size,"Qwen3.8 attention state size overflow");}
        for(int h=0;h<c->kv_heads;h++){v[n++]=(ColiSegmentStateSpan){s->K[i]+(size_t)h*stride,rb};v[n++]=(ColiSegmentStateSpan){s->V[i]+(size_t)h*stride,rb};}
        if(coli_segment_size_mul((size_t)position,(size_t)c->idx_dim,&cells)||coli_segment_size_mul(cells,sizeof(float),&cells)){free(v);return coli_segment_adapter_error(error,error_size,"Qwen3.8 indexer state size overflow");} v[n++]=(ColiSegmentStateSpan){s->IK[i],cells};
    }else{
        size_t cells;
        if(coli_segment_size_mul((size_t)c->dn_vheads,(size_t)c->dn_kdim,&cells)||coli_segment_size_mul(cells,(size_t)c->dn_vdim,&cells)||coli_segment_size_mul(cells,sizeof(float),&cells)){free(v);return coli_segment_adapter_error(error,error_size,"Qwen3.8 recurrent state size overflow");} v[n++]=(ColiSegmentStateSpan){s->DN_rec[i],cells};
        if(coli_segment_size_mul((size_t)c->dn_conv_dim,(size_t)c->dn_convk-1,&cells)||coli_segment_size_mul(cells,sizeof(float),&cells)){free(v);return coli_segment_adapter_error(error,error_size,"Qwen3.8 convolution state size overflow");} v[n++]=(ColiSegmentStateSpan){s->DN_conv[i],cells};
    }
    if(c->ple_layer>=0&&(uint32_t)c->ple_layer>=s->engine->layer_begin&&(uint32_t)c->ple_layer<s->engine->layer_end){v[n++]=(ColiSegmentStateSpan){&s->ple_history_len,sizeof(s->ple_history_len)};v[n++]=(ColiSegmentStateSpan){s->ple_history,sizeof(s->ple_history)};size_t cells;if(coli_segment_size_mul((size_t)c->hc_width,(size_t)c->ple_convk-1,&cells)||coli_segment_size_mul(cells,(size_t)c->ngram_size,&cells)||coli_segment_size_mul(cells,sizeof(float),&cells)){free(v);return coli_segment_adapter_error(error,error_size,"Qwen3.8 PLE state size overflow");}v[n++]=(ColiSegmentStateSpan){s->PLE_conv_state,cells};}
    if(n!=cap){free(v);return coli_segment_adapter_error(error,error_size,"Qwen3.8 state span topology mismatch");}
    *out=v;*count=n;return 0;
}

static int qwen38_segment_session_snapshot(void *impl,ColiSegmentWriteFn wf,void *wd,char *error,size_t es){Qwen38SegmentSession *s=(Qwen38SegmentSession*)impl;ColiSegmentStateSpan *sp=NULL;size_t n=0,bytes=0;if(!s||qwen38_segment_spans(s,s?s->position:0,&sp,&n,error,es)||coli_segment_spans_size(sp,n,&bytes)){free(sp);return coli_segment_adapter_error(error,es,"Qwen3.8 snapshot size overflow");}ColiSegmentSnapshotHeader h;coli_segment_snapshot_header_init(&h,"qwen38",s->engine->layer_begin,s->engine->layer_end,s->context_tokens,s->position,bytes,coli_segment_spans_hash(sp,n));int rc=coli_segment_stream_write(wf,wd,&h,sizeof(h),error,es);if(!rc)rc=coli_segment_spans_write(sp,n,wf,wd,error,es);free(sp);return rc;}

static int qwen38_segment_payload_valid(
    const ColiSegmentStateSpan *spans,size_t count,
    const unsigned char *payload,size_t payload_bytes,
    void *user_data,char *error,size_t error_size){
    Qwen38SegmentSession *s=(Qwen38SegmentSession*)user_data;
    const unsigned char *cursor=payload; size_t consumed=0;
    int found_len=0,found_history=0;
    int history_len=0; int64_t history[2]={0,0};
    for(size_t i=0;i<count;i++){
        if(spans[i].size>payload_bytes-consumed)
            return coli_segment_adapter_error(error,error_size,"Qwen3.8 snapshot payload layout is invalid");
        if(spans[i].data==&s->ple_history_len&&spans[i].size==sizeof(history_len)){
            memcpy(&history_len,cursor,sizeof(history_len));found_len=1;
        }else if(spans[i].data==s->ple_history&&spans[i].size==sizeof(history)){
            memcpy(history,cursor,sizeof(history));found_history=1;
        }
        cursor+=spans[i].size;consumed+=spans[i].size;
    }
    if(!s->PLE_conv_state)return 0;
    Cfg *c=&s->engine->model.c;
    if(!found_len||!found_history||history_len<0||history_len>2||
       (history_len>0&&(history[0]<0||history[0]>=c->vocab))||
       (history_len>1&&(history[1]<0||history[1]>=c->vocab)))
        return coli_segment_adapter_error(error,error_size,"Qwen3.8 snapshot PLE history is invalid");
    return 0;
}

static int qwen38_segment_session_restore(void *impl,ColiSegmentReadFn rf,void *rd,char *error,size_t es){
    Qwen38SegmentSession *s=(Qwen38SegmentSession*)impl; ColiSegmentSnapshotHeader h;
    if(!s||coli_segment_stream_read(rf,rd,&h,sizeof(h),error,es))return -1;
    if(h.position>s->context_tokens||h.layer_begin!=s->engine->layer_begin||
       h.layer_end!=s->engine->layer_end||h.context_tokens!=s->context_tokens)
        return coli_segment_adapter_error(error,es,"Qwen3.8 snapshot identity is incompatible");
    ColiSegmentStateSpan *sp=NULL; size_t n=0,bytes=0;
    if(qwen38_segment_spans(s,h.position,&sp,&n,error,es)||
       coli_segment_spans_size(sp,n,&bytes)||
       coli_segment_snapshot_header_valid(&h,"qwen38",s->engine->layer_begin,
                                          s->engine->layer_end,s->context_tokens,
                                          bytes,error,es)){
        free(sp);return -1;
    }
    int rc=coli_segment_spans_restore_checked(
        sp,n,h.payload_hash,rf,rd,qwen38_segment_payload_valid,s,error,es);
    free(sp);if(rc)return rc;
    s->position=h.position;return 0;
}

static const ColiSegmentAdapter qwen38_segment_adapter={sizeof(ColiSegmentAdapter),COLI_SEGMENT_ABI_VERSION,"qwen38",qwen38_segment_engine_open,qwen38_segment_engine_destroy,qwen38_segment_session_create,qwen38_segment_session_destroy,qwen38_segment_session_run,qwen38_segment_session_snapshot,qwen38_segment_session_restore,{0}};
int coli_qwen38_segment_adapter_register(void){return coli_segment_adapter_register(&qwen38_segment_adapter);}
#endif /* COLI_SEGMENT_ADAPTER */

#ifdef COLI_EDGE_ADAPTER
/* ---------- engine-owned model Edge adapter --------------------------- */

typedef struct {
    Model model;
} Qwen38EdgeEngine;

/* Edge owns only the tokenizer and boundary tensors.  Do not call
 * q38_model_free(): a boundary-only model deliberately has no Layer/cache
 * arrays, and keeping this destructor explicit makes it impossible for a
 * later core change to make the Edge process load or free transformer state. */
static void qwen38_edge_engine_destroy(void *engine_impl) {
    Qwen38EdgeEngine *engine=(Qwen38EdgeEngine*)engine_impl;
    if(!engine)return;
    Model *model=&engine->model;
    q38_weight_free(&model->embed);
    q38_weight_free(&model->lm_head);
    free(model->final_gr.norm);
    q38_weight_free(&model->final_gr.down);
    q38_weight_free(&model->final_gr.up);
    free(model->c.is_attn);
    st_destroy(&model->S);
    free_tokenizer();
    free(engine);
}

static int qwen38_edge_engine_open(
    void **engine_impl,ColiEdgeCapabilities *capabilities,
    const ColiEdgeEngineOptions *options,char *error,size_t error_size) {
    if(!engine_impl||!capabilities||!options||!options->model_dir)
        return coli_edge_adapter_error(error,error_size,
                                       "invalid Qwen3.8 Edge open");
    *engine_impl=NULL;
    if(options->backend_mask&&(options->backend_mask&~COLI_EDGE_CAP_CPU))
        return coli_edge_adapter_error(error,error_size,
                                       "Qwen3.8 Edge supports CPU only");
    /* The production tokenizer is process-global.  Segment-only engines do
     * not touch it, so a distributed process may host every Segment adapter
     * plus one Qwen3.8 Edge engine without cross-wiring vocabularies. */
    if(g_tok)
        return coli_edge_adapter_error(error,error_size,
                                       "a Qwen3.8 tokenizer is already active");
    Qwen38EdgeEngine *engine=(Qwen38EdgeEngine*)calloc(1,sizeof(*engine));
    if(!engine)
        return coli_edge_adapter_error(error,error_size,
                                       "out of memory opening Qwen3.8 Edge");
    Model *model=&engine->model;
    model->native_bf16=q38_env_bool("Q38_NATIVE_BF16",1);
    model->native_fp8=q38_env_bool("Q38_NATIVE_FP8",1);
    q38_load_cfg(&model->c,options->model_dir);
    q38_validate_cfg(&model->c);
    st_init(&model->S,options->model_dir);
    if(st_has(&model->S,"model.language_model.embed_tokens.weight"))
        snprintf(model->prefix,sizeof model->prefix,"model.language_model");
    else if(st_has(&model->S,"model.embed_tokens.weight"))
        snprintf(model->prefix,sizeof model->prefix,"model");
    else {
        qwen38_edge_engine_destroy(engine);
        return coli_edge_adapter_error(error,error_size,
            "Qwen3.8 checkpoint has no text embedding");
    }

    Cfg *config=&model->c;char name[320];
    snprintf(name,sizeof name,"%s.embed_tokens.weight",model->prefix);
    model->embed=q38_load_weight(model,name,config->vocab,config->hidden);
    model->lm_head=q38_load_weight(model,"lm_head.weight",
                                   config->vocab,config->hidden);
    q38_load_gr(model,&model->final_gr,-1,NULL,0);

    char tokenizer_path[4096];
    int path_length=snprintf(tokenizer_path,sizeof tokenizer_path,
                             "%s/tokenizer.json",options->model_dir);
    if(path_length<0||(size_t)path_length>=sizeof tokenizer_path||
       load_tokenizer(tokenizer_path)) {
        qwen38_edge_engine_destroy(engine);
        return coli_edge_adapter_error(error,error_size,
                                       "cannot load Qwen3.8 tokenizer");
    }

    uint64_t resident=model->resident_weight_bytes;
    uint64_t norm_bytes=(uint64_t)config->hc_width*sizeof(float);
    if(resident>UINT64_MAX-norm_bytes) {
        qwen38_edge_engine_destroy(engine);
        return coli_edge_adapter_error(error,error_size,
                                       "Qwen3.8 Edge resident size overflows");
    }
    resident+=norm_bytes;
    if(options->memory_limit_bytes&&resident>options->memory_limit_bytes) {
        qwen38_edge_engine_destroy(engine);
        return coli_edge_adapter_error(error,error_size,
                                       "Qwen3.8 Edge exceeds memory limit");
    }

    /* Numeric compatibility includes the actual routed-expert representation
     * even though Edge does not load those tensors.  This must be byte-for-byte
     * identical to the full Segment range or the runtime refuses the pairing. */
    uint64_t slot_bytes=0,fixed_scale_bytes=0;unsigned numeric_kinds=0;
    if(q38_segment_expert_layout(model,0,(uint32_t)config->layers,
                                 &slot_bytes,&fixed_scale_bytes,
                                 &numeric_kinds)) {
        qwen38_edge_engine_destroy(engine);
        return coli_edge_adapter_error(error,error_size,
            "Qwen3.8 Edge checkpoint has an unsupported expert layout");
    }
    (void)slot_bytes;(void)fixed_scale_bytes;

    memset(capabilities,0,sizeof(*capabilities));
    capabilities->struct_size=sizeof(*capabilities);
    capabilities->abi_version=COLI_EDGE_ABI_VERSION;
    capabilities->flags=COLI_EDGE_CAP_TOKENIZE|COLI_EDGE_CAP_DETOKENIZE|
                        COLI_EDGE_CAP_GREEDY|COLI_EDGE_CAP_CPU;
    coli_edge_capability_string(capabilities->engine_id,
                                sizeof(capabilities->engine_id),"qwen38");
    coli_edge_capability_string(
        capabilities->state_schema,sizeof(capabilities->state_schema),
        "qwen38/hyper-kv-deltanet-ple-f32-v1");
    q38_segment_numeric_class(capabilities->numeric_class,
                              sizeof(capabilities->numeric_class),numeric_kinds);
    coli_edge_capability_string(
        capabilities->tokenizer_class,sizeof(capabilities->tokenizer_class),
        "qwen38/hf-byte-bpe-nfc-v1");
    capabilities->state_dtype=COLI_EDGE_DTYPE_F32;
    capabilities->state_width=(uint32_t)config->hc_width;
    capabilities->vocab_size=(uint32_t)config->vocab;
    capabilities->max_batch_rows=128;
    capabilities->max_context_tokens=(uint32_t)config->max_positions;
    capabilities->num_layers=(uint32_t)config->layers;
    capabilities->bos_token_id=-1;
    capabilities->eos_token_id=config->eos_id;
    capabilities->resident_bytes=resident;
    *engine_impl=engine;
    return 0;
}

static int qwen38_edge_tokenize(
    void *engine_impl,const char *text,size_t text_bytes,
    int32_t *token_ids,size_t token_capacity,size_t *token_count,
    char *error,size_t error_size) {
    (void)engine_impl;
    if(!text||!token_count||text_bytes>INT_MAX)
        return coli_edge_adapter_error(error,error_size,
                                       "invalid Qwen3.8 tokenizer input");
    int *ids=NULL,count=0;
    encode_text_n(text,text_bytes,&ids,&count);
    if(count<0||(token_ids&&token_capacity<(size_t)count)) {
        free(ids);
        return coli_edge_adapter_error(error,error_size,
                                       "Qwen3.8 token output buffer is too small");
    }
    *token_count=(size_t)count;
    if(token_ids)
        for(int item=0;item<count;item++)token_ids[item]=ids[item];
    free(ids);
    return 0;
}

static int qwen38_edge_detokenize(
    void *engine_impl,const int32_t *token_ids,size_t token_count,
    char *text,size_t text_capacity,size_t *text_bytes,
    char *error,size_t error_size) {
    Qwen38EdgeEngine *engine=(Qwen38EdgeEngine*)engine_impl;
    if(!engine||!token_ids||!token_count||!text_bytes||token_count>INT_MAX||
       token_count>SIZE_MAX/sizeof(int))
        return coli_edge_adapter_error(error,error_size,
                                       "invalid Qwen3.8 detokenizer input");
    int *ids=(int*)malloc(token_count*sizeof(*ids));
    if(!ids)
        return coli_edge_adapter_error(error,error_size,
            "out of memory detokenizing Qwen3.8 tokens");
    for(size_t item=0;item<token_count;item++){
        int token=token_ids[item];
        if(token<0||token>=engine->model.c.vocab||token>=g_tok_n||
           !g_tok||!g_tok[token]){
            free(ids);
            return coli_edge_adapter_error(error,error_size,
                                           "Qwen3.8 token ID is not decodable");
        }
        ids[item]=token;
    }
    unsigned char *decoded=NULL;size_t decoded_bytes=0;
    int result=decode_range_alloc(ids,0,(int)token_count,
                                  &decoded,&decoded_bytes);
    free(ids);
    if(result) {
        free(decoded);
        return coli_edge_adapter_error(error,error_size,
            "cannot detokenize Qwen3.8 tokens");
    }
    *text_bytes=decoded_bytes;
    if(text&&text_capacity<decoded_bytes+1u) {
        free(decoded);
        return coli_edge_adapter_error(error,error_size,
                                       "Qwen3.8 text output buffer is too small");
    }
    if(text)memcpy(text,decoded,decoded_bytes+1u);
    free(decoded);
    return 0;
}

static int qwen38_edge_embed(void *engine_impl,
                             const ColiEdgeEmbedRequest *request,
                             char *error,size_t error_size) {
    Qwen38EdgeEngine *engine=(Qwen38EdgeEngine*)engine_impl;
    Cfg *config=&engine->model.c;
    float *output=(float*)request->output;
    float *row=(float*)malloc((size_t)config->hidden*sizeof(*row));
    if(!row)
        return coli_edge_adapter_error(error,error_size,
            "out of memory embedding Qwen3.8 tokens");
    for(uint32_t index=0;index<request->rows;index++) {
        if(request->should_cancel&&
           request->should_cancel(request->cancel_user_data)) {
            free(row);
            return coli_edge_adapter_error(error,error_size,
                                           "Qwen3.8 Edge embedding cancelled");
        }
        int token=request->token_ids[index];
        if(token<0||token>=config->vocab) {
            free(row);
            return coli_edge_adapter_error(error,error_size,
                                           "Qwen3.8 token ID is out of range");
        }
        q38_weight_row(&engine->model.embed,token,row);
        float *state=output+(size_t)index*config->hc_width;
        for(int copy=0;copy<config->hc_count;copy++)
            memcpy(state+(size_t)copy*config->hidden,row,
                   (size_t)config->hidden*sizeof(*row));
    }
    free(row);
    return 0;
}

static int qwen38_edge_select(void *engine_impl,
                              const ColiEdgeSelectRequest *request,
                              char *error,size_t error_size) {
    Qwen38EdgeEngine *engine=(Qwen38EdgeEngine*)engine_impl;
    Cfg *config=&engine->model.c;
    float *hidden=(float*)malloc((size_t)config->hidden*sizeof(*hidden));
    float *logits=(float*)malloc((size_t)config->vocab*sizeof(*logits));
    if(!hidden||!logits) {
        free(logits);free(hidden);
        return coli_edge_adapter_error(error,error_size,
                                       "out of memory running Qwen3.8 head");
    }
    const float *input=(const float*)request->input;
    for(uint32_t row=0;row<request->rows;row++) {
        if(request->should_cancel&&
           request->should_cancel(request->cancel_user_data)) {
            free(logits);free(hidden);
            return coli_edge_adapter_error(error,error_size,
                                           "Qwen3.8 Edge selection cancelled");
        }
        q38_gr_read(&engine->model,&engine->model.final_gr,
                    input+(size_t)row*config->hc_width,1,hidden,NULL);
        q38_weight_matmul(logits,hidden,&engine->model.lm_head,
                          1,config->hidden,config->vocab);
        if(coli_edge_argmax(logits,(uint32_t)config->vocab,
                            &request->token_ids[row],
                            request->scores?&request->scores[row]:NULL)) {
            free(logits);free(hidden);
            return coli_edge_adapter_error(error,error_size,
                                           "Qwen3.8 Edge head failed");
        }
    }
    free(logits);free(hidden);
    return 0;
}

static const ColiEdgeAdapter qwen38_edge_adapter={
    .struct_size = sizeof(ColiEdgeAdapter),
    .abi_version = COLI_EDGE_ABI_VERSION,
    .engine_id = "qwen38",
    .engine_open = qwen38_edge_engine_open,
    .engine_destroy = qwen38_edge_engine_destroy,
    .tokenize = qwen38_edge_tokenize,
    .detokenize = qwen38_edge_detokenize,
    .embed = qwen38_edge_embed,
    .select = qwen38_edge_select,
    .reserved_fn = {0}
};

int coli_qwen38_edge_adapter_register(void) {
    return coli_edge_adapter_register(&qwen38_edge_adapter);
}
#endif /* COLI_EDGE_ADAPTER */
