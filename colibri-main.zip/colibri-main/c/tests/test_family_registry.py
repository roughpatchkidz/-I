import json
import re
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest import mock

from family_registry import (
    FAMILIES,
    DisplayVariant,
    FamilyCapabilities,
    FamilyConfigError,
    FamilyDescriptor,
    FamilyLimits,
    PlannerGeometry,
    RegistryError,
    UnknownFamilyError,
    PlannerUnsupportedError,
    _build_registry,
    display_for,
    expert_contributions,
    fixed_resident_contribution,
    family_for_config,
    planner_geometry,
    public_metadata,
    resident_contribution,
    resolve_model,
    tuning_replay_prompt,
)


def _readmes(repo):
    """Ogni README del repo, trovato e non elencato.

    Una lista scritta a mano qui avrebbe lo stesso difetto che questi test
    esistono per prendere: chi aggiunge README.fr.md non tocca il test, il
    test continua a passare, e il lettore francese non trova il modello.
    """
    return sorted(repo.glob("README*.md"))


def qwen_geometry(config, context, _model_dir):
    layers = config["num_hidden_layers"]
    full = sum(kind == "full_attention" for kind in config["layer_types"])
    kv = full * context * config["num_key_value_heads"] * config["head_dim"] * 2 * 4
    conv_dim = (config["linear_num_key_heads"] * config["linear_key_head_dim"] * 2 +
                config["linear_num_value_heads"] * config["linear_value_head_dim"])
    fixed = (layers - full) * (
        config["linear_num_value_heads"] * config["linear_key_head_dim"] *
        config["linear_value_head_dim"] +
        conv_dim * (config["linear_conv_kernel_dim"] - 1)) * 4
    return PlannerGeometry(kv, fixed, 0, config["num_experts"])


def minimax_geometry(config, context, _model_dir):
    state = ((config["num_hidden_layers"] + 1) * context *
             config["num_key_value_heads"] * config["head_dim"] * 2 * 4)
    sparse = config["sparse_attention_config"]
    state += sum(bool(value) for value in sparse["sparse_attention_freq"]) * \
        context * sparse["sparse_index_dim"] * 4
    return PlannerGeometry(state, 0, 0, config["num_local_experts"])


TEST_INVENTORY = lambda _name, _size, _config, _dtype=None: ()
QWEN36_FIXTURE = FamilyDescriptor(
    id="qwen36",
    model_types=("qwen3_5_moe_text",),
    display_name="Qwen3.6",
    display_scale="",
    engine_artifact="qwen36",
    engine_aliases=(),
    engine_group="qwen36",
    internal_arch="qwen36",
    build_target="qwen36",
    process_names=("qwen36",),
    default_model_id="qwen3.6-colibri",
    cli_adapter="qwen36",
    gateway_adapter="qwen36",
    planner_id="qwen36_hybrid",
    planner_geometry=qwen_geometry,
    planner_unsupported_reason="",
    expert_inventory=TEST_INVENTORY,
    config_section="root",
    limits=FamilyLimits(8192, 262144, 1024, 8192, 1, 8, "Q36_MAXT"),
    capabilities=FamilyCapabilities(False, False, False, True),
)
MINIMAX_M3_FIXTURE = FamilyDescriptor(
    id="minimax_m3",
    model_types=("minimax_m3",),
    display_name="MiniMax M3",
    display_scale="",
    engine_artifact="colibri",
    engine_aliases=(),
    engine_group="colibri-core",
    internal_arch="minimax_m3",
    build_target="colibri",
    process_names=("colibri",),
    default_model_id="minimax-m3-colibri",
    cli_adapter="minimax_m3",
    gateway_adapter="minimax_m3",
    planner_id="minimax_m3_gqa",
    planner_geometry=minimax_geometry,
    planner_unsupported_reason="",
    expert_inventory=TEST_INVENTORY,
    config_section="root",
    limits=FamilyLimits(8192, 262144, 1024, 8192, 1, 8, "CTX"),
    capabilities=FamilyCapabilities(True, False, False, True),
)


class FamilyRegistryTest(unittest.TestCase):
    def test_qwen36_public_metadata_advertises_gateway_tool_support(self):
        family = next(family for family in FAMILIES if family.id == "qwen36")
        self.assertTrue(public_metadata(family)["capabilities"]["tools"])

    def test_production_descriptors_are_complete_unique_and_serializable(self):
        self.assertGreaterEqual(len(FAMILIES), 5)
        by_id, by_type = _build_registry(FAMILIES)
        self.assertEqual(len(by_id), len(FAMILIES))
        self.assertGreaterEqual(len(by_type), len(FAMILIES))
        for family in FAMILIES:
            with self.subTest(family=family.id):
                json.dumps(public_metadata(family))
                self.assertIn(family.id, by_id)

    def test_the_wire_capabilities_follow_the_engines_own_submit_contract(self):
        # `logprobs_echo` is the numeric logprobs/echo channel: the engine emits one ECHO
        # frame per prompt position it read out, position 0 included. `submit_gbytes` is
        # the header SHAPE -- the seventh numeric field coli_submit_parse reads, which a
        # sibling engine's six-field parser would take for a malformed key and answer with
        # "bad submit extension". Neither is published metadata: they describe the engine
        # link, not the user surface.
        by_id, _ = _build_registry(FAMILIES)
        for family_id, echo, gbytes in (("glm", True, True), ("mimo", True, True),
                                        ("qwen36", True, False), ("inkling", False, False),
                                        ("kimi", False, False), ("olmoe", False, False)):
            with self.subTest(family=family_id):
                self.assertIs(by_id[family_id].capabilities.logprobs_echo, echo)
                self.assertIs(by_id[family_id].capabilities.submit_gbytes, gbytes)
        # The positional flags keep their meaning and both new bits default to off.
        caps = FamilyCapabilities(True, False, False, True)
        self.assertFalse(caps.logprobs_echo)
        self.assertFalse(caps.submit_gbytes)

    def test_capabilities_carry_the_image_bit_for_families_with_an_image_path(self):
        # The bit says the gateway has a placeholder expansion for the family. Whether
        # the checkpoint being served actually loaded its tower is the engine's word
        # (the CAPS handshake line), never the family's: a glm53 export can carry
        # vision_config and no model.visual.* tensors.
        by_id, _ = _build_registry(FAMILIES)
        for family_id, expected in (("glm53", True), ("qwen38", True), ("qwen36", True),
                                    ("deepseek_v41", True), ("mimo", True),
                                    ("glm", True),   # Mistral-Large-4's pictures (expand_ml4_images); GLM-5.2's engine says vision=0
                                    ("kimi", False),
                                    ("inkling", False), ("olmoe", False),
                                    ("deepseek_v4", False), ("qwen_image", False)):
            with self.subTest(family=family_id):
                self.assertIs(by_id[family_id].capabilities.image, expected)
                self.assertIs(public_metadata(by_id[family_id])["capabilities"]["image"],
                              expected)
        # the four positional flags keep their meaning for every existing caller
        self.assertFalse(FamilyCapabilities(True, False, False, True).image)

    def test_glm53_exposes_engine_kv_slot_limit(self):
        by_id, _ = _build_registry(FAMILIES)
        self.assertEqual(by_id["glm53"].limits.max_kv_slots, 16)

    def test_unknown_or_invalid_config_never_falls_back_to_glm(self):
        with self.assertRaises(UnknownFamilyError):
            family_for_config({"model_type": "mixtral"})
        for config in ({}, {"model_type": ""}, {"model_type": []}, None):
            with self.subTest(config=config), self.assertRaises(FamilyConfigError):
                family_for_config(config)

    def test_model_resolution_reads_text_config_without_changing_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = {"model_type": "kimi_k3", "text_config": {"num_hidden_layers": 2}}
            (root / "config.json").write_text(json.dumps(config), encoding="utf-8")
            resolved = resolve_model(root)
            self.assertEqual(resolved.descriptor.id, "kimi")
            self.assertEqual(resolved.family_config, config["text_config"])

    def test_qwen_fixture_models_gqa_and_fixed_deltanet_state(self):
        config = {
            "model_type": "qwen3_5_moe_text",
            "num_hidden_layers": 8,
            "num_attention_heads": 4,
            "num_key_value_heads": 2,
            "head_dim": 16,
            "num_experts": 8,
            "num_experts_per_tok": 2,
            "layer_types": ["linear_attention"] * 3 + ["full_attention"] +
                           ["linear_attention"] * 3 + ["full_attention"],
            "linear_num_value_heads": 8, "linear_num_key_heads": 4,
            "linear_key_head_dim": 8, "linear_value_head_dim": 8,
            "linear_conv_kernel_dim": 4,
        }
        # qwen36 is a registered family now, so the fixture would collide on its
        # model_type alias. Assert against the production descriptor instead --
        # which is the stronger test: it pins the shipped geometry, not a copy.
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type[config["model_type"]]
        self.assertEqual(family, by_id["qwen36"])
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        self.assertEqual(geometry.configured_experts, 8)
        self.assertEqual(geometry.context_state_bytes, 16_384)
        self.assertEqual(geometry.fixed_state_bytes, 6 * (8 * 8 * 8 + 128 * 3) * 4)
        for model_type in ("qwen2", "qwen3_next", "my_qwen_model"):
            self.assertNotIn(model_type, by_type)
        # the dense Qwen3 is claimed by name (qwen36 runs it, GGUF or converted): every
        # layer holds KV, nothing is routed
        self.assertEqual(by_type["qwen3"], by_id["qwen36"])
        dense = {"model_type": "qwen3", "num_hidden_layers": 4, "num_key_value_heads": 2,
                 "head_dim": 16, "intermediate_size": 128}
        resolved = type("R", (), {"descriptor": family, "family_config": dense, "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        self.assertEqual((geometry.configured_experts, geometry.fixed_state_bytes), (0, 0))
        self.assertEqual(geometry.context_state_bytes, 4 * 32 * 2 * 16 * 2 * 4)

    def test_qwen38_fixture_resolves_nested_text_config_and_sizes_all_state(self):
        config = {
            "model_type": "qwen4_exp",
            "text_config": {
                "model_type": "qwen4_exp_text",
                "num_hidden_layers": 48,
                "hidden_size": 2560,
                "vocab_size": 248320,
                "max_position_embeddings": 262144,
                "eos_token_id": 248044,
                "num_attention_heads": 24,
                "num_key_value_heads": 2,
                "head_dim": 256,
                "rope_parameters": {"partial_rotary_factor": 0.25},
                "layer_types": ["linear_attention"] * 36 + ["full_attention"] * 12,
                "indexer_kv_heads": 1, "indexer_head_dim": 128,
                "indexer_n_heads": 4, "indexer_budget": 2048,
                "indexer_compress_ratio": 4,
                "linear_num_value_heads": 48,
                "linear_num_key_heads": 16,
                "linear_key_head_dim": 128, "linear_value_head_dim": 128,
                "linear_conv_kernel_dim": 4,
                "hc_count": 4, "hc_lowrank": 320,
                "ple_layer_ids": [2], "ple_embed_dim": 2560,
                "ple_conv_kernel_size": 4, "ngram_size": 3,
                "heads_per_ngram": 8, "split_ngram_parts": 128,
                "num_experts": 512, "moe_intermediate_size": 640,
                "num_experts_per_tok": 10,
                "shared_expert_intermediate_size": 640,
            },
        }
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config.json").write_text(json.dumps(config), encoding="utf-8")
            resolved = resolve_model(root)
        self.assertEqual(resolved.descriptor.id, "qwen38")
        self.assertEqual(resolved.family_config["model_type"], "qwen4_exp_text")
        geometry = planner_geometry(resolved, 32)
        self.assertEqual(geometry.configured_experts, 512)
        live_context = 12 * 32 * (2 * 2 * 256 + 128) * 4
        self.assertEqual(geometry.context_state_bytes,
                         live_context + 32 * 4)
        live_fixed = (36 * (48 * 128 * 128 + 10240 * 3) * 4 +
                      10240 * 9 * 4 + 2 * 8)
        expected_fixed = live_fixed * 2 + 248320 * 4
        self.assertEqual(geometry.fixed_state_bytes, expected_fixed)
        base_row = 4 * 2560 + 2 * 2560 + 4
        gated_residual_row = base_row + 2 * 4 * 2560 + 320
        qsa_row = (base_row + 2 * 24 * 256 + 2 * 2 * 256 +
                   (4 + 1) * 128 + 24 * 256)
        ple_row = base_row + 4 * 2560
        moe_fixed = 512 + 3 * 640 + 3 * 640 + 2 * 2560
        gdn_width = 2 * 16 * 128 + 48 * 128
        gdn_fixed = (2 * gdn_width + 3 * 48 * 128 +
                     2 * 48 + 2 * 48 * 128)
        ple_fixed = 2560 + 5 * 4 * 2560 + 2560
        qsa_fixed = 4 * 128 + 128 + 2048 + 4 - 1 + max(
            2 * (32 // 4), 256 + 2048 + 4 - 1)
        legacy_workspace = (
            32 * max(gated_residual_row, qsa_row, ple_row) +
            max(moe_fixed, gdn_fixed, ple_fixed, qsa_fixed)) * 4
        moe_assignment_bytes = 2 * (2560 + 640) * 4 + 8 + 2 * 4
        moe_row_bytes = (512 + 3 * 640 + 2560 + 1) * 4 + \
            10 * moe_assignment_bytes
        moe_fixed_bytes = 512 * (4 * 4 + 8) + 4
        moe_chunk_bytes = moe_fixed_bytes + 32 * moe_row_bytes
        delta_row_bytes = (gdn_width + 2 * 48 * 128 + 2 * 48) * 4
        delta_fixed_bytes = (gdn_width + 2 * 48 * 128 + 48 * 128) * 4
        delta_chunk_bytes = delta_fixed_bytes + 32 * delta_row_bytes
        batched_workspace = 32 * base_row * 4 + max(
            moe_chunk_bytes, delta_chunk_bytes)
        expected_workspace = max(legacy_workspace, batched_workspace)
        self.assertEqual(geometry.workspace_bytes, expected_workspace)

        # serve reads a prompt in segments (q38_serve_prefill): past one segment's rows the
        # forward's buffers stop growing with the context; the K/V and index rows do not
        segment = planner_geometry(resolved, 8192)
        full = planner_geometry(resolved, 262144)
        self.assertEqual(full.context_state_bytes,
                         12 * 262144 * (2 * 2 * 256 + 128) * 4 + 262144 * 4)
        pooled = 4 * (2 * (262144 // 4) - 2 * (8192 // 4))   # the selection's pooled scores
        self.assertLessEqual(full.workspace_bytes, segment.workspace_bytes + pooled)
        self.assertLess(full.workspace_bytes, 1_500_000_000)
        with mock.patch.dict("os.environ", {"COLI_PROMPT_SEGMENT": "2048"}):
            self.assertLess(planner_geometry(resolved, 262144).workspace_bytes, full.workspace_bytes)

        family = resolved.descriptor
        invalid = {
            "ngram_size": 2,
            "indexer_kv_heads": 2,
            "indexer_budget": 2047,
            "hc_count": 17,
            "ple_embed_dim": 2561,
            "linear_num_value_heads": 47,
            "num_attention_heads": 25,
        }
        for key, value in invalid.items():
            broken = json.loads(json.dumps(config["text_config"]))
            broken[key] = value
            bad = type("R", (), {"descriptor": family, "family_config": broken,
                                   "model_dir": "."})()
            with self.subTest(key=key), self.assertRaises(ValueError):
                planner_geometry(bad, 32)
        short = json.loads(json.dumps(config["text_config"]))
        short["max_position_embeddings"] = 16
        bad = type("R", (), {"descriptor": family, "family_config": short,
                               "model_dir": "."})()
        with self.assertRaisesRegex(ValueError, "max_position_embeddings"):
            planner_geometry(bad, 32)

    def test_qwen38_partial_rotary_above_one_does_not_truncate_into_range(self):
        # int(256 * 1.001) is 256, so the derived-dimension check never sees
        # that the factor is larger than the head. The indexer dim is the
        # head dim too, or the sparse-indexer check would reject it first.
        text = {
            "model_type": "qwen4_exp_text",
            "num_hidden_layers": 48, "hidden_size": 2560, "vocab_size": 248320,
            "max_position_embeddings": 262144, "eos_token_id": 248044,
            "num_attention_heads": 24, "num_key_value_heads": 2, "head_dim": 256,
            "rope_parameters": {"partial_rotary_factor": 1.001},
            "layer_types": ["linear_attention"] * 36 + ["full_attention"] * 12,
            "indexer_kv_heads": 1, "indexer_head_dim": 256,
            "indexer_n_heads": 4, "indexer_budget": 2048, "indexer_compress_ratio": 4,
            "linear_num_value_heads": 48, "linear_num_key_heads": 16,
            "linear_key_head_dim": 128, "linear_value_head_dim": 128,
            "linear_conv_kernel_dim": 4, "hc_count": 4, "hc_lowrank": 320,
            "ple_layer_ids": [2], "ple_embed_dim": 2560,
            "ple_conv_kernel_size": 4, "ngram_size": 3,
            "heads_per_ngram": 8, "split_ngram_parts": 128,
            "num_experts": 512, "moe_intermediate_size": 640,
            "num_experts_per_tok": 10, "shared_expert_intermediate_size": 640,
        }
        family = _build_registry(FAMILIES)[1]["qwen4_exp_text"]
        over = type("R", (), {"descriptor": family, "family_config": text, "model_dir": "."})()
        with self.assertRaisesRegex(ValueError, "partial_rotary_factor"):
            planner_geometry(over, 32)
        exact = json.loads(json.dumps(text))
        exact["rope_parameters"]["partial_rotary_factor"] = 1.0
        ok = type("R", (), {"descriptor": family, "family_config": exact, "model_dir": "."})()
        self.assertEqual(planner_geometry(ok, 32).configured_experts, 512)

    def test_qwen38_gguf_directory_is_sized_as_the_file_holds_it(self):
        # tools/gguf_import.py: resource_plan names each expert's slice of the
        # fused ggml tensor like a checkpoint expert, dtype "GGUF_<type>"; the
        # engine keeps the blocks as they are and reads the PLE table by rows.
        family = next(family for family in FAMILIES if family.id == "qwen38")
        resolved = type("R", (), {"descriptor": family,
                                   "family_config": {"num_experts": 512, "hidden_size": 2560,
                                                     "moe_intermediate_size": 640},
                                   "model_dir": "."})()
        self.assertEqual(expert_contributions(
            resolved, "model.layers.0.mlp.experts.5.down_proj.weight", 921600, "GGUF_IQ4_NL"),
            ((0, 5, 921600),))
        self.assertEqual(resident_contribution(
            resolved, "per_layer_token_embd.weight", 28800138240, "GGUF_IQ4_NL"), 0)
        self.assertEqual(resident_contribution(
            resolved, "blk.3.attn_q.weight", 1000, "GGUF_Q8_0"), 1000)
        self.assertEqual(resident_contribution(
            resolved, "blk.3.attn_q.weight", 1000, "GGUF_F16"), 2000)

    def test_qwen38_inventory_aggregates_per_expert_and_fused_tensor_sizes(self):
        family = next(family for family in FAMILIES if family.id == "qwen38")
        resolved = type("R", (), {"descriptor": family,
                                   "family_config": {"num_experts": 512,
                                                     "hidden_size": 32,
                                                     "moe_intermediate_size": 8},
                                   "model_dir": "."})()
        prefix = "model.language_model.layers.7.mlp.experts.23"
        self.assertEqual(expert_contributions(
            resolved, prefix + ".gate_proj.weight", 256, "F8_E4M3"),
            ((7, 23, 256),))
        self.assertEqual(expert_contributions(
            resolved, prefix + ".up_proj.weight", 512, "BF16"),
            ((7, 23, 512),))
        self.assertEqual(expert_contributions(
            resolved, prefix + ".down_proj.weight", 1024, "F32"),
            ((7, 23, 1024),))
        self.assertEqual(expert_contributions(
            resolved, prefix + ".down_proj.weight", 512, "F16"),
            ((7, 23, 1024),))
        # FP8 sidecars are normalized into a fixed per-model scale bank, not
        # copied into every cache slot.
        self.assertEqual(expert_contributions(
            resolved, prefix + ".down_proj.weight_scale_inv", 4, "F32"), ())
        self.assertEqual(fixed_resident_contribution(
            resolved, prefix + ".down_proj.weight_scale_inv", 4, "F32"), 4)
        with self.assertRaisesRegex(ValueError, "unsupported dtype/size"):
            expert_contributions(
                resolved, prefix + ".down_proj.weight_scale_inv", 16, "F32")
        fused = "model.layers.7.mlp.experts.gate_up_proj"
        fused_size = 512 * 2 * 32 * 8 * 2
        contributions = expert_contributions(resolved, fused, fused_size, "BF16")
        self.assertEqual(len(contributions), 512)
        self.assertEqual(contributions[23], (7, 23, 1024))
        contributions = expert_contributions(resolved, fused, fused_size, "F16")
        self.assertEqual(contributions[23], (7, 23, 2048))

        self.assertEqual(resident_contribution(
            resolved, "model.language_model.layers.0.self_attn.q_proj.weight",
            100, "BF16"), 100)
        self.assertEqual(resident_contribution(
            resolved, "model.language_model.layers.0.self_attn.q_proj.weight",
            100, "F16"), 200)
        self.assertEqual(resident_contribution(
            resolved, "model.language_model.layers.0.self_attn.q_norm.weight",
            100, "BF16"), 200)
        self.assertEqual(resident_contribution(
            resolved, "model.visual.blocks.0.attn.qkv.weight", 100), 0)
        self.assertEqual(resident_contribution(
            resolved, "mtp.layers.0.mlp.gate.weight", 100), 0)
        self.assertEqual(resident_contribution(
            resolved,
            "model.language_model.layers.1.ple.ple_embedding.ngram_embedding.shard_7.weight",
            100), 0)
        self.assertEqual(resident_contribution(
            resolved,
            "model.language_model.layers.1.ple.ple_embedding.layer_multipliers",
            24), 0)

    def test_minimax_fixture_can_share_colibri_without_becoming_glm(self):
        config = {
            "model_type": "minimax_m3",
            "num_hidden_layers": 2,
            "num_attention_heads": 4,
            "num_key_value_heads": 2,
            "head_dim": 8,
            "num_local_experts": 4,
            "num_experts_per_tok": 2,
            "sparse_attention_config": {
                "use_sparse_attention": True,
                "sparse_index_dim": 8,
                "sparse_attention_freq": [0, 1],
            },
        }
        by_id, by_type = _build_registry(FAMILIES + (MINIMAX_M3_FIXTURE,))
        family = by_type[config["model_type"]]
        self.assertEqual(family.engine_artifact, by_id["glm"].engine_artifact)
        self.assertEqual(family.engine_group, by_id["glm"].engine_group)
        self.assertNotEqual(family.internal_arch, by_id["glm"].internal_arch)
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        self.assertEqual(geometry.configured_experts, 4)
        self.assertEqual(geometry.context_state_bytes, 13_312)

    def test_olmoe_fixture_models_conventional_fp32_kv_cache(self):
        # OLMoE keeps a full K and V cache per layer, sized at num_attention_heads
        # * head_dim in fp32 (olmoe.c:1019-1020), no recurrent/fixed state, and no
        # model-specific workspace beyond the base runtime reserve.
        config = {
            "model_type": "olmoe",
            "num_hidden_layers": 4,
            "hidden_size": 32,
            "num_attention_heads": 4,
            "num_key_value_heads": 4,
            "num_experts": 8,
            "num_experts_per_tok": 2,
            "intermediate_size": 16,
            "vocab_size": 100,
        }
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type["olmoe"]
        self.assertEqual(family, by_id["olmoe"])
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        self.assertEqual(geometry.configured_experts, 8)
        # layers=4, context=32, heads=4, head_dim=32//4=8, K and V, fp32:
        # 4 * 32 * 4 * 8 * 2 * 4 = 32768
        self.assertEqual(geometry.context_state_bytes, 4 * 32 * 4 * 8 * 2 * 4)
        self.assertEqual(geometry.fixed_state_bytes, 0)
        self.assertEqual(geometry.workspace_bytes, 0)

    def test_production_planners_report_real_geometry(self):
        # #1066 is closed: every production planner now returns a real
        # PlannerGeometry instead of refusing with PlannerUnsupportedError.
        # The plan must never be a silently-invented zero-byte budget --
        # every family here has a resident KV/state cache, so at least one
        # of context_state_bytes or fixed_state_bytes must be non-zero.
        cases = {
            "olmoe": {
                "model_type": "olmoe",
                "hidden_size": 2048,
                "num_hidden_layers": 2,
                "num_attention_heads": 16,
                "num_key_value_heads": 16,
                "num_experts": 8,
            },
            "kimi_k3": {
                "model_type": "kimi_k3",
                "hidden_size": 2048,
                "num_hidden_layers": 8,
                "num_attention_heads": 16,
                "q_lora_rank": 64,
                "kv_lora_rank": 128,
                "qk_nope_head_dim": 64,
                "qk_rope_head_dim": 32,
                "v_head_dim": 128,
                "num_experts": 32,
                "linear_attn_config": {
                    "num_heads": 8,
                    "head_dim": 64,
                    "kda_layers": [1, 2, 3, 4, 5],
                },
            },
            "inkling": {
                "model_type": "inkling",
                "hidden_size": 2048,
                "num_hidden_layers": 6,
                "num_attention_heads": 16,
                "num_key_value_heads": 4,
                "head_dim": 32,
                "n_routed_experts": 8,
            },
            "deepseek_v4": {
                "model_type": "deepseek_v4",
                "hidden_size": 2048,
                "num_hidden_layers": 4,
                "num_attention_heads": 16,
                "head_dim": 32,
                "q_lora_rank": 16,
                "o_groups": 4,
                "o_lora_rank": 64,
                "sliding_window": 8,
                "index_head_dim": 24,
                "n_routed_experts": 32,
                "compress_ratios": [0, 2, 4, 4],
            },
        }
        for model_type, config in cases.items():
            family = family_for_config({"model_type": model_type})
            resolved = type("R", (), {"descriptor": family,
                                      "family_config": config,
                                      "model_dir": "."})()
            with self.subTest(model_type=model_type):
                geometry = planner_geometry(resolved, 32)
                self.assertIsInstance(geometry, PlannerGeometry)
                self.assertGreater(
                    geometry.context_state_bytes + geometry.fixed_state_bytes,
                    0)


    def test_olmoe_geometry_matches_engine_kv_allocation(self):
        # OLMoE config shaped like the real 1B-7B model (AI2), but small.
        config = {
            "model_type": "olmoe",
            "hidden_size": 2048,
            "num_hidden_layers": 2,
            "num_attention_heads": 16,
            "num_key_value_heads": 16,
            "num_experts": 8,
            "num_experts_per_tok": 2,
            "intermediate_size": 512,
            "vocab_size": 50304,
        }
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type[config["model_type"]]
        self.assertEqual(family, by_id["olmoe"])
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        # Engine allocates K+V with n_heads (not n_kv_heads), fp32:
        #   head_dim = hidden // n_heads = 2048 // 16 = 128
        #   state   = layers * context * heads * head_dim * 2 * 4
        self.assertEqual(geometry.configured_experts, 8)
        self.assertEqual(geometry.context_state_bytes,
                         2 * 32 * 16 * 128 * 2 * 4)
        self.assertEqual(geometry.fixed_state_bytes, 0)
        # Workspace: the bounded per-forward scratch (attention scores,
        # logits, expert temporaries) is covered by the base runtime reserve,
        # so the planner reports no context-scaling workspace (dev #1095).
        self.assertEqual(geometry.workspace_bytes, 0)

    def test_olmoe_geometry_scales_with_context(self):
        config = {
            "model_type": "olmoe",
            "hidden_size": 2048,
            "num_hidden_layers": 2,
            "num_attention_heads": 16,
            "num_key_value_heads": 16,
            "num_experts": 8,
            "num_experts_per_tok": 2,
            "intermediate_size": 512,
            "vocab_size": 50304,
        }
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type[config["model_type"]]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        small = planner_geometry(resolved, 16)
        large = planner_geometry(resolved, 64)
        ratio = large.context_state_bytes / small.context_state_bytes
        self.assertEqual(ratio, 4)  # linear in context
        # Workspace stays at zero at every context (per dev #1095): only the
        # KV state scales with context, so the ratio above is the full story.
        self.assertEqual(small.workspace_bytes, 0)
        self.assertEqual(large.workspace_bytes, 0)

    def test_olmoe_geometry_rejects_missing_keys(self):
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["olmoe"]
        resolved = type("R", (), {"descriptor": family, "family_config": {},
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_olmoe_geometry_uses_n_heads_not_n_kv_heads(self):
        # GQA where kv < q heads: the engine still allocates K/V per q head,
        # so the plan must follow num_attention_heads (olmoe.c:1019-1020).
        config = {
            "model_type": "olmoe",
            "hidden_size": 2048,
            "num_hidden_layers": 2,
            "num_attention_heads": 16,
            "num_key_value_heads": 4,   # GQA ratio 4
            "num_experts": 8,
            "num_experts_per_tok": 2,
            "intermediate_size": 512,
            "vocab_size": 50304,
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["olmoe"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        self.assertEqual(geometry.context_state_bytes,
                         2 * 32 * 16 * 128 * 2 * 4)  # 16 heads, not 4

    def test_kimi_geometry_matches_engine_hybrid_allocation(self):
        # Kimi K3-shaped config: 8 layers, 5 KDA + 3 MLA (small synthetic).
        config = {
            "model_type": "kimi_k3",
            "hidden_size": 2048,
            "num_hidden_layers": 8,
            "num_attention_heads": 16,
            "q_lora_rank": 64,
            "kv_lora_rank": 128,
            "qk_nope_head_dim": 64,
            "qk_rope_head_dim": 32,
            "v_head_dim": 128,
            "num_experts": 32,
            "linear_attn_config": {
                "num_heads": 8,
                "head_dim": 64,
                "short_conv_kernel_size": 3,
                "kda_layers": [1, 2, 3, 4, 5],
            },
        }
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type[config["model_type"]]
        self.assertEqual(family, by_id["kimi"])
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        # MLA cache: 3 MLA layers x context x (kv_lora + qk_rope) x 4
        self.assertEqual(geometry.context_state_bytes,
                         3 * 32 * (128 + 32) * 4)
        # KDA fixed recurrent state: 5 KDA layers x heads x hd x hd x 4
        self.assertEqual(geometry.fixed_state_bytes,
                         5 * 8 * 64 * 64 * 4)
        self.assertEqual(geometry.configured_experts, 32)

    def test_kimi_geometry_kda_state_does_not_scale_with_context(self):
        config = {
            "model_type": "kimi_k3",
            "hidden_size": 2048,
            "num_hidden_layers": 8,
            "num_attention_heads": 16,
            "q_lora_rank": 64,
            "kv_lora_rank": 128,
            "qk_nope_head_dim": 64,
            "qk_rope_head_dim": 32,
            "v_head_dim": 128,
            "num_experts": 32,
            "linear_attn_config": {
                "num_heads": 8,
                "head_dim": 64,
                "short_conv_kernel_size": 3,
                "kda_layers": [1, 2, 3, 4, 5],
            },
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["kimi"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        small = planner_geometry(resolved, 16)
        large = planner_geometry(resolved, 64)
        # KDA recurrent state is context-independent
        self.assertEqual(small.fixed_state_bytes, large.fixed_state_bytes)
        # MLA cache scales linearly with context
        self.assertEqual(large.context_state_bytes / small.context_state_bytes, 4)

    def test_kimi_geometry_rejects_missing_linear_attn_config(self):
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["kimi"]
        config = {
            "model_type": "kimi_k3",
            "hidden_size": 2048,
            "num_hidden_layers": 8,
            "num_attention_heads": 16,
            "q_lora_rank": 64,
            "kv_lora_rank": 128,
            "qk_nope_head_dim": 64,
            "qk_rope_head_dim": 32,
            "v_head_dim": 128,
            "num_experts": 32,
        }
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_kimi_geometry_rejects_missing_kda_layers(self):
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["kimi"]
        config = {
            "model_type": "kimi_k3",
            "hidden_size": 2048,
            "num_hidden_layers": 8,
            "num_attention_heads": 16,
            "q_lora_rank": 64,
            "kv_lora_rank": 128,
            "qk_nope_head_dim": 64,
            "qk_rope_head_dim": 32,
            "v_head_dim": 128,
            "num_experts": 32,
            "linear_attn_config": {"num_heads": 8, "head_dim": 64},
        }
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_kimi_geometry_rejects_missing_keys(self):
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["kimi"]
        resolved = type("R", (), {"descriptor": family, "family_config": {},
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_kimi_geometry_workspace_is_max_of_kda_and_mla(self):
        config = {
            "model_type": "kimi_k3",
            "hidden_size": 2048,
            "num_hidden_layers": 8,
            "num_attention_heads": 16,
            "q_lora_rank": 64,
            "kv_lora_rank": 128,
            "qk_nope_head_dim": 64,
            "qk_rope_head_dim": 32,
            "v_head_dim": 128,
            "num_experts": 32,
            "linear_attn_config": {
                "num_heads": 8,
                "head_dim": 64,
                "short_conv_kernel_size": 3,
                "kda_layers": [1, 2, 3, 4, 5],
            },
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["kimi"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        ctx = 32
        # KDA workspace: 6*ctx*P + ctx*hd + ctx*hidden floats
        ws_kda = (6 * ctx * (8 * 64) + ctx * 64 + ctx * 2048) * 4
        # MLA workspace: qa + qv + ckv + gv + ctx buffers
        qh = 64 + 32
        ws_mla = (ctx * 64 + ctx * 16 * qh + ctx * (128 + 32) +
                  2 * ctx * 16 * 128) * 4
        self.assertEqual(geometry.workspace_bytes, max(ws_kda, ws_mla))

    def test_inkling_geometry_matches_engine_hybrid_allocation(self):
        # 6 layers: default rule (i+1)%6 -> 5 sliding + 1 global (last).
        config = {
            "model_type": "inkling",
            "hidden_size": 2048,
            "num_hidden_layers": 6,
            "num_attention_heads": 16,
            "num_key_value_heads": 4,
            "head_dim": 32,
            "swa_num_attention_heads": 16,
            "swa_num_key_value_heads": 2,
            "swa_head_dim": 32,
            "sliding_window_size": 8,
            "d_rel": 4,
            "sconv_kernel_size": 3,
            "n_routed_experts": 8,
        }
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type[config["model_type"]]
        self.assertEqual(family, by_id["inkling"])
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        # 5 sliding layers: kv=2, hd=32, rows=window=8 -> 2*2*8*32*4 each
        sliding = 5 * (2 * 2 * 8 * 32 * 4)
        # 1 global layer: kv=4, hd=32, rows=context=32 -> 2*4*32*32*4
        global_ = 1 * (2 * 4 * 32 * 32 * 4)
        self.assertEqual(geometry.context_state_bytes, sliding + global_)
        # Conv states per layer: (2*kvdim + 2*hidden) * (conv_k-1) * 4
        kvdim_s = 2 * 32   # sliding kv*hd
        kvdim_g = 4 * 32   # global kv*hd
        fixed = 5 * (2 * kvdim_s + 2 * 2048) * 2 * 4
        fixed += 1 * (2 * kvdim_g + 2 * 2048) * 2 * 4
        self.assertEqual(geometry.fixed_state_bytes, fixed)
        self.assertEqual(geometry.configured_experts, 8)

    def test_inkling_geometry_sliding_ring_does_not_scale_past_window(self):
        config = {
            "model_type": "inkling",
            "hidden_size": 2048,
            "num_hidden_layers": 6,
            "num_attention_heads": 16,
            "num_key_value_heads": 4,
            "head_dim": 32,
            "swa_num_attention_heads": 16,
            "swa_num_key_value_heads": 2,
            "swa_head_dim": 32,
            "sliding_window_size": 8,
            "d_rel": 4,
            "sconv_kernel_size": 3,
            "n_routed_experts": 8,
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["inkling"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        small = planner_geometry(resolved, 8)    # context == window
        large = planner_geometry(resolved, 64)   # context > window
        # Sliding ring rows are capped at window, so beyond window the
        # sliding contribution is flat; only the 1 global layer grows.
        delta = large.context_state_bytes - small.context_state_bytes
        self.assertEqual(delta, 1 * (2 * 4 * (64 - 8) * 32 * 4))
        # Fixed (conv) state is context-independent
        self.assertEqual(small.fixed_state_bytes, large.fixed_state_bytes)

    def test_inkling_geometry_local_layer_ids_override_default(self):
        config = {
            "model_type": "inkling",
            "hidden_size": 2048,
            "num_hidden_layers": 4,
            "num_attention_heads": 16,
            "num_key_value_heads": 4,
            "head_dim": 32,
            "swa_num_attention_heads": 16,
            "swa_num_key_value_heads": 2,
            "swa_head_dim": 32,
            "sliding_window_size": 8,
            "d_rel": 4,
            "sconv_kernel_size": 3,
            "n_routed_experts": 8,
            "local_layer_ids": [0, 2],   # only layers 0 and 2 are sliding
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["inkling"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        # 2 sliding (kv=2, rows=8) + 2 global (kv=4, rows=32)
        expected = 2 * (2 * 2 * 8 * 32 * 4) + 2 * (2 * 4 * 32 * 32 * 4)
        self.assertEqual(geometry.context_state_bytes, expected)

    def test_inkling_geometry_audio_tower_adds_fixed_reserve(self):
        base = {
            "model_type": "inkling",
            "hidden_size": 2048,
            "num_hidden_layers": 6,
            "num_attention_heads": 16,
            "num_key_value_heads": 4,
            "head_dim": 32,
            "swa_num_attention_heads": 16,
            "swa_num_key_value_heads": 2,
            "swa_head_dim": 32,
            "sliding_window_size": 8,
            "d_rel": 4,
            "sconv_kernel_size": 3,
            "n_routed_experts": 8,
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["inkling"]
        resolved = type("R", (), {"descriptor": family, "family_config": base,
                                   "model_dir": "."})()
        no_audio = planner_geometry(resolved, 32)

        with_audio_cfg = dict(base)
        with_audio_cfg["audio_config"] = {"n_mel_bins": 80, "mel_vocab_size": 16}
        resolved2 = type("R", (), {"descriptor": family,
                                   "family_config": with_audio_cfg,
                                   "model_dir": "."})()
        audio = planner_geometry(resolved2, 32)
        # audio_enc table [80*16, 2048] + norm [2048], fp32
        expected_audio = (80 * 16 * 2048 + 2048) * 4
        self.assertEqual(audio.fixed_state_bytes - no_audio.fixed_state_bytes,
                         expected_audio)
        self.assertEqual(audio.context_state_bytes, no_audio.context_state_bytes)

    def test_inkling_geometry_rejects_missing_keys(self):
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["inkling"]
        resolved = type("R", (), {"descriptor": family, "family_config": {},
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_inkling_geometry_rejects_bad_layer_types_length(self):
        config = {
            "model_type": "inkling",
            "hidden_size": 2048,
            "num_hidden_layers": 6,
            "num_attention_heads": 16,
            "num_key_value_heads": 4,
            "head_dim": 32,
            "n_routed_experts": 8,
            "layer_types": ["hybrid_sliding"],  # wrong length
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["inkling"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_dsv4_geometry_matches_engine_context_bytes(self):
        # 4 layers: ratios [0, 2, 4, 4] -> no-compress, compressor, indexer, indexer
        config = {
            "model_type": "deepseek_v4",
            "hidden_size": 2048,
            "num_hidden_layers": 4,
            "num_attention_heads": 16,
            "head_dim": 32,
            "q_lora_rank": 16,
            "o_groups": 4,
            "o_lora_rank": 64,
            "sliding_window": 8,
            "index_head_dim": 24,
            "n_routed_experts": 32,
            "compress_ratios": [0, 2, 4, 4],
        }
        by_id, by_type = _build_registry(FAMILIES)
        family = by_type[config["model_type"]]
        self.assertEqual(family, by_id["deepseek_v4"])
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        # Fixed window ring: 4 layers * window 8 * head_dim 32 * 4
        self.assertEqual(geometry.fixed_state_bytes, 4 * 8 * 32 * 4)
        # Compressor states: ceil(32/2)=16 * hd * 4  +  ceil(32/4)=8 * hd * 4 * 2
        state = 16 * 32 * 4 + 8 * 32 * 4 + 8 * 32 * 4
        # Indexer states (ratio==4): ceil(32/4)=8 * index_hd 24 * 4, for 2 layers
        state += 8 * 24 * 4 + 8 * 24 * 4
        self.assertEqual(geometry.context_state_bytes, state)
        self.assertEqual(geometry.configured_experts, 32)

    def test_dsv4_geometry_fixed_ring_does_not_scale_with_context(self):
        config = {
            "model_type": "deepseek_v4",
            "hidden_size": 2048,
            "num_hidden_layers": 4,
            "num_attention_heads": 16,
            "head_dim": 32,
            "q_lora_rank": 16,
            "o_groups": 4,
            "o_lora_rank": 64,
            "sliding_window": 8,
            "index_head_dim": 24,
            "n_routed_experts": 32,
            "compress_ratios": [0, 2, 4, 4],
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["deepseek_v4"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        small = planner_geometry(resolved, 16)
        large = planner_geometry(resolved, 64)
        # Window ring is context-independent
        self.assertEqual(small.fixed_state_bytes, large.fixed_state_bytes)
        # Compressed states scale ~linearly with context (ceil divisions)
        ratio = large.context_state_bytes / small.context_state_bytes
        self.assertAlmostEqual(ratio, 4, delta=0.5)

    def test_dsv4_geometry_workspace_matches_attention_scratch(self):
        config = {
            "model_type": "deepseek_v4",
            "hidden_size": 2048,
            "num_hidden_layers": 4,
            "num_attention_heads": 16,
            "head_dim": 32,
            "q_lora_rank": 16,
            "o_groups": 4,
            "o_lora_rank": 64,
            "sliding_window": 8,
            "index_head_dim": 24,
            "n_routed_experts": 32,
            "compress_ratios": [0, 2, 4, 4],
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["deepseek_v4"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 32)
        ctx = 32
        q_width = 16 * 32       # heads * head_dim
        oa_width = 4 * 64       # o_groups * o_lora_rank
        expected = (ctx * (16 + 2 * q_width + 32 + oa_width) +
                    max(16, 32)) * 4
        self.assertEqual(geometry.workspace_bytes, expected)

    def test_dsv4_geometry_rejects_bad_compress_ratios(self):
        config = {
            "model_type": "deepseek_v4",
            "hidden_size": 2048,
            "num_hidden_layers": 4,
            "num_attention_heads": 16,
            "head_dim": 32,
            "q_lora_rank": 16,
            "o_groups": 4,
            "o_lora_rank": 64,
            "sliding_window": 8,
            "index_head_dim": 24,
            "n_routed_experts": 32,
            "compress_ratios": [0, 2],  # wrong length
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["deepseek_v4"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_dsv4_geometry_rejects_missing_keys(self):
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["deepseek_v4"]
        resolved = type("R", (), {"descriptor": family, "family_config": {},
                                   "model_dir": "."})()
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 32)

    def test_dsv4_geometry_all_uncompressed_layers_have_only_ring(self):
        config = {
            "model_type": "deepseek_v4",
            "hidden_size": 2048,
            "num_hidden_layers": 4,
            "num_attention_heads": 16,
            "head_dim": 32,
            "q_lora_rank": 16,
            "o_groups": 4,
            "o_lora_rank": 64,
            "sliding_window": 8,
            "index_head_dim": 24,
            "n_routed_experts": 32,
            "compress_ratios": [0, 0, 0, 0],
        }
        by_id, _ = _build_registry(FAMILIES)
        family = by_id["deepseek_v4"]
        resolved = type("R", (), {"descriptor": family, "family_config": config,
                                   "model_dir": "."})()
        geometry = planner_geometry(resolved, 64)
        # No compressors: context state is zero, only the ring is resident
        self.assertEqual(geometry.context_state_bytes, 0)
        self.assertEqual(geometry.fixed_state_bytes, 4 * 8 * 32 * 4)

    def test_cli_and_gateway_dispatch_follow_the_registry(self):
        import openai_server
        from importlib.machinery import SourceFileLoader
        import importlib.util

        cli_path = Path(__file__).resolve().parent.parent / "coli"
        loader = SourceFileLoader("family_registry_cli_test", str(cli_path))
        spec = importlib.util.spec_from_loader(loader.name, loader)
        cli = importlib.util.module_from_spec(spec)
        loader.exec_module(cli)

        source = cli_path.read_text(encoding="utf-8")
        self.assertNotRegex(source, r"family\.(?:cli|gateway)_adapter\s+not in")
        self.assertNotIn("K3CHAT1", source)
        self.assertEqual(source.count("if not family.has_gateway_adapter:"), 3)
        self.assertEqual(source.count("if not family.has_cli_adapter:"), 1)
        self.assertEqual(set(openai_server.family_ids()),
                         {family.id for family in FAMILIES})
        self.assertEqual({family.id for family in cli.all_families()},
                         {family.id for family in FAMILIES})

        resolved = type("R", (), {"descriptor": replace(
            FAMILIES[0], has_cli_adapter=False, has_gateway_adapter=False)})()
        args = type("A", (), {"model": ".", "prompt": ["hello"],
                                "no_attach": True})()
        with mock.patch.object(cli, "need_model"), \
             mock.patch.object(cli, "resolve_model", return_value=resolved), \
             mock.patch.object(cli, "engine_for", return_value="engine"), \
             mock.patch.object(cli, "banner"):
            with self.assertRaisesRegex(SystemExit, "coli run is not wired"):
                cli.cmd_run(args)
            with self.assertRaisesRegex(SystemExit, "gateway adapter is not wired"):
                cli.cmd_chat(args)

        # a family the gateway drives without a one-shot adapter (Qwen3.8, #2189): coli run
        # goes through the private server coli chat starts
        resolved = type("R", (), {"descriptor": replace(
            FAMILIES[0], has_cli_adapter=False, has_gateway_adapter=True)})()
        with mock.patch.object(cli, "need_model"), \
             mock.patch.object(cli, "resolve_model", return_value=resolved), \
             mock.patch.object(cli, "engine_for", return_value="engine"), \
             mock.patch.object(cli, "banner"), \
             mock.patch.object(cli, "run_via_gateway") as gateway:
            cli.cmd_run(args)
        gateway.assert_called_once()
        self.assertEqual(gateway.call_args.args[2:], ("engine", "hello"))

    def test_tuning_replay_prompts_are_registry_owned(self):
        prompt = "hello {world}"
        expected = {
            # GLM-5.3 apre il ragionamento e non lo chiude: il suo
            # chat_template.jinja mette <think> dopo <|assistant|> e basta,
            # dove GLM-5.2 metteva <think></think>.
            "glm53": "[gMASK]<sop><|user|>hello {world}<|assistant|><think>",
            "glm": "[gMASK]<sop><|user|>hello {world}<|assistant|><think></think>",
            "inkling": "<|user|>hello {world}<|assistant|>",
            "kimi": "K3CHAT1\nM user 13\nhello {world}G 0\n\n",
            "olmoe": "<|user|>\nhello {world}\n<|assistant|>\n",
            # Qwen3.6's generation prompt MUST open <think>: the model was
            # never trained on the bare "assistant\\n" state and greedy argmax
            # there lands on an EOS special (measured gen=0).
            "qwen36": "<|im_start|>user\nhello {world}<|im_end|>\n"
                      "<|im_start|>assistant\n<think>\n",
            "qwen38": "<|im_start|>system\nReasoning effort is set to xhigh. Please think carefully "
                      "through the task, validate key assumptions, consider plausible alternatives, "
                      "and prioritize correctness, consistency, and clarity in the final answer."
                      "<|im_end|>\n<|im_start|>user\nhello {world}<|im_end|>\n"
                      "<|im_start|>assistant\n<think>\n",
            "deepseek_v4": "hello {world}",
            # V4.1 ships its chat encoding as a Python module (encoding/encoding.py),
            # not a jinja template, so the replay prompt stays the bare text like V4.
            "deepseek_v41": "hello {world}",
            # MiMo-V2.6: render_chat_mimo's cue with thinking on (its template's default)
            "mimo": "<|im_start|>user\nhello {world}<|im_end|><|im_start|>assistant\n<think>",
            # An image model has no chat template and nothing to tune; the
            # template is the identity and `coli tune` refuses the modality.
            "qwen_image": "hello {world}",
            # A decision model answers questions; it has no prompt to replay.
            "laya": "hello {world}",
            "gliner_decide": "hello {world}",
        }
        self.assertEqual(
            {family.id: tuning_replay_prompt(family, prompt) for family in FAMILIES},
            expected,
        )

    def test_optional_adapters_and_prompt_template_are_registry_invariants(self):
        self.assertFalse(QWEN36_FIXTURE.has_cli_adapter)
        self.assertFalse(QWEN36_FIXTURE.has_gateway_adapter)
        self.assertEqual(tuning_replay_prompt(QWEN36_FIXTURE, "hello"), "hello")

        with self.assertRaises(RegistryError):
            _build_registry((replace(QWEN36_FIXTURE,
                                     resident_inventory="not callable"),))

        for template in ("static", "{unknown}", "{prompt", "{prompt[foo]}"):
            with self.subTest(template=template), self.assertRaises(RegistryError):
                _build_registry((replace(QWEN36_FIXTURE,
                                         tune_prompt_template=template),))

    def test_doctor_reports_unknown_family_instead_of_falling_back(self):
        from doctor import run_doctor

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config.json").write_text(
                json.dumps({"model_type": "mixtral"}), encoding="utf-8")
            (root / "tokenizer.json").write_text("{}", encoding="utf-8")
            report = run_doctor(root, engine_path=root / "colibri",
                                available_memory=16_000_000_000,
                                available_disk=1, gpus=[],
                                linkage={"linked": False, "missing": False})
        checks = {item["id"]: item for item in report["checks"]}
        self.assertEqual(checks["model.family"]["status"], "fail")
        self.assertIn("unsupported model_type", checks["model.family"]["summary"])
        self.assertIsNone(report["plan"])

    def test_doctor_reports_engine_capability_failure(self):
        from doctor import run_doctor

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config.json").write_text(
                json.dumps({"model_type": "kimi_k3"}), encoding="utf-8")
            (root / "tokenizer.json").write_text("{}", encoding="utf-8")
            report = run_doctor(
                root, engine_path=root / "colibri",
                engine_error=UnknownFamilyError("this image contains only GLM"),
                available_memory=16_000_000_000, available_disk=1, gpus=[],
                linkage={"linked": False, "missing": False})
        checks = {item["id"]: item for item in report["checks"]}
        self.assertEqual(checks["engine.binary"]["status"], "fail")
        self.assertEqual(report["status"], "error")

    def test_tools_capability_matches_what_the_renderer_actually_does(self):
        """The `tools` flag must agree with the gateway's behaviour.

        It is descriptive -- it only feeds the capability dict -- which is
        exactly why it drifted: glm53 and kimi both render and parse tool calls
        while sharing a COMMON_CAP that said they do not, and nothing failed to
        tell anyone. A client asking what a family supports was told the
        opposite of the truth. Ask the renderer instead of trusting the flag.
        """
        import openai_server

        probe = [{"role": "user", "content": "hi"}]
        tool = [{"type": "function",
                 "function": {"name": "f", "description": "d",
                              "parameters": {"type": "object", "properties": {}}}}]
        for family in FAMILIES:
            renderer = getattr(openai_server, f"render_chat_{family.id}", None)
            if renderer is None:          # kimi/deepseek build their payload in C
                continue
            refused = False
            try:
                renderer(probe, tools=tool)
            except openai_server.APIError as exc:
                refused = getattr(exc, "code", None) == "unsupported_parameter"
            except Exception:             # nothing else here is a capability answer
                continue
            self.assertEqual(
                family.capabilities.tools, not refused,
                f"{family.id}: registry says tools={family.capabilities.tools} but the "
                f"renderer {'refuses' if refused else 'accepts'} them")

    def test_a_reasoning_family_gets_more_room_than_a_single_answer(self):
        """Chi ragiona deve avere un budget interattivo piu' largo del default.

        Il tetto sui token e' una rete di sicurezza: la fine vera la decidono
        gli stop token. Ma su un modello che riflette prima di rispondere, un
        tetto stretto non ti prende DOPO la risposta, ti prende DENTRO al
        pensiero, e il turno finisce senza che l'utente veda niente (#1278).

        glm53, inkling e kimi erano rimaste all'interattivo uguale al default,
        mentre ogni altra famiglia che ragiona lo aveva gia' alzato. Nessuno se
        n'e' accorto perche' il registro accetta qualsiasi valore >= 1: questo
        controllo esiste perche' la prossima non passi allo stesso modo.
        """
        for family in FAMILIES:
            if not family.capabilities.thinking:
                continue          # senza ragionamento il default e' la risposta intera
            self.assertGreater(
                family.limits.interactive_max_output, family.limits.default_max_output,
                f"{family.id}: reasons, but its interactive budget "
                f"({family.limits.interactive_max_output}) is no larger than the "
                f"non-interactive default ({family.limits.default_max_output}) -- "
                f"reasoning can consume it before the answer starts")

    def test_every_readme_names_every_family(self):
        """Ogni README, tradotto compreso, deve nominare ogni famiglia.

        E' la terza volta oggi che un conteggio ripetuto in due posti diverge:
        release.yml costruiva sei motori e ne copiava sette, i contatori degli
        adapter dicevano 7 con 8 famiglie registrate, e i README dichiaravano
        sei, sette e otto famiglie contemporaneamente -- l'inglese si
        contraddiceva da solo fra riga 21 e riga 586.

        Il nome della famiglia e' il controllo giusto, non il numerale: sono
        quattro lingue e il numerale si scrive in quattro modi, mentre
        `Qwen3.8-Flash-Next` si scrive uguale ovunque. Chi aggiunge una famiglia
        e dimentica le traduzioni lo scopre qui invece che da un utente che
        legge la sua lingua e non trova il modello.
        """
        repo = Path(__file__).resolve().parents[2]
        for path in _readmes(repo):
            name = path.name
            text = path.read_text(encoding="utf-8")
            for family in FAMILIES:
                # Il nome senza il suffisso di taglia: i README scrivono
                # "**Qwen3.6** (35B-A3B)", non "Qwen3.6-35B-A3B", perche' la
                # dimensione sta fra parentesi. Cercare il display_name intero
                # fallirebbe su una differenza di formattazione invece che su
                # una famiglia mancante, che e' quello che qui interessa.
                parts = []
                for piece in family.display_name.split("-"):
                    if re.fullmatch(r"A?\d+(\.\d+)?B", piece):
                        break
                    parts.append(piece)
                token = "-".join(parts) or family.display_name
                # assertTrue e non assertIn: assertIn stampa il README intero
                # nel messaggio di errore, e mille righe di markdown nascondono
                # la riga che dice cosa manca.
                self.assertTrue(token in text,
                                f"{name}: does not mention {family.display_name} "
                                f"({family.id}); a reader in that language cannot "
                                f"tell the family is supported")

    def test_release_ships_everything_coli_reaches(self):
        """L'archivio deve contenere ogni file Python che coli raggiunge.

        #1296: il pacchetto v1.10.0 aveva quattro comandi rotti. release.yml
        copiava sette .py scelti a mano piu' un solo file in tools/, e il
        codice era andato avanti. Mancavano convert_fp8_to_int4.py,
        eval_glm.py, fetch_benchmarks.py, mirror_plan.py, e i moduli cluster,
        glm53_image, qwen38_image.

        Ora la lista la calcola c/tools/pack_python.py. Questo test fissa i
        due punti ciechi che avevano fatto passare il difetto, perche' sono i
        due modi in cui un file sfugge a chi guarda a occhio:

        - un import dentro una funzione, dopo un sys.path.insert. E' il caso
          di qwen38_image in openai_server.py, e l'ImportError li' e'
          catturato e riscritto come "image support needs Pillow and numpy":
          nel pacchetto pubblicato mandare un'immagine dava la colpa
          all'ambiente dell'utente per un file che non avevamo spedito.
        - un sottoprocesso scritto con lo spazio dopo la virgola,
          os.path.join(TOOLS, "mirror_plan.py"). La mia prima grep cercava
          TOOLS," senza spazio e non lo vedeva: quattro invocazioni, non tre.
        """
        repo = Path(__file__).resolve().parents[2]
        sys.path.insert(0, str(repo / "c" / "tools"))
        try:
            import pack_python
        finally:
            sys.path.pop(0)

        reached = {path.name for path in pack_python.needed(repo / "c")}

        # I sette file che mancavano davvero dall'archivio v1.10.0.
        for name in ("convert_fp8_to_int4.py", "eval_glm.py",
                     "fetch_benchmarks.py", "mirror_plan.py",
                     "cluster.py", "glm53_image.py", "qwen38_image.py"):
            self.assertIn(name, reached,
                          f"{name} mancava dall'archivio v1.10.0 e il calcolo "
                          f"non lo ritrova: #1296 si ripeterebbe")

        release = (repo / ".github" / "workflows" / "release.yml").read_text(
            encoding="utf-8")
        self.assertIn("pack_python.py c dist", release,
                      "release.yml non calcola piu' i file da copiare")
        self.assertIn("--check", release,
                      "release.yml non verifica piu' l'archivio estratto")

    def test_the_python_job_builds_every_engine_a_test_skips_without(self):
        """Un test protetto da skipUnless(ENGINE.exists()) sparisce se il job
        non compila quel motore, e sparisce in silenzio: la classe si salta,
        il job resta verde, e nessuno distingue "passato" da "mai eseguito".

        E' successo davvero. Il job Python non compilava nessun motore, quindi
        sette test fra test_kimi_usage_cli e test_inkling_prefix_serve non
        giravano da sempre, e uno era rosso da quando il messaggio di kimi_k3
        e' stato riscritto. E' la stessa forma del job dei sanitizer che
        rieseguiva un binario senza strumentazione: verde perche' vuoto.

        Il controllo va nella direzione che serve. Non chiede che il job
        compili una certa lista, che sarebbe un'altra costante da tenere
        allineata a mano: parte dai test, guarda su quale binario si saltano,
        e pretende che il job lo costruisca.
        """
        repo = Path(__file__).resolve().parents[2]
        tests_dir = repo / "c" / "tests"
        guard = re.compile(r'ENGINE\s*=\s*HERE\s*/\s*\(?\s*"([a-z0-9_]+)\.exe"'
                           r'.*?else\s*"([a-z0-9_]+)"', re.S)
        needed = {}
        for path in sorted(tests_dir.glob("test_*.py")):
            text = path.read_text(encoding="utf-8")
            if "skipUnless" not in text or "ENGINE.exists()" not in text:
                continue
            m = guard.search(text)
            if m:
                needed[m.group(2)] = path.name
        self.assertTrue(needed,
                        "nessun test guardato da ENGINE.exists() trovato: il "
                        "controllo non sta piu' guardando niente")
        ci = (repo / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
        # Il corpo del job va da "  python:" fino al job successivo, cioe' la
        # prossima riga indentata di due spazi esatti. Tagliare al primo "\n  "
        # non funziona: le righe interne sono indentate di quattro e cominciano
        # anch'esse per due spazi, quindi il corpo verrebbe vuoto e il test
        # fallirebbe sempre, per la ragione sbagliata.
        job = re.search(r"(?m)^  python:\n(.*?)(?=^  \S|\Z)", ci, re.S)
        self.assertIsNotNone(job, "il job 'python:' non esiste piu' in ci.yml")
        body = job.group(1)
        # I bersagli veri di make, non il corpo del job: un commento che nomina
        # "test_inkling_prefix_serve.py" contiene la parola "inkling" e farebbe
        # passare il controllo senza che nulla venga compilato. Il controllo
        # negativo di questo test lo ha dimostrato togliendo inkling dalla
        # riga di build: passava lo stesso.
        built = set()
        for run_line in re.findall(r"(?m)^\s*run:\s*(.+)$", body):
            m = re.search(r"\bmake\b(?:\s+-C\s+\S+)?\s+(.*)", run_line)
            if m:
                built.update(tok for tok in m.group(1).split() if not tok.startswith("-"))
        for engine, where in sorted(needed.items()):
            self.assertIn(engine, built,
                          f"{where} si salta se '{engine}' non e' compilato, e il "
                          f"job Python della CI non lo compila: quei test non "
                          f"girano mai e il job resta verde perche' e' vuoto")

    def test_every_readme_banner_matches_the_declared_version(self):
        """Il banner dei README deve dire la versione che dichiara version.py.

        Il numero vive in cinque posti e finora niente li legava. Il modo in
        cui questo sbaglia non e' rumoroso: si aggiornano quattro file su
        cinque, la release esce, e il banner del quinto annuncia la versione
        precedente a chiunque legga quella lingua. E' la stessa forma che ha
        fatto uscire la v1.9.0 senza archivi -- una costante, piu' consumatori,
        nessun controllo -- solo su un file diverso.

        Qui il confronto e' con version.py e non fra i README fra loro: se
        divergessero tutti insieme dal codice, un test di sola coerenza
        reciproca li troverebbe d'accordo e non direbbe niente.
        """
        repo = Path(__file__).resolve().parents[2]
        declared = re.search(r'__version__\s*=\s*"([^"]+)"',
                             (repo / "c" / "version.py").read_text(encoding="utf-8"))
        self.assertIsNotNone(declared, "c/version.py: __version__ non trovato")
        version = declared.group(1)
        seen = 0
        for path in _readmes(repo):
            for banner in re.findall(r"colibri v(\d+\.\d+\.\d+)",
                                     path.read_text(encoding="utf-8")):
                seen += 1
                self.assertEqual(
                    banner, version,
                    f"{path.name}: il banner dice v{banner} ma version.py "
                    f"dichiara {version}; la release annuncerebbe due numeri "
                    f"diversi a seconda della lingua che il lettore apre")
        # Se un giorno il banner cambia forma questo test smetterebbe di
        # guardare qualcosa senza mai fallire: meglio che lo dica.
        self.assertGreater(seen, 0,
                           "nessun banner 'colibri vX.Y.Z' trovato in alcun "
                           "README: il test non sta piu' controllando niente")

    def test_the_site_shows_the_version_and_every_family(self):
        """site/index.html deve dire la versione vera e nominare ogni famiglia.

        Trovato fermo a "Currently shipping v1.7.0" con sei famiglie su otto:
        quattro release e due modelli indietro. E' la sesta copia del numero di
        versione e la quinta lista di famiglie, e ne' il contratto dei banner
        (#1288) ne' quello dei README (#1287) la guardavano. Il sito e' la
        prima cosa che un visitatore vede e l'ultima che ci si ricorda di
        aggiornare: esattamente il posto per un contratto.
        """
        repo = Path(__file__).resolve().parents[2]
        site = (repo / "site" / "index.html").read_text(encoding="utf-8")
        declared = re.search(r'__version__\s*=\s*"([^"]+)"',
                             (repo / "c" / "version.py").read_text(encoding="utf-8"))
        shown = re.search(r"Currently shipping <b>v([\d.]+)</b>", site)
        self.assertIsNotNone(shown,
                             "site/index.html: la riga 'Currently shipping' non "
                             "c'e' piu'; il contratto non sta controllando niente")
        self.assertEqual(shown.group(1), declared.group(1),
                         f"il sito dice v{shown.group(1)} ma version.py dichiara "
                         f"{declared.group(1)}: il visitatore legge una versione "
                         f"vecchia")
        for family in FAMILIES:
            parts = []
            for piece in family.display_name.split("-"):
                if re.fullmatch(r"A?\d+(\.\d+)?B", piece):
                    break
                parts.append(piece)
            token = "-".join(parts) or family.display_name
            self.assertTrue(token in site,
                            f"site/index.html non nomina {family.display_name} "
                            f"({family.id}): il sito mostra meno famiglie di "
                            f"quante ne girano")

    def test_build_install_ci_and_release_cover_registered_engines(self):
        repo = Path(__file__).resolve().parents[2]
        makefile = (repo / "c" / "Makefile").read_text(encoding="utf-8")
        ci = (repo / ".github" / "workflows" / "ci.yml").read_text(encoding="utf-8")
        release = (repo / ".github" / "workflows" / "release.yml").read_text(
            encoding="utf-8")
        docker = (repo / "docker" / "Dockerfile.slim").read_text(encoding="utf-8")
        clean = (repo / "c" / "tools" / "clean.py").read_text(encoding="utf-8")
        make_rules = re.sub(r"\\\n[ \t]*", " ", makefile)
        install_rule = re.search(r"(?m)^install:\s*(.*)$", make_rules)
        self.assertIsNotNone(install_rule)
        install_prerequisites = install_rule.group(1).split("#", 1)[0]
        for family in FAMILIES:
            with self.subTest(family=family.id):
                self.assertRegex(
                    makefile,
                    rf"(?m)^{re.escape(family.build_target)}(?:\$\(EXE\))?:")
                install_target = family.build_target
                if family.id != "deepseek_v4":
                    install_target += "$(EXE)"
                self.assertRegex(
                    install_prerequisites,
                    rf"(?<![\w.-]){re.escape(install_target)}(?![\w.-])")
                if family.id != "deepseek_v4":
                    self.assertIn(family.build_target,
                                  re.search(r'ENGINES="([^"]+)"', ci).group(1).split())
                    self.assertIn(f"cp c/{family.engine_artifact}", release)
                    # Copiarlo non basta: va anche COSTRUITO. Il contratto
                    # verificava solo meta', e con quella meta' la v1.9.0 e'
                    # uscita col nome di GLM-5.3-Flash e senza il suo binario,
                    # esattamente come la v1.5.0 con DeepSeek V4 (#858). Un
                    # `cp` di un file che nessuno ha compilato fallisce a
                    # release gia' pubblicata, cioe' nel momento peggiore.
                    build_step = re.search(r"for t in ([a-z0-9_ ]+); do",
                                           release)
                    self.assertIsNotNone(build_step,
                                         "release.yml: build loop not found")
                    self.assertIn(family.build_target, build_step.group(1).split(),
                                  f"{family.id}: release.yml copies "
                                  f"c/{family.engine_artifact} but never builds it")
                    self.assertIn(f"$(LIBEXECDIR)/{family.engine_artifact}", makefile)
                    # `make clean` must actually remove the engine. When it does
                    # not, a rebuild with different EXTRA_CFLAGS reports "up to
                    # date" and the caller silently keeps the OLD binary. The
                    # ASan step of the Qwen3.6 oracle job re-ran an
                    # un-instrumented qwen36 that way for as long as it existed
                    # (#1262): green, with the sanitizer never having run.
                    self.assertIn(f'"{family.engine_artifact}"', clean,
                                  f"{family.id}: tools/clean.py does not remove "
                                  f"c/{family.engine_artifact}, so a rebuild with "
                                  f"different flags is a silent no-op")
                else:
                    self.assertIn("deepseek-v4", ci)
                    self.assertIn("cp c/deepseek_v4", release)
        for text in (makefile, docker):
            self.assertIn("family_registry.py", text)
        # release.yml non nomina piu' i singoli .py: da #1296 la lista la
        # calcola pack_python.py seguendo gli import a partire da coli. Il
        # contratto qui e' sempre lo stesso -- family_registry.py deve finire
        # nell'archivio -- ma va verificato alla fonte nuova, se no si
        # controlla che esista una riga invece che il file venga spedito.
        sys.path.insert(0, str(repo / "c" / "tools"))
        try:
            import pack_python
        finally:
            sys.path.pop(0)
        shipped = {path.name for path in pack_python.needed(repo / "c")}
        self.assertIn("family_registry.py", shipped,
                      "l'archivio non spedirebbe family_registry.py")


class GlmFamilyNamesBothModelsTest(unittest.TestCase):
    """#1365 follow-up: a GLM-5.3 container was announced as "GLM-5.2 744B".

    The engine loaded the right weights; only the banner named a different
    model. The fix is the name, and the reason the name covers two models
    rather than choosing between them is worth pinning here, because the
    obvious "improvement" later is to add detection.

    There is nothing to detect. Z.ai say so on GLM-5.3's own card -- "GLM-5.3
    uses the same base model as GLM-5.2; every gain comes from post-training"
    -- and the checkpoints agree: diffing the two real config.json leaves one
    extra key and the transformers_version that wrote the file. If a release
    ever ships a genuine discriminator, split the family then, on evidence,
    and this test is where to record it.
    """

    #: The two configs, reduced to what the registry reads plus the only two
    #: keys that actually differ between the real files.
    BASE = {
        "model_type": "glm_moe_dsa",
        "num_hidden_layers": 78,
        "n_routed_experts": 256,
        "hidden_size": 6144,
        "moe_intermediate_size": 2048,
    }

    def test_both_checkpoints_resolve_to_the_same_family(self):
        v52 = dict(self.BASE, transformers_version="5.12.0")
        v53 = dict(self.BASE, transformers_version="5.15.0",
                   moe_router_dtype="float32")
        self.assertEqual(family_for_config(v52).id, family_for_config(v53).id)
        self.assertEqual(family_for_config(v53).engine_artifact, "colibri")

    def test_the_only_differences_are_not_discriminators(self):
        """Neither key can carry the decision, so neither may be read as if it
        could. `transformers_version` records the library that wrote the file
        and changes when anyone re-exports; `moe_router_dtype` is a precision
        hint that a re-export of GLM-5.2 could equally carry."""
        source = Path(__file__).resolve().parents[1] / "family_registry.py"
        text = source.read_text(encoding="utf-8")
        for key in ("transformers_version", "moe_router_dtype"):
            self.assertNotIn(f'"{key}"', text,
                             f"{key} is not a version discriminator; naming a "
                             f"checkpoint from it would be a guess wearing a "
                             f"rule's clothes")

    def test_the_name_states_both_models(self):
        family = family_for_config(dict(self.BASE))
        for model in ("5.2", "5.3"):
            self.assertIn(model, family.display_name,
                          "a user running one of the two must not read the "
                          "name of the other")



# Planning keys of Qwen/Qwen3.8-2.4T-A95B, config.json (fetched 2026-09-03).
# Same model_type as the 35B container, an order of magnitude apart on every
# size that matters -- the case #1045 is about.
QWEN38_2P4T_CONFIG = {
    "model_type": "qwen3_5_moe_text",
    "num_hidden_layers": 92,
    "num_experts": 512,
    "num_experts_per_tok": 10,
    "hidden_size": 8192,
    "moe_intermediate_size": 2048,
    "full_attention_interval": 4,
    "layer_types": ["full_attention" if i % 4 == 3 else "linear_attention"
                    for i in range(92)],
    "num_attention_heads": 64,
    "num_key_value_heads": 4,
    "head_dim": 256,
    "linear_num_key_heads": 16,
    "linear_key_head_dim": 128,
    "linear_num_value_heads": 128,
    "linear_value_head_dim": 128,
    "linear_conv_kernel_dim": 4,
    "vocab_size": 248320,
    "max_position_embeddings": 262144,
    "mtp_num_hidden_layers": 1,
}

# The 35B container's flattened text config (what the converter writes).
QWEN36_35B_CONFIG = {
    "model_type": "qwen3_5_moe_text",
    "num_hidden_layers": 40,
    "num_experts": 256,
    "num_experts_per_tok": 8,
    "hidden_size": 2048,
    "layer_types": ["full_attention" if i % 4 == 3 else "linear_attention"
                    for i in range(40)],
    "num_key_value_heads": 2,
    "head_dim": 256,
    "linear_num_key_heads": 16,
    "linear_key_head_dim": 128,
    "linear_num_value_heads": 32,
    "linear_value_head_dim": 128,
    "linear_conv_kernel_dim": 4,
}


class DisplayVariantTest(unittest.TestCase):
    """One model_type, two checkpoint sizes: the banner must name what is on disk."""

    def _resolve(self, config):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config.json").write_text(json.dumps(config), encoding="utf-8")
            return resolve_model(root)

    def test_35b_container_keeps_its_name(self):
        self.assertEqual(display_for(self._resolve(QWEN36_35B_CONFIG)),
                         ("Qwen3.6-35B-A3B", "35B"))

    def test_2p4t_checkpoint_is_not_announced_as_35b(self):
        resolved = self._resolve(QWEN38_2P4T_CONFIG)
        self.assertEqual(resolved.descriptor.id, "qwen36")
        self.assertEqual(display_for(resolved), ("Qwen3.8-2.4T-A95B", "2.4T"))

    def test_35b_vl_checkpoint_resolves_through_text_config(self):
        # the HF repo nests the text config; the container flattens it
        wrapped = {"model_type": "qwen3_5_moe", "architectures": ["Qwen3_5MoeForConditionalGeneration"],
                   "text_config": QWEN36_35B_CONFIG}
        self.assertEqual(display_for(self._resolve(wrapped)), ("Qwen3.6-35B-A3B", "35B"))

    def test_unrecognised_geometry_names_itself(self):
        # a tiny fixture, or a third sibling: no borrowed parameter count
        tiny = dict(QWEN36_35B_CONFIG, num_hidden_layers=8, num_experts=8, hidden_size=64)
        self.assertEqual(display_for(self._resolve(tiny)), ("qwen3_5_moe_text", ""))
        # every key must match, one off is not "close enough"
        off = dict(QWEN38_2P4T_CONFIG, hidden_size=4096)
        self.assertEqual(display_for(self._resolve(off)), ("qwen3_5_moe_text", ""))

    def test_families_without_variants_are_unchanged(self):
        for family in FAMILIES:
            if family.display_variants:
                continue
            resolved = self._resolve({"model_type": family.model_types[0]})
            self.assertEqual(display_for(resolved), (family.display_name, family.display_scale))

    def test_variants_are_public(self):
        meta = public_metadata(next(f for f in FAMILIES if f.id == "qwen36"))
        self.assertEqual([v["display_name"] for v in meta["display_variants"]],
                         ["Qwen3.6-35B-A3B", "Qwen3.8-2.4T-A95B", "Qwen3.8-27B",
                          "Qwen3-Coder-30B-A3B", "Qwen3-Coder-REAP-25B-A3B", "Flint",
                          "Muse-Spark-Open-816B-A42B", "LFM3-VL-2B"])
        self.assertEqual(meta["display_variants"][3]["geometry"],
                         {"num_hidden_layers": 48, "num_experts": 128, "hidden_size": 2048})
        self.assertEqual(meta["display_variants"][2]["geometry"],
                         {"num_hidden_layers": 64, "hidden_size": 5120, "intermediate_size": 17408})
        self.assertEqual(meta["display_variants"][1]["geometry"],
                         {"num_hidden_layers": 92, "num_experts": 512, "hidden_size": 8192})
        for family in FAMILIES:
            json.dumps(public_metadata(family))

    def test_registry_refuses_malformed_variants(self):
        good = DisplayVariant((("num_hidden_layers", 8),), "Qwen3.6", "")
        for bad in (
            DisplayVariant((), "Qwen3.6", ""),                       # matches everything
            DisplayVariant((("num_hidden_layers", 0),), "Qwen3.6", ""),
            DisplayVariant((("num_hidden_layers", True),), "Qwen3.6", ""),
            DisplayVariant((("", 8),), "Qwen3.6", ""),
            DisplayVariant((("num_hidden_layers", 8),), "", ""),
            "not a variant",
        ):
            with self.subTest(bad=bad):
                with self.assertRaises(RegistryError):
                    _build_registry((replace(QWEN36_FIXTURE, display_variants=(good, bad)),))
        # display_name must be one of the variants' names (README contract)
        with self.assertRaises(RegistryError):
            _build_registry((replace(QWEN36_FIXTURE, display_variants=(
                DisplayVariant((("num_hidden_layers", 8),), "Something-Else", ""),)),))
        _build_registry((replace(QWEN36_FIXTURE, display_variants=(good,)),))


class Qwen38_2p4tGeometryTest(unittest.TestCase):
    """The registered qwen36 planner on the 2.4T config: every guard holds,
    and the numbers are the ones quoted in #1045."""

    def _resolve(self, config):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config.json").write_text(json.dumps(config), encoding="utf-8")
            return resolve_model(root)

    def test_planner_geometry_at_8k_and_256k(self):
        resolved = self._resolve(QWEN38_2P4T_CONFIG)
        g8 = planner_geometry(resolved, 8192)
        # 23 attention layers x 8192 x 4 kv heads x 256 x (K+V) x f32 = 1.44 GiB
        self.assertEqual(g8.context_state_bytes, 23 * 8192 * 4 * 256 * 2 * 4)
        self.assertAlmostEqual(g8.context_state_bytes / 2**30, 1.4375, places=4)
        self.assertEqual(g8.configured_experts, 512)
        # DeltaNet state is context-free: 0.55 GiB at any length
        g256 = planner_geometry(resolved, 262144)
        self.assertEqual(g256.fixed_state_bytes, g8.fixed_state_bytes)
        self.assertAlmostEqual(g256.context_state_bytes / 2**30, 46.0, places=1)
        self.assertAlmostEqual(g8.fixed_state_bytes / 2**30, 0.55, places=2)

    def test_context_beyond_the_registered_maximum_is_refused(self):
        resolved = self._resolve(QWEN38_2P4T_CONFIG)
        with self.assertRaises(ValueError):
            planner_geometry(resolved, 262144 + 1)

    def test_expert_inventory_sees_the_container_layout(self):
        # the container stores experts one tensor each; the 2.4T layer/expert
        # indices are within what the descriptor claims
        resolved = self._resolve(QWEN38_2P4T_CONFIG)
        self.assertEqual(expert_contributions(
            resolved, "model.layers.91.mlp.experts.511.merged_weight", 1234),
            ((91, 511, 1234),))
        self.assertEqual(expert_contributions(resolved, "mtp.layers.0.mlp.experts.0.x", 1), ())

if __name__ == "__main__":
    unittest.main()
