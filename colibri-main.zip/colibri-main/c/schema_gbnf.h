/* schema_gbnf.h — JSON-Schema -> GBNF compiler for the grammar-forced draft source (#48/#70).
 *
 * Compiles a practical subset of JSON Schema into the byte-level GBNF subset that
 * grammar.h parses, so structured-output requests (OpenAI `response_format:
 * {"type":"json_schema"}` and the SCHEMA= env) get grammar-forced drafts without
 * hand-writing GBNF.
 *
 * Safety model: the grammar is a DRAFT SOURCE, never a sampling constraint (see
 * grammar.h). A schema compiled too strictly (or a model that deviates) only costs
 * draft acceptance — output is unchanged. So the compiler can be strict and compact
 * (no whitespace between tokens, exact key order): strictness maximizes forced-span
 * length on conforming outputs and cannot corrupt non-conforming ones.
 *
 * Supported subset:
 *   type: object   + properties (+ required)     — properties in declared order;
 *                    if `required` is present it must list every property (OpenAI
 *                    structured-output "strict" semantics); a proper subset -> fail.
 *   type: string   (+ enum of strings, const)
 *   type: number | integer | boolean | null
 *   type: array    + items (+ minItems 0|1)
 *   enum / const   also allowed at value level with numbers
 *   nesting to SGB_MAX_DEPTH; annotation keys ($schema, title, description,
 *   default, examples, additionalProperties) are ignored.
 * Anything else (anyOf/oneOf/$ref/pattern/format/minimum/maximum...) -> returns NULL and
 * the caller falls back to running without a grammar. Fail-closed, never fatal.
 */
#ifndef SCHEMA_GBNF_H
#define SCHEMA_GBNF_H
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "json.h"

#define SGB_MAX_DEPTH 32

/* an array item that holds an array, compiled once as rule jitem<id> after root */
typedef struct { jval *sc; int depth; } SgbItemRule;

typedef struct {
    char  *s; size_t len, cap;      /* output GBNF text */
    int    nrule;                   /* next composite rule id */
    SgbItemRule *items; int items_cap;  /* composite rule bodies, indexed by id */
    int    use_str, use_num, use_int;  /* shared terminal rules actually referenced */
    char   err[160];
    int    fail;
} SgbCtx;

static void sgb_put(SgbCtx *C, const char *t){
    size_t n = strlen(t);
    if (C->len + n + 1 > C->cap){
        size_t nc = C->cap ? C->cap * 2 : 1024;
        while (nc < C->len + n + 1) nc *= 2;
        char *ns = (char *)realloc(C->s, nc);
        if (!ns){ C->fail = 1; return; }
        C->s = ns; C->cap = nc;
    }
    memcpy(C->s + C->len, t, n); C->len += n; C->s[C->len] = 0;
}

static void sgb_fail(SgbCtx *C, const char *what){
    if (!C->err[0]) snprintf(C->err, sizeof C->err, "unsupported schema: %s", what);
    C->fail = 1;
}

/* emit a JSON string VALUE (with quotes) as a GBNF literal: "..." with the JSON
 * text embedded, escaping for the GBNF literal syntax (\" \\ \xHH). */
static void sgb_put_json_string_lit(SgbCtx *C, const char *raw){
    sgb_put(C, "\"\\\"");                       /* GBNF literal opening: "\"  */
    char b[8];
    for (const unsigned char *p = (const unsigned char *)raw; *p; p++){
        unsigned char c = *p;
        if (c == '"')       sgb_put(C, "\\\\\\\"");   /* JSON \"  inside GBNF literal */
        else if (c == '\\') sgb_put(C, "\\\\\\\\");
        else if (c < 0x20){
            /* json.h already decoded the schema string. Escape the control
             * for JSON first, then escape that backslash for the GBNF literal. */
            const char *short_escape = c == '\b' ? "\\\\b" : c == '\f' ? "\\\\f"
                : c == '\n' ? "\\\\n" : c == '\r' ? "\\\\r" : c == '\t' ? "\\\\t" : NULL;
            if (short_escape) sgb_put(C, short_escape);
            else { snprintf(b, sizeof b, "\\\\u%04x", c); sgb_put(C, b); }
        }
        else if (c == 0x7f) sgb_put(C, "\\x7f");
        else { b[0] = (char)c; b[1] = 0; sgb_put(C, b); }
    }
    sgb_put(C, "\\\"\"");
}

/* emit a number the way a model would print it: shortest round-trip via %g */
static void sgb_put_number_lit(SgbCtx *C, double d){
    /* 1e9999 parses as inf. %.17g then writes the literal inf, which is not JSON. */
    if (!isfinite(d)){ sgb_fail(C, "non-finite number"); return; }
    char b[64]; snprintf(b, sizeof b, "\"%.17g\"", d);
    /* %.17g writes 0.1 as 0.10000000000000001: a fraction takes the fewest
     * digits that read back as the same double, the text a model writes. */
    if (d < 9007199254740992.0 && d > -9007199254740992.0 && d != (double)(long long)d)
        for (int prec = 15; prec < 17; prec++){
            char t[64]; snprintf(t, sizeof t, "\"%.*g\"", prec, d);
            if (strtod(t + 1, NULL) == d){ memcpy(b, t, sizeof b); break; }
        }
    /* Check the formatting range before converting: finite schema numbers
     * outside it need not be representable as long long. */
    if (d < 1e15 && d > -1e15 && d == (double)(long long)d)
        snprintf(b, sizeof b, "\"%lld\"", (long long)d);
    sgb_put(C, b);
}

static int sgb_is_annotation(const char *k){
    return !strcmp(k,"$schema") || !strcmp(k,"title") || !strcmp(k,"description")
        || !strcmp(k,"default") || !strcmp(k,"examples")
        || !strcmp(k,"additionalProperties");
}

/* forward */
static void sgb_value(SgbCtx *C, jval *sc, int depth);

static void sgb_enum(SgbCtx *C, jval *e){
    if (!e || e->t != J_ARR || e->len < 1){ sgb_fail(C, "empty enum"); return; }
    sgb_put(C, "( ");
    for (int i = 0; i < e->len && !C->fail; i++){
        if (i) sgb_put(C, " | ");
        jval *v = e->kids[i];
        if (v->t == J_STR)       sgb_put_json_string_lit(C, v->str);
        else if (v->t == J_NUM)  sgb_put_number_lit(C, v->num);
        else if (v->t == J_BOOL) sgb_put(C, v->boolean ? "\"true\"" : "\"false\"");
        else if (v->t == J_NULL) sgb_put(C, "\"null\"");
        else sgb_fail(C, "enum member type");
    }
    sgb_put(C, " )");
}

static void sgb_object(SgbCtx *C, jval *sc, int depth){
    jval *props = json_get(sc, "properties");
    jval *req   = json_get(sc, "required");
    if (!props || props->t != J_OBJ){ sgb_fail(C, "object without properties"); return; }
    if (props->len == 0){ sgb_put(C, "\"{\" jws \"}\""); return; }
    if (req){
        if (req->t != J_ARR){ sgb_fail(C, "required not an array"); return; }
        /* strict semantics: every property must be required (OpenAI structured
         * outputs contract). A proper subset would need optional-group emission
         * with ambiguous separators — out of v1 scope. */
        if (req->len != props->len){ sgb_fail(C, "required must list every property (strict)"); return; }
        for (int i = 0; i < props->len; i++){
            int found = 0;
            for (int j = 0; j < req->len; j++)
                if (req->kids[j]->t == J_STR && !strcmp(req->kids[j]->str, props->keys[i])) found = 1;
            if (!found){ sgb_fail(C, "property not in required (strict)"); return; }
        }
    }
    /* jws at every separator: whitespace tolerance is strictly acceptance-positive
     * for a DRAFT-source grammar — a compact-only grammar dies (desyncs) at the
     * first stray space and forfeits every span after it, while jws points merely
     * aren't forced themselves (two legal bytes) and the multi-byte spans around
     * them keep drafting. Measured on GLM-5.2 current main: the sloppy-JSON
     * continuation costs a compact grammar most of its spans. */
    sgb_put(C, "\"{\" jws ");
    for (int i = 0; i < props->len && !C->fail; i++){
        if (i) sgb_put(C, " \",\" jws ");
        sgb_put_json_string_lit(C, props->keys[i]);
        sgb_put(C, " jws \":\" jws ");
        sgb_value(C, props->kids[i], depth + 1);
        sgb_put(C, " jws");
    }
    sgb_put(C, " \"}\"");
}

/* true when a schema node is an array, or an object with an array below it */
static int sgb_has_array(jval *sc, int depth){
    if (!sc || sc->t != J_OBJ || depth > SGB_MAX_DEPTH) return 0;
    jval *ty = json_get(sc, "type");
    if (!ty || ty->t != J_STR) return 0;
    if (!strcmp(ty->str, "array")) return 1;
    jval *props = json_get(sc, "properties");
    if (strcmp(ty->str, "object") || !props || props->t != J_OBJ) return 0;
    for (int i = 0; i < props->len; i++)
        if (sgb_has_array(props->kids[i], depth + 1)) return 1;
    return 0;
}

static void sgb_item(SgbCtx *C, jval *items, int depth, const char *rule){
    if (rule[0]) sgb_put(C, rule); else sgb_value(C, items, depth);
}

/* An array names its item grammar twice (the first item, then each ","-item).
 * Inlining an item that holds an array at both places doubled everything below
 * it at every nesting level: 2^depth copies of the innermost item. Such an item
 * is queued as one composite rule, emitted after the root rule, and referenced
 * by name. Any other item is inlined as before and costs no extra rule. */
static void sgb_array(SgbCtx *C, jval *sc, int depth){
    jval *items = json_get(sc, "items");
    jval *mi    = json_get(sc, "minItems");
    /* Only the integers 0 and 1 are implemented. 0.5 and -1 used to fall
     * through as "zero or more", and true is a bool that is not a number. */
    int min1 = 0;
    if (mi){
        if (mi->t != J_NUM || !isfinite(mi->num) || mi->num != floor(mi->num) ||
            mi->num < 0.0 || mi->num > 1.0){
            sgb_fail(C, "minItems must be 0 or 1"); return;
        }
        min1 = mi->num == 1.0;
    }
    if (!items){ sgb_fail(C, "array without items"); return; }
    char rule[32] = "";
    if (sgb_has_array(items, depth + 1)){
        if (C->nrule == C->items_cap){
            int nc = C->items_cap ? C->items_cap * 2 : 8;
            SgbItemRule *ni = (SgbItemRule *)realloc(C->items, (size_t)nc * sizeof *ni);
            if (!ni){ C->fail = 1; return; }
            C->items = ni; C->items_cap = nc;
        }
        C->items[C->nrule].sc = items;
        C->items[C->nrule].depth = depth + 1;
        snprintf(rule, sizeof rule, "jitem%d", C->nrule++);
    }
    if (min1){
        sgb_put(C, "\"[\" jws ");
        sgb_item(C, items, depth + 1, rule);
        sgb_put(C, " jws ( \",\" jws ");
        sgb_item(C, items, depth + 1, rule);
        sgb_put(C, " jws )* \"]\"");
    } else {
        sgb_put(C, "\"[\" jws ( ");
        sgb_item(C, items, depth + 1, rule);
        sgb_put(C, " jws ( \",\" jws ");
        sgb_item(C, items, depth + 1, rule);
        sgb_put(C, " jws )* )? \"]\"");
    }
}

static void sgb_value(SgbCtx *C, jval *sc, int depth){
    if (C->fail) return;
    if (depth > SGB_MAX_DEPTH){ sgb_fail(C, "nesting too deep"); return; }
    if (!sc || sc->t != J_OBJ){ sgb_fail(C, "schema node not an object"); return; }

    /* reject unknown constraint keywords (fail-closed) */
    for (int i = 0; i < sc->len; i++){
        const char *k = sc->keys[i];
        if (strcmp(k,"type") && strcmp(k,"properties") && strcmp(k,"required")
            && strcmp(k,"items") && strcmp(k,"enum") && strcmp(k,"const")
            && strcmp(k,"minItems") && !sgb_is_annotation(k)){
            sgb_fail(C, k); return;
        }
    }

    jval *cst = json_get(sc, "const");
    if (cst){
        if (cst->t == J_STR)       sgb_put_json_string_lit(C, cst->str);
        else if (cst->t == J_NUM)  sgb_put_number_lit(C, cst->num);
        else if (cst->t == J_BOOL) sgb_put(C, cst->boolean ? "\"true\"" : "\"false\"");
        else if (cst->t == J_NULL) sgb_put(C, "\"null\"");
        else sgb_fail(C, "const type");
        return;
    }
    jval *en = json_get(sc, "enum");
    if (en){ sgb_enum(C, en); return; }

    jval *ty = json_get(sc, "type");
    if (!ty || ty->t != J_STR){ sgb_fail(C, "missing type"); return; }
    const char *t = ty->str;
    if      (!strcmp(t, "object"))  sgb_object(C, sc, depth);
    else if (!strcmp(t, "array"))   sgb_array(C, sc, depth);
    else if (!strcmp(t, "string")){ C->use_str = 1; sgb_put(C, "jstr"); }
    else if (!strcmp(t, "number")){ C->use_num = 1; sgb_put(C, "jnum"); }
    else if (!strcmp(t, "integer")){ C->use_int = 1; sgb_put(C, "jint"); }
    else if (!strcmp(t, "boolean")) sgb_put(C, "( \"true\" | \"false\" )");
    else if (!strcmp(t, "null"))    sgb_put(C, "\"null\"");
    else sgb_fail(C, t);
}

static void sgb_free_jval(jval *v){
    if (!v) return;
    if (v->t == J_OBJ){
        for (int i = 0; i < v->len; i++){ free(v->keys[i]); sgb_free_jval(v->kids[i]); }
        free(v->keys); free(v->kids);
    } else if (v->t == J_ARR){
        for (int i = 0; i < v->len; i++) sgb_free_jval(v->kids[i]);
        free(v->kids);
    } else if (v->t == J_STR) free(v->str);
    free(v);
}

/* Compile a JSON-Schema string to GBNF. Returns a malloc'd GBNF text (caller
 * frees) or NULL with a message in err (if err != NULL). */
static char *schema_to_gbnf(const char *schema_json, char *err, int errsz){
    SgbCtx C; memset(&C, 0, sizeof C);
    jval *sc = json_parse(schema_json, NULL);
    if (!sc){ if (err) snprintf(err, errsz, "schema: json parse failed"); return NULL; }

    sgb_put(&C, "root ::= jws ");
    sgb_value(&C, sc, 0);
    sgb_put(&C, " jws\n");
    /* item rules queued by sgb_array; compiling one can queue the next (a deeper
     * array), so nrule grows while this loop runs */
    for (int i = 0; i < C.nrule && !C.fail; i++){
        char head[40]; snprintf(head, sizeof head, "jitem%d ::= ", i);
        sgb_put(&C, head);
        sgb_value(&C, C.items[i].sc, C.items[i].depth);
        sgb_put(&C, "\n");
    }
    free(C.items);
    sgb_put(&C, "jws ::= ( \" \" | \"\\t\" | \"\\n\" | \"\\r\" )*\n");
    if (C.use_str)
        sgb_put(&C, "jstr ::= \"\\\"\" jchar* \"\\\"\"\n"
                    "jchar ::= [^\"\\\\\\x00-\\x1f] | \"\\\\\" ( [\"\\\\/bfnrt] | \"u\" jhex jhex jhex jhex )\n"
                    "jhex ::= [0-9a-fA-F]\n");
    if (C.use_num)
        sgb_put(&C, "jnum ::= \"-\"? ( \"0\" | [1-9] [0-9]* ) ( \".\" [0-9]+ )? ( ( \"e\" | \"E\" ) ( \"+\" | \"-\" )? [0-9]+ )?\n");
    if (C.use_int)
        sgb_put(&C, "jint ::= \"-\"? ( \"0\" | [1-9] [0-9]* )\n");

    sgb_free_jval(sc);
    if (C.fail || !C.s){
        if (err) snprintf(err, errsz, "%s", C.err[0] ? C.err : "schema: compile failed");
        free(C.s); return NULL;
    }
    return C.s;
}

#endif /* SCHEMA_GBNF_H */
